import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
study=Path('/Users/n/numivivo-hirisa-20260910');root=study/'native-programs';runtime=root/'name-mapping/runtime-release';binary=runtime/'numivivo';repo=Path('/Users/n/numivivo-h5ad-20260909')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def read(p):return json.loads(p.read_text())
def write(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n')
assert read(root/'release-cli/checks.json')['status']=='passed'
environment=read(runtime/'environment.json');assert sha(binary)==environment['binarySHA256']
protocol=read(root/'full-protocol.json');assert sha(root/'full-plan.json')==protocol['planSHA256']
assert all(sha(repo/name)==digest for name,digest in environment['sourceFiles'].items())
paths=['full-plan.json','full-protocol.json','run_full.py','check_native_programs.py','check_integration_response.py']
write(root/'full-execution-freeze.json',dict(binarySHA256=sha(binary),runtimeEnvironmentSHA256=sha(runtime/'environment.json'),files={n:sha(root/n) for n in paths},releaseCLI=read(root/'release-cli/checks.json'),psBefore=subprocess.check_output(['ps','-axo','pid,pcpu,rss,etime,comm'],text=True),startedAtUnix=time.time()))
env={**os.environ,'NUMIVIVO_HDF5_LIBRARY':'/Users/n/numivivo-multiassay-hdf5-20260909/libhdf5.dylib','OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','VECLIB_MAXIMUM_THREADS':'1'}
commands=[]
for name,cmd in [
 ('full-publish',['/usr/bin/time','-l',str(binary),'singlecell-h5ad-programs',str(study/'native-release/original.h5ad'),'--plan',str(root/'full-plan.json'),'--output',str(root/'full')]),
 ('full-independent',['/Users/n/numivivo-integration-reference-py/bin/python',str(root/'check_native_programs.py'),'--bundle',str(root/'full'),'--reference',str(study/'integration-programs/reference'),'--metadata',str(study/'integration-full/native/metadata.json'),'--out',str(root/'full-independent.json')]),
 ('full-verify',['/usr/bin/time','-l',str(binary),'singlecell-h5ad-programs-verify',str(root/'full')])]:
 free=shutil.disk_usage(root).free;assert free>=protocol['requiredAvailableGiBBeforeEachNativePhase']*2**30,('phase headroom',name,free)
 start=time.time();write(root/(name+'-start.json'),dict(command=cmd,freeBytes=free,startedAtUnix=start))
 with (root/(name+'.log')).open('x') as f:result=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 status=dict(command=cmd,seconds=time.time()-start,returnCode=result.returncode,freeBytesAfter=shutil.disk_usage(root).free);write(root/(name+'-status.json'),status);commands.append(status);print(name,status,flush=True);assert result.returncode==0
 if name=='full-publish':write(root/'full-output-freeze.json',{p.name:dict(bytes=p.stat().st_size,SHA256=sha(p)) for p in (root/'full').iterdir() if p.is_file() and p.name!='original.h5ad'})
assert read(root/'full-independent.json')['status']=='passed'
for name,value in read(root/'full-output-freeze.json').items():assert value==dict(bytes=(root/'full'/name).stat().st_size,SHA256=sha(root/'full'/name))
write(root/'full-complete.json',dict(status='passed',commands=commands,binarySHA256=sha(binary),cells=1612594,independentCheckSHA256=sha(root/'full-independent.json'),nativeReplayPassed=True,scope='Complete original-cohort standalone native expression scores and replay; independent all-cell values/detections/totals verified. Does not change integration biological failures or establish prediction/annotation.'))
