import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
repo=Path('/Users/n/numivivo-h5ad-20260909');study=Path('/Users/n/numivivo-hirisa-20260910');root=study/'native-programs/name-mapping';out=study/'storage-cleanup/program-build-cache';out.mkdir()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
assert json.loads((study/'native-programs/release-cli/checks.json').read_text())['status']=='passed'
environment=json.loads((root/'runtime-release/environment.json').read_text());frozen=root/'runtime-release/numivivo'
assert sha(frozen)==environment['binarySHA256']==sha(repo/'.build/arm64-apple-macosx/release/numivivo')
assert all(sha(repo/p)==h for p,h in environment['sourceFiles'].items())
targets=[repo/'.build/arm64-apple-macosx'/name for name in ['debug','release']]
aliases=[repo/'.build'/name for name in ['debug','release']]
manifest=[];owners=[]
for p,alias in zip(targets,aliases):
 assert p.is_dir() and not p.is_symlink() and p.resolve().is_relative_to(repo.resolve())
 assert (p/'Modules').is_dir() and (p/'description.json').is_file() and (p/'NumiVivoKit.build').is_dir()
 assert alias.is_symlink() and alias.resolve()==p
 for path in [p,*p.rglob('*')]:
  s=path.lstat();manifest.append(dict(path=str(path),inode=s.st_ino,mode=s.st_mode,bytes=s.st_size,blocks=s.st_blocks,symlink=path.is_symlink()))
 check=subprocess.run(['/usr/sbin/lsof','-nP','+D',str(p)],text=True,capture_output=True)
 owners.append(dict(path=str(p),returnCode=check.returncode,stdout=check.stdout,stderr=check.stderr))
 assert check.returncode==1 and not check.stdout.strip() and not check.stderr.strip(),'Preserve open or incompletely inspected build tree'
record=dict(status='verified-disposable-generated-build-cache',createdUnix=time.time(),paths=[str(p) for p in targets],aliases=[str(p) for p in aliases],freeBefore=shutil.disk_usage(repo).free,frozenRuntimeSHA256=sha(frozen),files=manifest,lsof=owners,psBefore=subprocess.check_output(['ps','-axo','pid,pcpu,rss,etime,comm'],text=True))
(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
for p,alias in zip(targets,aliases):
 assert alias.resolve()==p and p.lstat().st_ino==next(v['inode'] for v in manifest if v['path']==str(p))
 shutil.rmtree(p);alias.unlink()
assert sha(frozen)==environment['binarySHA256']
assert all(not p.exists() and not p.is_symlink() for p in targets+aliases)
result=dict(status='removed',logicalBytes=sum(v['bytes'] for v in manifest if not v['symlink']),allocatedBytes=sum(v['blocks']*512 for v in manifest),entries=len(manifest),freeBefore=record['freeBefore'],freeAfter=shutil.disk_usage(repo).free,remainingTargets=0,frozenRuntimePreserved=True,scope='Only verified regenerable debug/release build products and their exact symlinks; source, package checkout caches, frozen executables, research evidence and active full jobs preserved.')
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
