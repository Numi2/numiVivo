import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
repo=Path('/Users/n/numivivo-h5ad-20260909');root=Path('/Users/n/numivivo-hirisa-20260910/native-programs/name-mapping');base='f1c1bc6a87f50430ed15adf0ec3c21ad4ec47008'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def write(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n')
def git(*a):return subprocess.check_output(['git','-C',str(repo),*a],text=True)
assert git('rev-parse','HEAD').strip()==base
patch=json.loads((root/'admission-patch-source.json').read_text());assert {s[3:] for s in git('status','--porcelain','--untracked-files=all').splitlines()}==set(patch)
assert not git('diff','--cached','--name-only').strip()
assert all(sha(repo/p)==h for p,h in patch.items())
production={p:sha(repo/p) for p in git('ls-files','Package.swift','Sources').splitlines() if (repo/p).is_file()}
production.update(patch)
write(root/'admission-validation-start.json',dict(baseCommit=base,patch=patch,production=production,psBefore=subprocess.check_output(['ps','-axo','pid,pcpu,rss,etime,comm'],text=True),freeBytes=shutil.disk_usage(root).free))
env={**os.environ,'NUMIVIVO_HDF5_LIBRARY':'/Users/n/numivivo-multiassay-hdf5-20260909/libhdf5.dylib'}
commands=[]
for name,cmd in [('admission-tests',['swift','test','--jobs','2','--filter','SingleCellProgramTests|SingleCellPCABundleTests']),('admission-release-build',['swift','build','--jobs','2','-c','release','--product','numivivo'])]:
 start=time.time()
 with (root/(name+'.log')).open('x') as f:result=subprocess.run(cmd,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT)
 status=dict(command=cmd,returnCode=result.returncode,seconds=time.time()-start);write(root/(name+'-status.json'),status);commands.append(status);print(name,status,flush=True);assert result.returncode==0
assert all(sha(repo/p)==h for p,h in production.items())
runtime=root/'runtime-release';runtime.mkdir(exist_ok=False);binary=runtime/'numivivo';shutil.copy2(repo/'.build/release/numivivo',binary);binary.chmod(0o555)
hardware=subprocess.check_output(['system_profiler','SPHardwareDataType'],text=True);hardware='\n'.join(x for x in hardware.splitlines() if not any(k in x for k in ['Serial Number','Hardware UUID','Provisioning UDID']))+'\n'
manifest=dict(baseCommit=base,binarySHA256=sha(binary),sourceFiles=production,patchFiles=patch,configuration='release',buildLogSHA256=sha(root/'admission-release-build.log'),HDF5SHA256=sha(Path(env['NUMIVIVO_HDF5_LIBRARY'])),swift=subprocess.check_output(['swift','--version'],text=True),OS=subprocess.check_output(['sw_vers'],text=True),hardware=hardware,frozenAtUnix=time.time())
write(runtime/'environment.json',manifest);write(root/'admission-validation-complete.json',dict(status='passed',commands=commands,binarySHA256=sha(binary),scope='Native flat program accumulator and binary artifact tests plus complete release build; CLI and real cohort qualification remain separate.'))
