import hashlib,json,os,shutil,stat,subprocess
from pathlib import Path
root=Path('/Users/n/numivivo-metal-normalization-20260911');store=Path('/Users/n/numivivo-legacy-count-route-20260911/count-store')
assert json.loads((root/'native-checks.json').read_text())['status']=='passed'
assert json.loads((root/'cli-checks.json').read_text())['status']=='passed'
pairs=[(root/x/'values.bin',root/'cpu-0/values.bin') for x in ['cpu-before','cpu-1','cpu-2','cli-cpu','cli-cpu-explicit']]
pairs += [(root/x/'values.bin',root/'metal-0/values.bin') for x in ['metal-1','metal-2','cli-metal']]
pairs += [(root/'cli-store'/x,store/x) for x in ['original.h5ad','counts.bin']]
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1048576):h.update(b)
 return h.hexdigest()
records=[]
for target,retained in pairs:
 assert target!=retained and not target.is_symlink() and not retained.is_symlink()
 info=target.stat();assert stat.S_ISREG(info.st_mode)
 digest=sha(target);assert digest==sha(retained) and info.st_size==retained.stat().st_size
 record=dict(path=str(target),retainedPath=str(retained),bytes=info.st_size,SHA256=digest,device=info.st_dev,inode=info.st_ino,mtime=info.st_mtime_ns)
 records.append(record)
handles=subprocess.run(['lsof','-nP','--',*[r['path'] for r in records]],capture_output=True)
(root/'duplicate-lsof.stdout').write_bytes(handles.stdout);(root/'duplicate-lsof.stderr').write_bytes(handles.stderr)
assert handles.returncode==1 and not handles.stdout and not handles.stderr
before=shutil.disk_usage(root).free
for r in records:
 p=Path(r['path']);s=p.stat();assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)==(r['device'],r['inode'],r['bytes'],r['mtime']);p.unlink()
after=shutil.disk_usage(root).free
result=dict(status='removed-verified-duplicates',files=records,availableBytesBefore=before,availableBytesAfter=after,measuredAdditionalAvailableBytes=after-before,logicalBytes=sum(r['bytes'] for r in records),allTargetsAbsent=all(not Path(r['path']).exists() for r in records),receiptsAndLogsRetained=True)
(root/'duplicate-cleanup.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status=result['status'],files=len(records),availableBytesAfter=after,measuredAdditionalAvailableBytes=after-before)))
