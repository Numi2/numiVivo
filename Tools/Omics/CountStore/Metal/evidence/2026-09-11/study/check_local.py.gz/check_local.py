import hashlib,json
from pathlib import Path
import numpy as np
root=Path(__file__).parent;store=Path('/Users/home/numivivo-legacy-count-route-20260911/route/count-store')
quality=json.loads((store/'quality.json').read_text());receipt=json.loads((root/'local-metal/receipt.json').read_text())
raw=np.memmap(store/'counts.bin',mode='r',dtype=[('row','<u4'),('feature','<u4'),('value','<u8')]);values=np.memmap(root/'local-metal/values.bin',mode='r',dtype=[('row','<u4'),('feature','<u4'),('value','<f8')]);assert len(raw)==len(values)==14184532
totals=np.asarray(quality['rowTotals'],dtype=np.uint64);maximum=0.;violations=0
for start in range(0,len(raw),262144):
 r=raw[start:start+262144];v=values[start:start+262144]
 np.testing.assert_array_equal(r['row'],v['row']);np.testing.assert_array_equal(r['feature'],v['feature'])
 expected=np.log1p(r['value'].astype(np.float64)*(10000/totals[r['row']].astype(np.float64)))
 error=np.abs(v['value']-expected);maximum=max(maximum,float(error.max()));violations+=int((error>3e-6+3e-6*np.abs(expected)).sum())
 assert np.all(v['value']>0) and np.all(np.isfinite(v['value']))
 np.testing.assert_array_equal(v['value'],v['value'].astype(np.float32).astype(np.float64))
with (root/'local-metal/values.bin').open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
assert digest==bytes(receipt['values']['bytes']).hex() and violations==0
v=dict(status='passed',entries=len(raw),device=receipt['execution']['deviceName'],valuesSHA256=digest,maximumAbsoluteError=maximum,violations=violations,checkerSHA256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='Every original Kang count record versus independent FP64 NumPy expression; no biological prediction')
(root/'local-check.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v))
