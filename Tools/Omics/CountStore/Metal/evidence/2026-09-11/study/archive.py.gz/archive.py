import gzip,hashlib,json
from pathlib import Path
study=Path(__file__).parent;repo=Path('/Users/home/numivivo-single-cell-20260909');out=repo/'Tools/Omics/CountStore/Metal/evidence/2026-09-11';out.mkdir(parents=True,exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
files={}
for name in ['archive-initial-manifest.json','build-wrapper-before-fix.sh','default-build-shell-regression.json','backup.json','bindings.json','baseline-sources.sha256','local-check.json','check_local.py','preserve_normalized.py','remove_preserved_remote.py','remove_initial_duplicate.py','cleanup_benchmark_duplicates.py','remote-final-state.txt','local-metal.log','local-metal.stdout','local-metal/receipt.json','reference/checks.json']:
 files['study/'+name]=study/name
for p in sorted((study/'rejections').glob('*')):
 if p.is_file():files['study/rejections/'+p.name]=p
for p in sorted((study/'remote').iterdir()):
 if p.is_file() and p.suffix in ['.json','.log','.stdout','.stderr','.py']:
  files['native/'+p.name]=p
for name in ['runtime/sources.sha256','runtime-cli/sources.sha256']:
 files['native/'+name]=study/'remote'/name
for p in sorted((study/'remote/kernel').iterdir()):
 if p.is_file():files['native/kernel/'+p.name]=p
for label in ['cpu-before','cpu-0','cpu-1','cpu-2','metal-0','metal-1','metal-2','cli-cpu','cli-cpu-explicit','cli-metal','cli-store']:
 for name in ['receipt.json','input-receipt.json']:
  p=study/'remote'/label/name
  if p.exists():files['native/'+label+'/'+name]=p
for name in ['metadata.json','quality.json','plan.json']:
 files['common/'+name]=study/'remote/cli-store'/name
source_names=['Sources/NumiVivoKit/Omics/VivoH5ADCountStore.swift','Sources/NumiVivoKit/Omics/VivoMetalCountNormalization.swift','Sources/NumiVivoCLI/VivoSingleCellCLICommands.swift','Tools/Omics/H5AD/Main.swift','Tools/Omics/H5AD/CLIMain.swift','Tools/Omics/H5AD/build.sh']
source_names += [str(p.relative_to(repo)) for p in sorted((repo/'Tools/Omics/CountStore/Metal').iterdir()) if p.is_file()]
for name in source_names:files['source/'+name]=repo/name
files['study/archive.py']=Path(__file__)
records=[]
for name,p in sorted(files.items()):
 b=p.read_bytes();encoded=gzip.compress(b,mtime=0);q=out/(name+'.gz');q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(encoded)
 records.append(dict(sourcePath=name,sourceBytes=len(b),sourceSHA256=sha(b),storedPath=name+'.gz',storedBytes=len(encoded),storedSHA256=sha(encoded),gzipEncoded=True))
backup=json.loads((study/'backup.json').read_text());cleanup=json.loads((study/'remote/duplicate-cleanup.json').read_text())
native=json.loads((study/'remote/native-checks.json').read_text());reference=json.loads((study/'reference/checks.json').read_text())
manifest=dict(schemaVersion=1,status='passed',sourceBase='9cb829b8a800e3e89e0437d912d4e500234a2148',completeCells=24673,completeFeatures=15706,completeCountRecords=14184532,nativePublicationAndReplay=True,independentReference=reference['comparisons'],backendPromoted=False,performanceConclusion='No demonstrated end-to-end speedup: three-run median CPU 1.043 s, Metal 1.050 s',biologicalPredictionQualified=False,records=records,historicalNormalizedPayloadBackup=backup,benchmarkPayloadRestoration=cleanup['files'],sharedMetadataMember='common/metadata.json',compiledExecutables=json.loads((study/'bindings.json').read_text())['executables'],retainedPayloads=[dict(path='/Users/n/numivivo-metal-normalization-20260911/'+x['label']+'/values.bin',bytes=14184532*16,SHA256=x['SHA256']) for x in reference['comparisons']],scope='Full original Kang count transform; explicit FP32 GPU option, exact default CPU regression, actual product single-cell CLI and storage relocation. Not a full app build, general speedup or biological qualification.',archiveScriptSHA256=sha(Path(__file__).read_bytes()))
(out/'manifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(members=len(records),storedBytes=sum(x['storedBytes'] for x in records),manifestSHA256=sha((out/'manifest.json').read_bytes()))))
