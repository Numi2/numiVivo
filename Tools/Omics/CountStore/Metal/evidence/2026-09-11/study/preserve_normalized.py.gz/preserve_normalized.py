import gzip,hashlib,json,os,shutil,subprocess,time
from pathlib import Path
root=Path(__file__).parent;source='/Users/n/numivivo-count-store-final-20260909/normalized/values.bin';expected='66336f23b26f7c23c2bfd357c95142c948de9a4768ec48a5dd1ce90925e42821';size=5785321936
out=root/'norman-qualified-values.bin.gz'
assert not out.exists() and shutil.disk_usage(root).free>size+1073741824
p=subprocess.Popen(['ssh','-4','macmini','cat',source],stdout=subprocess.PIPE,stderr=(root/'backup-ssh.log').open('wb'));digest=hashlib.sha256();count=0;t=time.time()
with out.open('xb') as raw:
 with gzip.GzipFile(filename='',fileobj=raw,mode='wb',compresslevel=1,mtime=0) as f:
  while b:=p.stdout.read(1048576):digest.update(b);count+=len(b);f.write(b)
assert p.wait()==0 and count==size and digest.hexdigest()==expected
check=hashlib.sha256();length=0
with gzip.open(out,'rb') as f:
 while b:=f.read(1048576):check.update(b);length+=len(b)
assert length==size and check.hexdigest()==expected
compressed=hashlib.sha256()
with out.open('rb') as f:
 while b:=f.read(1048576):compressed.update(b)
v=dict(status='preserved-and-decoded-verified',source=source,localBackup=str(out),decodedBytes=count,decodedSHA256=expected,storedBytes=out.stat().st_size,storedSHA256=compressed.hexdigest(),seconds=time.time()-t)
(root/'backup.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v))
