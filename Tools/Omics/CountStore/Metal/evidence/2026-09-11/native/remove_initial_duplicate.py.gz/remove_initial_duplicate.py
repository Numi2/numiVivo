import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
root=Path('/Users/n/numivivo-metal-normalization-20260911');backup=json.loads((root/'backup.json').read_text())
source=Path('/Users/n/numivivo-count-store-20260909/normalized/values.bin')
assert backup['status']=='preserved-and-decoded-verified' and backup['source']=='/Users/n/numivivo-count-store-final-20260909/normalized/values.bin'
assert set(p.name for p in source.parent.iterdir())=={'values.bin','metadata.json','receipt.json','input-receipt.json'}
receipt=json.loads((source.parent/'receipt.json').read_text());expected=bytes(receipt['values']['bytes']).hex()
assert expected==backup['decodedSHA256'] and source.stat().st_size==backup['decodedBytes']==receipt['entries']*16
h=hashlib.sha256();before_stat=source.stat()
with source.open('rb') as f:
 while b:=f.read(1048576):h.update(b)
after_stat=source.stat()
assert h.hexdigest()==expected and all(getattr(after_stat,k)==getattr(before_stat,k) for k in ['st_dev','st_ino','st_size','st_mtime_ns','st_ctime_ns'])
handles=subprocess.run(['lsof','-nP','--',str(source)],capture_output=True)
(root/'cleanup-initial-lsof.stdout').write_bytes(handles.stdout);(root/'cleanup-initial-lsof.stderr').write_bytes(handles.stderr)
assert handles.returncode==1 and not handles.stdout and not handles.stderr,'Source still has an owner or handle inventory failed'
before=shutil.disk_usage(root).free;source.unlink();after=shutil.disk_usage(root).free
v=dict(status='removed-verified-redundant-payload',source=str(source),backup=backup,availableBytesBefore=before,availableBytesAfter=after,measuredAdditionalAvailableBytes=after-before,removedBytes=before_stat.st_size,sourceAbsent=not source.exists(),receiptsAndMetadataRetained=True,timeUnix=time.time())
(root/'cleanup-initial.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v))
