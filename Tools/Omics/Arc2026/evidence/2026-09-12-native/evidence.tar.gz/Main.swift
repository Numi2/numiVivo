import Foundation
@main struct ArcConformanceMain { static func main() { exit(VivoArc2026CLICommands().run(arguments: Array(CommandLine.arguments.dropFirst()))) } }
