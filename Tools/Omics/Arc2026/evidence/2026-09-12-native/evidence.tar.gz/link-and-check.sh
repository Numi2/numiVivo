#!/bin/bash
set -euo pipefail
ROOT=/Users/home/numivivo-arc-native-20260912
swiftc -swift-version 6 -O -parse-as-library -I "$ROOT/build" -I "$ROOT/source/Sources/CNumiVivoZlib" -I "$ROOT/source/Sources/NumiVivoCore/include" -L "$ROOT/build" -lNumiVivoKit "$ROOT/source/Sources/NumiVivoCLI/VivoArc2026CLICommands.swift" "$ROOT/Main.swift" "$ROOT/build/OmicsHNSW.o" "$ROOT/build/OmicsGaussian.o" -framework Accelerate -lc++ -o "$ROOT/arc-native"
/Users/home/numivivo-singlecell-benchmark-py/bin/python "$ROOT/source/Tools/Omics/Arc2026/check_native.py" --native "$ROOT/arc-native" --output "$ROOT/checks"
