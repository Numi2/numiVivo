import Foundation
import Testing
@testable import NumiVivoKit

@Suite struct SingleCellNBAdaptiveMomentsTests {
    @Test func discreteHermiteSumIsExactForCubicsAndBoundsQuartic() {
        for n in [1,2,7,31] {
            let span = Double(n), a = 3.0, b = a+span
            for degree in 0...3 {
                let d = Double(degree)
                let direct = (0...n).reduce(0.0) { $0+pow(a+Double($1),d) }
                let value = VivoOmicsNBAdaptiveMoments.polynomialSum(left: pow(a,d),right: pow(b,d),
                    leftSlope: degree == 0 ? 0 : d*pow(a,d-1),rightSlope: degree == 0 ? 0 : d*pow(b,d-1),span: span)
                #expect(abs(value-direct) < 1e-8)
            }
            let direct = (0...n).reduce(0.0) { $0+pow(a+Double($1),4) }
            let value = VivoOmicsNBAdaptiveMoments.polynomialSum(left: pow(a,4),right: pow(b,4),leftSlope: 4*pow(a,3),rightSlope: 4*pow(b,3),span: span)
            #expect(abs(direct-value-(pow(span,5)-span)/30) < 1e-7)
        }
    }
    @Test func adaptiveMomentsMatchDirectAndPreserveExplicitBudgets() throws {
        for (mu,phi) in [(10000.0,0.03),(10000,0.7),(10000,4)] {
            let direct = try VivoOmicsNBResidualAdjustment.moments(mean: mu,dispersion: phi,maximumTerms: 10_000_000)
            let adaptive = try VivoOmicsNBResidualAdjustment.moments(mean: mu,dispersion: phi,method: .adaptive)
            #expect(abs(adaptive.mean/direct.mean-1) < 2e-8)
            #expect(abs(adaptive.variance/direct.variance-1) < 2e-8)
            let diagnostics = try #require(adaptive.summation)
            #expect(diagnostics.method == .adaptive)
            #expect(adaptive.meanTruncationBound+diagnostics.meanErrorBound <= 1e-10*adaptive.mean)
            #expect(adaptive.varianceTruncationBound+diagnostics.varianceErrorBound <= 1e-10*adaptive.variance)
            #expect(adaptive.evaluatedCounts < direct.evaluatedCounts)
        }
        #expect(throws: (any Error).self) { try VivoOmicsNBResidualAdjustment.moments(mean: 1_000_000,dispersion: 0.03,maximumTerms: 4,method: .adaptive) }
        let small = try VivoOmicsNBResidualAdjustment.moments(mean: 1,dispersion: 0.2,method: .adaptive)
        #expect(small.summation == nil)
        #expect(small == (try VivoOmicsNBResidualAdjustment.moments(mean: 1,dispersion: 0.2)))
    }

    @Test func nativePMFAndDerivativeBoundsMatchIndependentHighPrecision() throws {
        struct Point: Decodable { let count: UInt64; let probability, deviance, logSlope, devianceSlope: Double }
        struct Reference: Decodable { let mean, dispersion, modeProbability: Double; let endpoints: [Point]; let fourthDerivativeAbsolute: [[Double]] }
        // Independently generated with 65-digit log-Gamma and differentiation.
        let json = #"""
[{"mean":10000,"dispersion":0.03,"endpoints":[{"count":5000,"probability":7.5295561843594e-07,"deviance":12.821168935657663,"logSlope":0.0031174149216534565,"devianceSlope":-0.006633505251987819},{"count":15000,"probability":6.6094769502340805e-06,"deviance":6.283862313932705,"logSlope":-0.001174626109557802,"devianceSlope":0.0022160667087235252}],"modeProbability":0.0002328743515003974,"fourthDerivativeAbsolute":[[2.3012687665798825e-17,1.1080275551152484e-17,1.061688749712393e-15],[5.674998492969853e-17,2.643068264619926e-16,6.076022212663575e-16],[4.5263445553215675e-18,2.0018308918602673e-17,7.196764129338375e-17]]},{"mean":100000,"dispersion":0.1,"endpoints":[{"count":50000,"probability":3.627101680197045e-06,"deviance":3.8624436778564073,"logSlope":7.998700194636771e-05,"devianceSlope":-0.00019997000466591677},{"count":150000,"probability":3.240878741337183e-06,"deviance":1.8905311859835334,"logSlope":-3.999700024886789e-05,"devianceSlope":6.666111158020679e-05}],"modeProbability":1.3174905270936692e-05,"fourthDerivativeAbsolute":[[7.597856683262248e-23,4.954543953557771e-22,1.943552480484192e-21],[8.005040810802097e-24,8.505355910190537e-23,3.0018903281885747e-22],[5.7034164825326524e-24,7.655138804121537e-24,6.722580046336332e-23]]},{"mean":1000000,"dispersion":0.03,"endpoints":[{"count":500000,"probability":7.350350735333605e-09,"deviance":12.875923173131024,"logSlope":3.133173341534875e-05,"devianceSlope":-6.666333350616359e-05},{"count":1500000,"probability":6.556546289877839e-08,"deviance":6.302140946423994,"logSlope":-1.1777461737245473e-05,"devianceSlope":2.222160495564651e-05}],"modeProbability":2.332582715724839e-06,"fourthDerivativeAbsolute":[[2.3069822046627763e-27,1.3193003775748151e-27,1.0532684082353214e-25],[5.721938065457232e-27,2.664928328283735e-26,6.126272019368149e-26],[4.562790171113717e-28,1.997984462768406e-27,7.314936396357232e-27]]},{"mean":10000,"dispersion":4,"endpoints":[{"count":32,"probability":0.0014441612130714023,"deviance":2.3719666559197696,"logSlope":-0.023370478639538252,"devianceSlope":-0.015514281509099481},{"count":64,"probability":0.0008592793455809033,"deviance":2.027965810740709,"logSlope":-0.011720802427623654,"devianceSlope":-0.00774728145630423}],"modeProbability":0.07071023618382172,"fourthDerivativeAbsolute":[[1.8363885551335848e-08,6.680608438741984e-08,2.3244261561848235e-07],[2.6933100111949037e-09,9.253085377816787e-09,3.023748357989543e-08],[6.889729961199307e-10,2.2680362985807583e-09,7.069303900789016e-09]]},{"mean":10000,"dispersion":4,"endpoints":[{"count":1000,"probability":0.00010695553587425191,"deviance":0.7012419265588743,"logSlope":-0.0007749059218890022,"devianceSlope":-0.00044993813540429746},{"count":30000,"probability":4.0414957331093865e-06,"deviance":0.45068552249464555,"logSlope":-4.9999583337962875e-05,"devianceSlope":3.333277778780845e-05}],"modeProbability":0.07071023618382172,"fourthDerivativeAbsolute":[[1.4860565275238815e-15,2.8410821113037603e-15,4.597241938992425e-15],[3.385878977535738e-21,1.4434442395931425e-21,2.7832459542384585e-22],[1.5155253500527524e-22,6.53595747425141e-24,2.070040109601678e-23]]}]
        """#
        let cases = try JSONDecoder().decode([Reference].self,from: Data(json.utf8))
        for row in cases {
            let size = 1/row.dispersion
            let nodes = try row.endpoints.map { e in
                let d = try VivoOmicsNegativeBinomial.unitDeviance(count: e.count,mean: row.mean,dispersion: row.dispersion)
                let p = exp(VivoOmicsNBAdaptiveMoments.logProbability(count: Double(e.count),mean: row.mean,size: size,deviance: d))
                let slope = VivoOmicsNBAdaptiveMoments.logProbabilitySlope(count: Double(e.count),mean: row.mean,size: size)
                #expect(abs(p/e.probability-1) < 1e-11)
                #expect(abs(slope-e.logSlope) < 1e-13)
                return VivoOmicsNBAdaptiveMoments.Node(count: e.count,probability: p,deviance: d,logSlope: slope,devianceSlope: e.devianceSlope)
            }
            let bound = VivoOmicsNBAdaptiveMoments.fourthDerivativeBounds(left: nodes[0],right: nodes[1],size: size,mean: row.mean,modeProbability: row.modeProbability)
            for values in row.fourthDerivativeAbsolute {
                for i in 0...2 { #expect(values[i] <= bound[i]*(1+1e-12)) }
            }
        }
    }
}
