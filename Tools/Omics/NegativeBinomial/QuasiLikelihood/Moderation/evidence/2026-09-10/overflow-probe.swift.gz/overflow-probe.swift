import Foundation
@main struct Probe {
    static func main() {
        do {
            let fit = try VivoOmicsPrecisionLowess.fit(x: [0,1,2], y: [1e308,-1e308,1e308], weights: [1,2,3], span: 0.6)
            print(fit.fitted.allSatisfy(\.isFinite) ? "finite-fit" : "nonfinite-fit-returned")
        } catch { print("explicit-error: \(error)") }
    }
}
