from pathlib import Path
import json,gzip,hashlib,tarfile
r=Path(__file__).parent;old=Path('/Users/n/numivivo-replogle2020-20260911/target-kernel')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((r/'completion.json').read_text())['exitCode']==0
frozen=json.loads((r/'native/prediction-freeze.json').read_text());assert frozen['folds']==150 and frozen['commands']==601 and frozen['allNativeReplaysPassed']
checks=json.loads((r/'checks/checks.json').read_text());assert checks['comparedVectors']==750
reports=[]
for f in sorted((r/'native/folds').glob('*/*/report.json.gz')):
 relative=f.relative_to(r/'native');prior=old/relative
 a=gzip.decompress(f.read_bytes());b=gzip.decompress(prior.read_bytes());assert a==b,str(relative)
 reports.append(dict(path=str(relative),decodedSHA256=hashlib.sha256(a).hexdigest(),bytes=len(a),freshStoredSHA256=sha(f),priorStoredSHA256=sha(prior)))
assert len(reports)==150
summary=json.loads((r/'checks/summary.json').read_text());primary=[x for x in summary if x['panel']=='allGenes']
result=dict(status='PASS numerical and complete execution; no change from fixed predictor',folds=150,nativeCommands=601,comparedVectors=750,byteIdenticalReports=150,primary=primary,maximumPredictionError=checks['maximumPredictionError'],maximumWeightError=checks['maximumWeightError'],reports=reports,scope='Development reuse; all selected lambda 1; no new biological gain')
(r/'result.json').write_text(json.dumps(result,indent=2))
# Bind every retained artifact, including failed setup and full predictions.
files=[]
for p in sorted(r.rglob('*')):
 if p.is_file() and p.name not in ['external-manifest.json','evidence.tar.gz'] and '__pycache__' not in p.parts:
  files.append(dict(path=str(p.relative_to(r)),bytes=p.stat().st_size,sha256=sha(p)))
(r/'external-manifest.json').write_text(json.dumps(dict(root=str(r),files=files),indent=2))
with tarfile.open(r/'evidence.tar.gz','w:gz') as t:
 for e in files:
  p=r/e['path'];rel=p.relative_to(r)
  # Large native inputs/models/prediction arrays remain externally hash-bound.
  if ('native' in rel.parts or 'native-attempt-1' in rel.parts) and (p.name.endswith('.gz') or 'scratch' in rel.parts):continue
  if p.suffix in ['.json','.py','.log']:t.add(p,arcname=str(rel))
 t.add(r/'external-manifest.json',arcname='external-manifest.json')
print(json.dumps({k:v for k,v in result.items() if k not in ['reports','primary']}));print('archiveBytes', (r/'evidence.tar.gz').stat().st_size)
