from pathlib import Path
import json,subprocess,time,os
r=Path(__file__).parent
pid=json.loads((r/'native-process.json').read_text())['pid']
while not (r/'native/prediction-freeze.json').exists():
 try:os.kill(pid,0)
 except ProcessLookupError:
  (r/'completion.json').write_text(json.dumps(dict(status='native-stopped-without-freeze',pid=pid,unix=time.time())))
  raise SystemExit(1)
 time.sleep(5)
args=['/Users/n/numivivo-mnn-wide-20260912/evaluation-py/bin/python',str(r/'source/Replogle2020/check_target_kernel.py'),'/Users/n/numivivo-replogle2020-20260911','--native',str(r/'native'),'--descriptors','/Users/n/numivivo-replogle2020-20260911/identity-author-analysis/descriptors','--out',str(r/'checks')]
with (r/'checks.log').open('w') as f:p=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
(r/'completion.json').write_text(json.dumps(dict(status='checker-completed',exitCode=p.returncode,unix=time.time())))
raise SystemExit(p.returncode)
