"""Bind new preparation inputs/outputs to the previous qualified archive."""
from pathlib import Path
import argparse,gzip,hashlib,json
p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('archive',type=Path);v=p.parse_args();r=v.root;a=v.archive

def sha(p):
 d=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):d.update(b)
 return d.hexdigest()

m=json.loads((a/'manifest.json').read_text());rec=next(x for x in m['records'] if x['sourcePath'].endswith('source-map.json'))
raw=gzip.decompress((a/rec['storedPath']).read_bytes()) if rec['gzipEncoded'] else (a/rec['storedPath']).read_bytes()
assert hashlib.sha256(raw).hexdigest()==rec['sourceSHA256']
source_map=json.loads(raw)['files'];external=json.loads((r/'external-artifacts.json').read_text());verified=[]
for name in ['selected-plan.json','prepared-complete/inventory.json','selected-checks.json','paper-authority.json','external-artifacts.json']:
 expected=source_map[name]['SHA256'];assert sha(r/name)==expected;verified.append(dict(path=name,SHA256=expected))
rec=next(x for x in external['records'] if x['path'].endswith('/selected-reference.npz'));assert sha(r/'selected-reference.npz')==rec['SHA256'];verified.append(dict(path='selected-reference.npz',SHA256=rec['SHA256']))
checks=json.loads((r/'training-preparation/checks.json').read_text());assert sha(r/'prepare_training.py')==checks['scriptSHA256']
for x in checks['files']:
 f=r/'training-preparation'/x['path'];assert f.stat().st_size==x['bytes'] and sha(f)==x['SHA256']
value=dict(status='passed',priorArchiveManifestSHA256=sha(a/'manifest.json'),inputs=verified,outputFilesVerified=len(checks['files']),executedScriptSHA256=checks['scriptSHA256'],checksSHA256=sha(r/'training-preparation/checks.json'),bindingScriptSHA256=sha(Path(__file__)))
(r/'training-preparation/input-output-binding.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))
