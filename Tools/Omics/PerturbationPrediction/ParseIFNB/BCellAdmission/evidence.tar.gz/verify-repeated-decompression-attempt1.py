from pathlib import Path
import json,collections,hashlib
import numpy as np
s=Path(__file__).parent
a=json.loads((s/'audit.json').read_text());r=json.loads((s/'source-roster.json').read_text());z=np.load(s/'source-roster-codes.npz');rows=np.load(s/'selected-labels.npz');cats=json.loads((s/'label-categories.json').read_text())['categories']
np.testing.assert_array_equal(rows['originalSelectedRows'],z['selected'])
counts=collections.Counter();chosen=[]
for row,label in zip(rows['originalSelectedRows'],rows['cellType']):
 donor=r['categories']['donor'][int(z['donor'][row])];condition=r['categories']['cytokine'][int(z['cytokine'][row])];name=cats[int(label)];assert condition in ['PBS','IFN-beta'];counts[donor,condition,name]+=1
 if name in ['B Intermediate/Memory','B Naive']:chosen.append(int(row))
np.testing.assert_array_equal(chosen,rows['bCellSourceRows']);assert len(chosen)==a['bCellRows']==72446
for donor,conditions in a['sourceLabelCounts'].items():
 for condition,labels in conditions.items():
  assert sum(labels.values())==r['counts'][donor][condition]
  for name,n in labels.items():assert n==counts[donor,condition,name]
  assert a['bCellDonorCounts'][donor][condition]==sum(counts[donor,condition,k] for k in ['B Intermediate/Memory','B Naive'])
panel=json.loads((s/'model-metadata.json').read_text())['featureIDs'];features=r['sourceFeatures'];common={x[7:] for x in panel}&set(features)
assert len(common)==a['exactCorrespondences']==11600
assert {x['modelID'][7:] for x in a['missing']}=={x[7:] for x in panel}-set(features)
for x in a['mapping']:assert panel[x['modelIndex']]==x['modelID'] and features[x['sourceIndex']]==x['sourceSymbol']==x['modelID'][7:]
assert hashlib.sha256((s/'selected-labels.npz').read_bytes()).hexdigest()==a['rowCodesSHA256']
(s/'verification.json').write_text(json.dumps({'status':'pass-independent-scalar-all-selected-rows-and-exact-feature-map','sourceRows':len(rows['originalSelectedRows']),'selectedBCells':len(chosen),'donorConditionLabelCounts':len(a['sourceLabelCounts'])*2*len(cats),'exactGenes':len(common),'missingGenes':len(panel)-len(common)},indent=2)+'\n')
print('PASS all 725031 row identities, 432 label counts and 11800 feature decisions')
