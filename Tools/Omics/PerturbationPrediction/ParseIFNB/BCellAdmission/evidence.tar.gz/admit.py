from pathlib import Path
import sys,json,hashlib,time,subprocess,collections
import numpy as np,h5py
s=Path(__file__).parent;old=Path('/Users/home/numivivo-parse-ifnb-20260911');repo=Path('/Users/home/numivivo-expression-memory-20260911')
sys.path.insert(0,str(old))
from remote_io import Remote,URL,ETAG,SIZE
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def gitjson(path):return json.loads(subprocess.check_output(['git','-C',str(repo),'show','HEAD:'+path]))
m=gitjson('Tools/Omics/PerturbationPrediction/ParseIFNB/evidence/2026-09-11-preparation/contents.json')
for name in ['sources/roster.json','sources/roster-codes.npz']:assert sha(old/name)==m['members'][name]['SHA256']
meta=Path('/Users/home/numivivo-study-heldout-20260912/cohort-metadata.json');modelManifest=gitjson('Tools/Omics/PerturbationPrediction/StudyContextKernel/manifest.json')
assert sha(meta)==modelManifest['members']['source-metadata.json']
roster=json.loads((old/'sources/roster.json').read_text());panel=json.loads(meta.read_text())['featureIDs'];source=roster['sourceFeatures'];assert len(panel)==11800 and len(source)==40352 and len(set(source))==len(source)
allowed=['B Intermediate/Memory','B Naive'];cats=json.loads((s/'label-categories.json').read_text())
assert all(x in cats['categories'] for x in allowed)
freeze={'createdUnix':time.time(),'labels':allowed,'rule':'Literal B Intermediate/Memory and B Naive within all original PBS/IFN-beta source rows; preserve all donors, treatments and rows satisfying metadata rule. Plasmablast is retained separately in roster, not silently called B Naive.','sourceURL':URL,'ETag':ETAG,'sourceBytes':SIZE,'sourceRosterSHA256':sha(old/'sources/roster.json'),'sourceCodesSHA256':sha(old/'sources/roster-codes.npz'),'categorySHA256':sha(s/'label-categories.json'),'modelFeatureMetadataSHA256':sha(meta),'scriptSHA256':sha(Path(__file__)),'status':'metadata-only-before-celltype-code-read','outcomesUsed':False,'predictionAuthorized':False,'doseReagent':'Unresolved; do not fit or score'}
(s/'freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
f=Remote()
try:
 with h5py.File(f,'r') as h:
  assert h['obs/cell_type/categories'].asstr()[:].tolist()==cats['categories']
  codes=h['obs/cell_type/codes'][:];assert codes.shape==(9697974,) and codes.min()>=0 and codes.max()<len(cats['categories'])
finally:(s/'label-ranges.json').write_text(json.dumps(f.requests,indent=2)+'\n')
r=np.load(old/'sources/roster-codes.npz');selected=r['selected'];assert len(selected)==725031
all_labels=codes[selected];keep=np.isin(all_labels,[cats['categories'].index(x) for x in allowed]);rows=selected[keep]
np.savez_compressed(s/'selected-labels.npz',originalSelectedRows=selected,cellType=all_labels,bCellSourceRows=rows)
counts={};complete={}
for d,name in enumerate(roster['categories']['donor']):
 counts[name]={};complete[name]={}
 for condition in ['PBS','IFN-beta']:
  c=roster['categories']['cytokine'].index(condition);mask=(r['donor'][selected]==d)&(r['cytokine'][selected]==c)
  complete[name][condition]={label:int(np.count_nonzero(mask&(all_labels==i))) for i,label in enumerate(cats['categories'])}
  counts[name][condition]=int(np.count_nonzero(mask&keep))
  assert sum(complete[name][condition].values())==roster['counts'][name][condition]
lookup={v:i for i,v in enumerate(source)};mapping=[];missing=[]
for i,name in enumerate(panel):
 assert name.startswith('symbol|');symbol=name[len('symbol|'):]
 if symbol in lookup:mapping.append({'modelIndex':i,'modelID':name,'sourceIndex':lookup[symbol],'sourceSymbol':symbol})
 else:missing.append({'modelIndex':i,'modelID':name})
assert len(mapping)+len(missing)==11800 and len(set(x['sourceIndex'] for x in mapping))==len(mapping)
report={'status':'complete-metadata-audit-no-prediction','originalCohortCells':len(selected),'bCellRows':len(rows),'sourceLabelCounts':complete,'bCellDonorCounts':counts,'donors':len(counts),'allDonorsHaveBothConditions':all(all(v>0 for v in x.values()) for x in counts.values()),'modelFeatures':len(panel),'exactCorrespondences':len(mapping),'missingFeatures':len(missing),'mapping':mapping,'missing':missing,'predictionFitted':False,'predictionScored':False,'modelPanelChanged':False,'scope':'Source-provided annotation subset and exact symbol compatibility only; labels not authoritative. No count aggregation, model fitting or response-score inspection. Dose/reagent and complete model compatibility still required.','freezeSHA256':sha(s/'freeze.json'),'rowCodesSHA256':sha(s/'selected-labels.npz')}
(s/'audit.json').write_text(json.dumps(report,indent=2)+'\n');print({k:v for k,v in report.items() if k not in ['sourceLabelCounts','mapping','missing']})
