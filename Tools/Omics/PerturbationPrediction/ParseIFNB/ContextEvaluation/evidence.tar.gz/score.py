from pathlib import Path
import json,hashlib,math,time
import numpy as np
s=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
pr=read(s/'protocol.json');ex=read(s/'execution.json');fr=read(s/'prediction-freeze.json')
assert sha(s/'protocol.json')==ex['protocolSHA256']=='85f84a58b47f811779013d26ac5a90d4d3cde913974d388cef8f4700cf77d44d'
assert sha(s/'execution.json')==fr['executionSHA256'] and sha(s/'native/Parse.json')==fr['outputSHA256']
assert sha(s/'inputs/Parse.json')==ex['inputs']['Parse.json']
a=read(s/'inputs/Parse.json');b=read(s/'native/Parse.json');panel=read(s/'panel-freeze.json')
assert a['featureIDs']==b['featureIDs']==panel['featureIDs'] and a['queryDonorIDs']==b['queryDonorIDs']==['Parse:'+d for d in pr['queryDonors']]
assert read(s/'verification.json')['status']=='pass-all-inner-losses-weights-and-predictions'
root=Path('/Users/n/numivivo-parse-logcpm-20260912');source=Path('/Users/n/numivivo-parse-bcell-counts-20260912')
# Check exact frozen projection against original feature symbols, independent of prepared query arrays.
p=read(source/'donor-plans/Donor1/plan.json');features=p['metadata']['features'];idx=panel['parseFeatureIndices']
print('feature keys',list(features[0]),flush=True)
assert len(idx)==len(set(idx))==11600
# Source feature IDs already bound to normalization outputs; symbols identify the frozen exact panel.
for j,i in enumerate(idx):
 f=features[i];symbol=f.get('symbol',f.get('name'))
 assert 'symbol|'+symbol==panel['featureIDs'][j],(j,f)
rows=[];maxdiff=0.;targets=[]
for k,d in enumerate(pr['queryDonors']):
 path=root/d/'native.json';assert sha(path)==ex['sourceOutputs'][str(path)]
 r=read(path);assert r['groupIDs']==['IFN-beta','PBS'] and r['featureIDs']==[f['id'] for f in features]
 target=np.array(r['means'][0])[idx];control=np.array(r['means'][1])[idx];targets.append(target)
 np.testing.assert_array_equal(control,a['queryControls'][k])
 vectors={'candidate':b['predictedTreated'][k],'trainingMean':b['trainingMeanPredictions'][k],'noChange':control.tolist()};metrics={}
 for name,v in vectors.items():
  value=float(np.sqrt(np.mean((np.array(v)-target)**2)))
  independent=math.sqrt(math.fsum((float(x)-float(y))**2 for x,y in zip(v,target))/11600)
  maxdiff=max(maxdiff,abs(value-independent));assert abs(value-independent)<1e-12
  metrics[name]=value
 rows.append(dict(donor=d,rmse=metrics))
means={name:math.fsum(r['rmse'][name] for r in rows)/12 for name in vectors}
gains={name:1-means['candidate']/means[name] for name in ['trainingMean','noChange']}
result=dict(createdUnix=time.time(),status='PASS' if all(v>=.05 for v in gains.values()) else 'FAIL',donors=rows,meanRMSE=means,gainFraction=gains,maximumIndependentScoreDifference=maxdiff,protocolSHA256=sha(s/'protocol.json'),predictionFreezeSHA256=sha(s/'prediction-freeze.json'),scorerSHA256=sha(Path(__file__)),predictionScored=True,claim='External-study transfer stress test only; participant independence and matched exposure unverified; candidate remains unpromoted.')
np.save(s/'targets.npy',np.array(targets),allow_pickle=False);result['targetsSHA256']=sha(s/'targets.npy')
with (s/'scores.json').open('x') as f:json.dump(result,f,indent=2)
print(json.dumps({k:v for k,v in result.items() if k!='donors'},indent=2))
