from pathlib import Path
import json,hashlib,subprocess,time
import numpy as np
s=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pr=json.loads((s/'protocol.json').read_text())
assert sha(s/'protocol.json')=='85f84a58b47f811779013d26ac5a90d4d3cde913974d388cef8f4700cf77d44d'
for name,h in pr['dependencies'].items():
 p=s/Path(name).name
 if p.name!='protocol.json':assert sha(p)==h
panel=json.loads((s/'panel-freeze.json').read_text());meta=json.loads((s/'source-metadata.json').read_text());a=np.load(s/'source-cohorts.npz')
assert meta['featureIDs']==panel['featureIDs'] and len(meta['featureIDs'])==11600
root=Path('/Users/n/numivivo-parse-logcpm-20260912');complete=json.loads((root/'complete.json').read_text());assert [x['donor'] for x in complete['donors']]==pr['queryDonors']
queries=[];bindings={}
for d in complete['donors']:
 p=root/d['donor']/'native.json';assert sha(p)==d['nativeSHA256'];r=json.loads(p.read_text());assert r['groupIDs']==['IFN-beta','PBS']
 # Only PBS values enter prediction input. Full means already inspected for engineering.
 queries.append([r['means'][1][i] for i in panel['parseFeatureIndices']]);bindings[str(p)]=sha(p)
studies=pr['trainingStudies']
obj=dict(featureIDs=meta['featureIDs'],queryStudy='Parse',trainingDonorIDs=[d for t in studies for d in meta['studies'][t]],trainingStudies=[t for t in studies for d in meta['studies'][t]],queryDonorIDs=['Parse:'+d for d in pr['queryDonors']],queryControls=queries,controls=np.concatenate([a[t+'_controls'] for t in studies]).tolist(),treated=np.concatenate([a[t+'_treated'] for t in studies]).tolist())
assert len(obj['trainingDonorIDs'])==75
(s/'inputs').mkdir();(s/'native').mkdir();p=s/'inputs/Parse.json';p.write_text(json.dumps(obj,separators=(',',':')))
execution=dict(protocolSHA256=sha(s/'protocol.json'),inputs={'Parse.json':sha(p)},sourceOutputs=bindings,driverSHA256=sha(Path(__file__)),verifierSHA256=sha(s/'verify.py'),binarySHA256=sha(s/'context-kernel'))
(s/'execution.json').write_text(json.dumps(execution,indent=2)+'\n')
start=time.time()
with (s/'native/Parse.log').open('xb') as f:subprocess.run([str(s/'context-kernel'),str(p),str(s/'native/Parse.json')],stdout=f,stderr=f,check=True)
(s/'prediction-freeze.json').write_text(json.dumps(dict(createdUnix=time.time(),seconds=time.time()-start,executionSHA256=sha(s/'execution.json'),outputSHA256=sha(s/'native/Parse.json'),predictionScored=False),indent=2)+'\n')
print('Native predictions frozen',flush=True)
subprocess.run(['/Users/n/numivivo-integration-reference-py/bin/python',str(s/'verify.py')],check=True)
