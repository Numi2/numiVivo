from pathlib import Path
import json,hashlib
import numpy as np
s=Path(__file__).parent;pr=json.loads((s/'execution.json').read_text());records={};penalties=[.01,.1,1,10,100,None]
def weights(studies):return np.array([1/(len(set(studies))*studies.count(v)) for v in studies])
def reference(x,y,q,studies,lam):
 w=weights(studies);center=w@x;z=(x-center)*np.sqrt(w[:,None]);qc=q-center
 if lam is None:beta=np.broadcast_to(w,(len(q),len(w))).copy()
 else:
  # Independent eigensystem solve, with BLAS matrix products instead of native scalar loops/Cholesky.
  k=z@z.T/x.shape[1];values,vectors=np.linalg.eigh(k);rhs=z@qc.T/x.shape[1];a=vectors@((vectors.T@rhs)/(values[:,None]+lam));b=a.T*np.sqrt(w);beta=w+b-b.sum(1)[:,None]*w
 return np.maximum(0,q+beta@(y-x)),beta
for name,h in pr['inputs'].items():
 p=s/'inputs'/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==h
 a=json.loads(p.read_text());b=json.loads((s/'native'/name).read_text());x=np.array(a['controls']);y=np.array(a['treated']);q=np.array(a['queryControls']);studies=a['trainingStudies'];loss=[]
 for study in sorted(set(studies)):
  keep=np.array([v!=study for v in studies]);test=~keep;row=[]
  for lam in penalties:
   pred,_=reference(x[keep],y[keep],x[test],[v for v,k in zip(studies,keep) if k],lam);row.append(float(np.mean((pred-y[test])**2)))
  loss.append(row)
 means=np.mean(loss,axis=0);best=min(range(len(penalties)),key=lambda i:(means[i],-i));lam=penalties[best];assert b['model'].get('selectedPenalty')==lam
 np.testing.assert_allclose(loss,b['model']['innerStudyMSE'],rtol=1e-10,atol=1e-11)
 pred,beta=reference(x,y,q,studies,lam);base,_=reference(x,y,q,studies,None)
 np.testing.assert_allclose(beta,b['model']['queryResponseWeights'],rtol=1e-9,atol=1e-10)
 np.testing.assert_allclose(pred,b['predictedTreated'],rtol=1e-10,atol=1e-10);np.testing.assert_allclose(base,b['trainingMeanPredictions'],rtol=1e-12,atol=1e-12)
 records[a['queryStudy']]={'predictions':pred.size,'maximumPredictionError':float(np.max(abs(pred-b['predictedTreated']))),'maximumWeightError':float(np.max(abs(beta-b['model']['queryResponseWeights']))),'selectedPenalty':lam,'innerLosses':loss,'minimumResponseWeight':float(beta.min()),'maximumResponseWeight':float(beta.max()),'maximumWeightSumError':float(np.max(abs(beta.sum(1)-1)))}
(s/'verification.json').write_text(json.dumps({'status':'pass-all-inner-losses-weights-and-predictions','folds':records},indent=2)+'\n');print(records)
