from pathlib import Path
import json,copy
import numpy as np
from run_bcells import select_records
s=Path(__file__).parent
run={'lo':10,'hi':14,'selectedOffsets':[1,3],'selectedLo':0,'selectedHi':2}
a=np.array([[10|(2<<32),5],[11|(1<<32),7],[11|(3<<32),2],[13,11]],dtype='<u8')
b,bulk,totals=select_records(run,a.tobytes(),np.array([5,9,0,11],dtype=np.uint64))
expected=np.array([[0|(1<<32),7],[0|(3<<32),2],[1,11]],dtype='<u8');assert b==expected.tobytes();assert bulk.sum()==20 and (bulk[[0,1,3]]==[11,7,2]).all();assert totals.tolist()==[9,11]
zero=dict(run,selectedOffsets=[2],selectedHi=1);data,bulk,totals=select_records(zero,a.tobytes(),np.array([5,9,0,11],dtype=np.uint64));assert data==b'' and not bulk.any() and totals.tolist()==[0]
rejected=[]
for name,change in [('duplicate',{'selectedOffsets':[1,1]}),('descending',{'selectedOffsets':[3,1]}),('out-of-range',{'selectedOffsets':[1,4]}),('wrong-output-size',{'selectedHi':3})]:
 try:select_records(dict(run,**change),a.tobytes(),np.array([5,9,0,11],dtype=np.uint64))
 except AssertionError:rejected.append(name)
 else:raise AssertionError(name)
(s/'tests.json').write_text(json.dumps({'status':'pass','numericalCases':['sparse row remapping with exact counts and columns','selected zero-count row'],'rejections':rejected,'scope':'Transport selection only; biological evidence requires real native execution'},indent=2)+'\n');print('PASS exact sparse selection, zero row and four rejection controls')
