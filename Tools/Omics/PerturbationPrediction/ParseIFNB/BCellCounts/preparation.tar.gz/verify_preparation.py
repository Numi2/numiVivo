from pathlib import Path
import json,hashlib
import numpy as np
s=Path(__file__).parent;old=Path('/Users/home/numivivo-parse-ifnb-20260911');ad=Path('/Users/home/numivivo-parse-bcell-admission-20260912')
parent=json.loads((old/'prepared/plan.json').read_text());manifest=json.loads((s/'donor-plans/manifest.json').read_text());z=np.load(ad/'selected-labels.npz')
reverse={int(v):i for i,v in enumerate(z['originalSelectedRows'])};expected={reverse[int(x)] for x in z['bCellSourceRows']};seen=[];records=0
for part in manifest['parts']:
 d=s/'donor-plans'/part['donor'];p=json.loads((d/'plan.json').read_text());indices=np.load(d/'parent-selected-rows.npy').tolist();runs=json.loads((d/'runs.json').read_text())
 assert set(indices)<=expected and len(indices)==part['cells']
 assert p['metadata']['features']==parent['metadata']['features']
 assert p['metadata']['cells']==[parent['metadata']['cells'][i] for i in indices]
 assert p['rowNonzeros']==[parent['rowNonzeros'][i] for i in indices]
 sampleIDs={x['id'] for x in p['metadata']['samples']};assert len(sampleIDs)==2 and all(x['donorID']==part['donor'] for x in p['metadata']['samples'])
 assert all(c['sampleID'] in sampleIDs for c in p['metadata']['cells'])
 reconstructed=[]
 for r in runs:
  assert r['selectedLo']==len(reconstructed)
  reconstructed.extend(r['lo']+offset for offset in r['selectedOffsets'])
  assert r['selectedHi']==len(reconstructed)
 assert reconstructed==indices
 seen+=indices;records+=sum(p['rowNonzeros'])
assert len(seen)==len(set(seen))==len(expected)==72446 and set(seen)==expected and records==manifest['records']==124909573
(s/'preparation-verification.json').write_text(json.dumps({'status':'pass-complete-independent-parent-projection','cells':len(seen),'records':records,'donors':12,'features':40352,'allMetadataCellsAndCardinalitiesExact':True,'allSelectedRowsExactlyOnce':True,'modelFitted':False},indent=2)+'\n')
print('PASS all 72446 cells and 124909573 planned records against original parent')
