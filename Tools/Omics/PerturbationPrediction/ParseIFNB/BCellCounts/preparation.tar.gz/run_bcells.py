from pathlib import Path
import os,json,hashlib,subprocess,time,concurrent.futures,fcntl,platform
import numpy as np
import run_counts as adapter
from run_donors import check_bundle
ROOT=Path(__file__).parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def select_records(run,data,totals):
 offsets=np.array(run['selectedOffsets'],dtype=np.int64);width=run['hi']-run['lo']
 assert len(offsets)>0 and np.all(np.diff(offsets)>0) and offsets.min()>=0 and offsets.max()<width
 assert run['selectedHi']-run['selectedLo']==len(offsets) and len(totals)==width
 values=np.frombuffer(data,dtype='<u8').reshape(-1,2);oldrows=(values[:,0]&np.uint64(0xffffffff)).astype(np.int64)-run['lo']
 assert np.all((oldrows>=0)&(oldrows<width))
 rowmap=np.full(width,-1,dtype=np.int64);rowmap[offsets]=np.arange(run['selectedLo'],run['selectedHi'])
 mapped=rowmap[oldrows];chosen=values[mapped>=0].copy();mapped=mapped[mapped>=0]
 columns=chosen[:,0]>>np.uint64(32);assert np.all(columns<40352)
 chosen[:,0]=(columns<<np.uint64(32))|mapped.astype(np.uint64)
 bulk=np.zeros(40352,dtype=np.uint64);np.add.at(bulk,columns.astype(np.int64),chosen[:,1])
 return chosen.tobytes(),bulk,np.array(totals)[offsets]
def one(run):
 _,data,_,totals,qc=adapter.one(run);packed,bulk,rowtotals=select_records(run,data,totals)
 a=np.load(ROOT/f"axes/run-{run['run']:04d}.npz");off=np.array(run['selectedOffsets']);nnz=np.diff(a['indptr'])[off]
 sub=dict(sourceGeneCountMismatch=int(np.count_nonzero(nnz!=a['gene_count'][off])),sourceTscpCountMismatch=int(np.count_nonzero(rowtotals!=a['tscp_count'][off])),sourceMinusMatrixTotal=int(a['tscp_count'][off].sum())-int(rowtotals.sum()),sourceMinusMatrixGeneCount=int(a['gene_count'][off].sum())-int(nnz.sum()),selectedCells=len(off),selectedNonzeros=len(packed)//16,selectedTotalCounts=int(rowtotals.sum()),parentRunQC=qc,ranges=qc['ranges'])
 return run,packed,bulk,rowtotals,sub
def main():
 assert ROOT==adapter.ROOT
 assert json.loads((ROOT/'tests.json').read_text())['status']=='pass'
 lock=(ROOT/'controller.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 f=json.loads((ROOT/'donor-plans/manifest.json').read_text());binary=ROOT/'build-pooled/numivivo-omics';assert sha(binary)==f['binarySHA256'];assert f['cells']==72446 and len(f['parts'])==12
 for name,h in f['boundSourceFiles'].items():assert sha(ROOT/name)==h,name
 write(ROOT/'runtime-freeze.json',dict(pid=os.getpid(),platform=platform.platform(),manifestSHA256=sha(ROOT/'donor-plans/manifest.json'),binarySHA256=sha(binary),sourceFiles={p.name:sha(p) for p in ROOT.glob('*.py')},predictionFitted=False))
 for phase in ['ingest','verify']:
  completed=[]
  for part in f['parts']:
   donor=part['donor'];plans=ROOT/'donor-plans'/donor;plan=plans/'plan.json';runs_path=plans/'runs.json'
   assert sha(plan)==part['planSHA256'] and sha(runs_path)==part['runsSHA256']
   runs=json.loads(runs_path.read_text());directory=ROOT/'execution'/phase/donor;directory.mkdir(parents=True,exist_ok=True);pointer=directory/'published.json'
   if pointer.exists():
    rec=json.loads(pointer.read_text());assert rec['status']=='passed' and rec['binarySHA256']==sha(binary) and rec['planSHA256']==sha(plan)
    receipt=check_bundle(ROOT/rec['bundle'],plan,ROOT/rec['independentCounts']);assert sha(ROOT/rec['bundle']/'receipt.json')==rec['receiptSHA256'];assert sha(ROOT/rec['independentCounts'])==rec['independentCountsSHA256'];assert bytes(receipt['stream']['bytes']).hex()==rec['streamSHA256'];completed.append(rec);print('RESUMED',phase,donor,flush=True);continue
   base=json.loads((ROOT/'execution/ingest'/donor/'published.json').read_text()) if phase=='verify' else None
   attempt=directory/('attempt-%03d'%(len(list(directory.glob('attempt-*')))+1));attempt.mkdir()
   bundle=ROOT/base['bundle'] if base else attempt/'native'
   cmd=[str(binary),'singlecell-count-stream-verify',str(bundle)] if base else [str(binary),'singlecell-count-stream-pseudobulk','--plan',str(plan),'--output',str(bundle)]
   groups=sorted(set(x['sample'] for x in runs));counts=np.zeros((2,40352),dtype=np.uint64);totals=np.zeros(part['cells'],dtype=np.uint64);digest=hashlib.sha256();received=0;start=time.time()
   stdout=(attempt/'native.stdout').open('wb');stderr=(attempt/'native.stderr').open('wb');proc=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=stdout,stderr=stderr)
   rec=dict(status='running',phase=phase,donor=donor,pid=proc.pid,binarySHA256=sha(binary),planSHA256=sha(plan),cells=part['cells'],records=part['records'],attempt=str(attempt.relative_to(ROOT)),bundle=str(bundle.relative_to(ROOT)),startedUnix=start);write(attempt/'execution.json',rec)
   try:
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
     pending={};submitted=0
     for wanted in range(len(runs)):
      while submitted<min(len(runs),wanted+8):pending[submitted]=pool.submit(one,runs[submitted]);submitted+=1
      run,data,bulk,rowtotals,qc=pending.pop(wanted).result()
      if base:
       old=json.loads((ROOT/base['attempt']/f"run-{run['run']:04d}.json").read_text());assert [(x['start'],x['stop'],x['SHA256']) for x in old['ranges']]==[(x['start'],x['stop'],x['SHA256']) for x in qc['ranges']]
      proc.stdin.write(data);digest.update(data);received+=len(data);counts[groups.index(run['sample'])]+=bulk;totals[run['selectedLo']:run['selectedHi']]=rowtotals;write(attempt/f"run-{run['run']:04d}.json",qc)
      write(ROOT/'progress.json',dict(phase=phase,donor=donor,sourceRunsCompleted=wanted+1,sourceRuns=len(runs),selectedCellsStreamed=run['selectedHi'],streamBytes=received,updatedUnix=time.time(),pid=os.getpid()))
      if wanted%25==0:print('STREAM',phase,donor,wanted+1,len(runs),received,flush=True)
    proc.stdin.close();code=proc.wait();stdout.close();stderr.close();assert code==0,(attempt/'native.stderr').read_text()[-2000:]
    independent=attempt/'independent-counts.npz';np.savez_compressed(independent,groups=np.array(groups),counts=counts,cellTotals=totals)
    receipt=check_bundle(bundle,plan,independent);assert received==part['records']*16==receipt['streamBytes'] and digest.hexdigest()==bytes(receipt['stream']['bytes']).hex()
    if base:assert digest.hexdigest()==base['streamSHA256']
    rec.update(status='passed',seconds=time.time()-start,streamBytes=received,streamSHA256=digest.hexdigest(),totalCounts=int(totals.sum()),independentCounts=str(independent.relative_to(ROOT)),independentCountsSHA256=sha(independent),receiptSHA256=sha(bundle/'receipt.json'));write(attempt/'execution.json',rec);write(pointer,rec);completed.append(rec);print('COMPLETE',phase,donor,part['cells'],part['records'],flush=True)
   except BaseException as error:
    rec.update(status='failed',errorType=type(error).__name__,error=str(error),streamedBytes=received)
    try:
     if proc.stdin and not proc.stdin.closed:proc.stdin.close()
    except OSError:pass
    proc.wait();write(attempt/'execution.json',rec);raise
   finally:stdout.close();stderr.close()
  assert len(completed)==12 and sum(x['cells'] for x in completed)==72446 and sum(x['records'] for x in completed)==f['records']
  write(ROOT/(phase+'-complete.json'),dict(status='passed',parts=completed,cells=72446,records=f['records'],manifestSHA256=sha(ROOT/'donor-plans/manifest.json')))
 write(ROOT/'complete.json',dict(status='passed-all-native-ingestions-and-replays',cells=72446,records=f['records'],predictionFitted=False,predictionScored=False))
if __name__=='__main__':main()
