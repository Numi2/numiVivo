from pathlib import Path
import numpy as np,json,hashlib,subprocess,shutil,time
repo=Path('/Users/home/numivivo-expression-memory-20260911');old=Path('/Users/home/numivivo-parse-ifnb-20260911');ad=Path('/Users/home/numivivo-parse-bcell-admission-20260912');s=Path(__file__).parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def content(path):return json.loads(subprocess.check_output(['git','-C',str(repo),'show','HEAD:'+path]))
pre=content('Tools/Omics/PerturbationPrediction/ParseIFNB/evidence/2026-09-11-preparation/contents.json')
mem=content('Tools/Omics/CountStore/Stream/Memory/evidence/2026-09-11/contents.json')
for name in ['prepared/plan.json','prepared/runs.json','sources/asset-head.json']:
 assert sha(old/name)==pre['members'][name]['SHA256']
assert sha(old/'build-pooled/numivivo-omics')==mem['members']['runtime/corrected/numivivo-omics']['SHA256']
admanifest=content('Tools/Omics/PerturbationPrediction/ParseIFNB/BCellAdmission/manifest.json')
assert sha(ad/'selected-labels.npz')==admanifest['members']['selected-labels.npz']
parent=json.loads((old/'prepared/plan.json').read_text());runs=json.loads((old/'prepared/runs.json').read_text());labels=np.load(ad/'selected-labels.npz')
indices=np.searchsorted(labels['originalSelectedRows'],labels['bCellSourceRows']);assert np.array_equal(labels['originalSelectedRows'][indices],labels['bCellSourceRows']) and len(indices)==72446
selected=set(map(int,indices));samples={x['id']:x for x in parent['metadata']['samples']};donors=sorted(set(x['donorID'] for x in samples.values()))
(s/'donor-plans').mkdir();parts=[];seen=[]
for donor in donors:
 chosen=[];parts_runs=[]
 for run in runs:
  if samples[run['sample']]['donorID']!=donor:continue
  offsets=[i-run['lo'] for i in range(run['lo'],run['hi']) if i in selected]
  if not offsets:continue
  part=dict(run,selectedOffsets=offsets,selectedLo=len(chosen),selectedHi=len(chosen)+len(offsets));parts_runs.append(part);chosen += [run['lo']+i for i in offsets]
 assert chosen and len(set(chosen))==len(chosen)
 metadata=dict(parent['metadata'],id=parent['metadata']['id']+'-Bcell-'+donor,cells=[parent['metadata']['cells'][i] for i in chosen],samples=[x for x in samples.values() if x['donorID']==donor])
 declaration=json.loads(parent['sourceDeclaration']);declaration.update(parentPlanSHA256=sha(old/'prepared/plan.json'),subset='Literal B Intermediate/Memory and B Naive in frozen Parse BCellAdmission',subsetRowSHA256=sha(ad/'selected-labels.npz'),partitionDonor=donor)
 plan=dict(parent,metadata=metadata,sourceDeclaration=json.dumps(declaration,sort_keys=True),rowNonzeros=[parent['rowNonzeros'][i] for i in chosen])
 if 'rowTotals' in parent:plan['rowTotals']=[parent['rowTotals'][i] for i in chosen]
 d=s/'donor-plans'/donor;d.mkdir();(d/'plan.json').write_text(json.dumps(plan,separators=(',',':')));(d/'runs.json').write_text(json.dumps(parts_runs,separators=(',',':')));np.save(d/'parent-selected-rows.npy',np.array(chosen,dtype='<u8'))
 parts.append({'donor':donor,'cells':len(chosen),'records':sum(plan['rowNonzeros']),'runs':len(parts_runs),'planSHA256':sha(d/'plan.json'),'runsSHA256':sha(d/'runs.json'),'rowMapSHA256':sha(d/'parent-selected-rows.npy')});seen+=chosen
assert sorted(seen)==sorted(selected) and len(parts)==12
for folder in ['axes','chunks','sources','prepared','build-pooled']:(s/folder).mkdir()
bound={}
for run in runs:
 for name in [f"axes/run-{run['run']:04d}.npz",f"chunks/run-{run['run']:04d}.json"]:
  assert sha(old/name)==pre['members'][name]['SHA256'];shutil.copy2(old/name,s/name);bound[name]=sha(s/name)
for name in ['sources/asset-head.json','prepared/runs.json','build-pooled/numivivo-omics']:shutil.copy2(old/name,s/name);bound[name]=sha(s/name)
for name in ['run_counts.py','run_donors.py']:
 data=subprocess.check_output(['git','-C',str(repo),'show','HEAD:Tools/Omics/PerturbationPrediction/ParseIFNB/'+name]);(s/name).write_bytes(data);bound[name]=sha(s/name)
manifest={'status':'frozen-complete-source-labeled-B-cell-count-selection','createdUnix':time.time(),'cells':len(seen),'records':sum(x['records'] for x in parts),'features':40352,'parts':parts,'parentPlanSHA256':sha(old/'prepared/plan.json'),'selectionSHA256':sha(ad/'selected-labels.npz'),'binarySHA256':sha(s/'build-pooled/numivivo-omics'),'boundSourceFiles':bound,'scope':'Native ingestion and replay of selected B-cell counts only; no prediction. Retain every selected source row, donor, condition and all RNA features. Source label and QC discrepancies remain explicit.'}
(s/'donor-plans/manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print({k:v for k,v in manifest.items() if k not in ['parts','boundSourceFiles']})
