from pathlib import Path
import hashlib,json,tarfile,sys,platform
from importlib.metadata import version
r=Path(__file__).parent
read=lambda p:json.loads(p.read_text())
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
assert read(r/'terminal.json')['returnCode']==0 and read(r/'checks-terminal.json')['returnCode']==0
numerical=read(r/'numerical.json');refinement=read(r/'refinement-oracle.json');rows=[]
for c in ['hagai','kang','ding']:
 fit=read(r/'candidate'/c/'report.json');ev=read(r/'evaluation'/c/'checks.json');num=next(x for x in numerical['results'] if x['cohort']==c)
 refine=next(x for x in refinement['results'] if x['cohort']==c)
 rows.append(dict(refinement=refine,cohort=c,cells=ev['cells'],fitSeconds=fit['fitSeconds'],gates=ev['gates'],anchorPrecision=num['anchorPrecision'],anchorRecall=num['anchorRecall'],maximumKernelDeltaError=num['maximumKernelDeltaError'],baselineTypeRecall=ev['baseline'].get('cellTypeRecall'),candidateTypeRecall=ev['metrics'].get('cellTypeRecall')))
summary=dict(status='completed-development-experiment-not-promoted',cohorts=rows,versions={n:version(n) for n in ['numpy','scipy','scikit-learn','anndata','harmonypy','pandas']},python=sys.version,platform=platform.platform())
(r/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files=[];external={}
for p in r.rglob('*'):
 if not p.is_file() or any(x in p.parts for x in ['evaluation-py','__pycache__']):continue
 n=str(p.relative_to(r))
 if p.name in ['evidence.tar.gz','manifest.json']:continue
 if p.suffix=='.npz':external[n]=dict(bytes=p.stat().st_size,SHA256=sha(p));continue
 files.append(p)
with tarfile.open(r/'evidence.tar.gz','w:gz') as t:
 for p in sorted(files):t.add(p,arcname=str(p.relative_to(r)),recursive=False)
m=dict(archiveSHA256=sha(r/'evidence.tar.gz'),members={str(p.relative_to(r)):sha(p) for p in sorted(files)},externalArrays=external,remoteRoot=str(r),scope='All source and JSON results retained; complete numerical and neighbor array witnesses external and hash-bound. Original source cohort dependency is separate.')
(r/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps(summary));print('archive bytes',(r/'evidence.tar.gz').stat().st_size)
