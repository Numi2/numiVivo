from pathlib import Path
import ctypes as C,json,hashlib
import numpy as np
r=Path(__file__).parent;lib=C.CDLL(str(r/'libHybrid.dylib'));f=lib.exact_refine
D=C.POINTER(C.c_double);I=C.POINTER(C.c_int64);U=C.POINTER(C.c_uint32);B=C.POINTER(C.c_uint8)
f.restype=C.c_int;f.argtypes=[D,U,B,C.c_uint32,C.c_uint32,C.c_uint32,C.c_uint32,C.c_uint64,I,D,C.c_uint64,C.POINTER(C.c_uint64)]
x=np.array([[0,0],[0,0],[1,0],[2,0],[0,0],[1,0],[1,0],[2,0]],dtype=np.float64);levels=np.array([0]*4+[1]*4,dtype=np.uint32)
mask=np.zeros((2,8),dtype=np.uint8);mask[0,4:]=1;mask[1,:4]=1
ids=np.full((2,8,2),-1,dtype=np.int64);ds=np.zeros_like(ids,dtype=np.float64)
def run(a=x,m=mask,budget=1000,capacity=32):
 count=C.c_uint64();status=f(a.ctypes.data_as(D),levels.ctypes.data_as(U),m.ctypes.data_as(B),8,2,2,2,budget,ids.ctypes.data_as(I),ds.ctypes.data_as(D),capacity,C.byref(count));return status,count.value
assert run()==(0,32)
for direction,row in zip(*np.where(mask)):
 eligible=np.flatnonzero(levels<levels[row] if direction==0 else levels>levels[row]);values=np.abs(x[eligible]-x[row]).sum(1);order=np.lexsort((eligible,values))[:2]
 assert np.array_equal(ids[direction,row],eligible[order]) and np.array_equal(ds[direction,row],values[order])
bad=mask.copy();bad[0,0]=1
nonfinite=x.copy();nonfinite[0,0]=np.nan
codes=dict(budget=run(budget=1)[0],zeroBudget=run(budget=0)[0],shortOutput=run(capacity=1)[0],boundaryQuery=run(m=bad)[0],nonfinite=run(a=nonfinite)[0])
assert codes==dict(budget=2,zeroBudget=1,shortOutput=1,boundaryQuery=1,nonfinite=4)
with (r/'refinement-tests.json').open('x') as out:json.dump(dict(status='passed',tieAndEligibleExact=True,errors=codes,sourceSHA256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),librarySHA256=hashlib.sha256((r/'libHybrid.dylib').read_bytes()).hexdigest()),out,indent=2)
print('PASS exact refinement ties, eligibility and failure statuses')
