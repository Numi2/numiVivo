"""Check the complete distance-tail rule and exhaustive outputs independently."""
from pathlib import Path
import json,hashlib
import numpy as np
from scipy.spatial.distance import cdist
r=Path(__file__).parent;old=Path('/Users/n/numivivo-mnn-wide-20260912');source=Path('/Users/n/numivivo-native-mnn-20260910')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads((r/'candidate/outputs-frozen.json').read_text());prior=json.loads((old/'candidate/outputs-frozen.json').read_text());results=[]
for c in ['hagai','kang','ding']:
 for root,freeze in [(r,f),(old,prior)]:assert sha(root/'candidate'/c/'matching.npz')==freeze['files'][c+'/matching.npz']
 a_file=np.load(r/'candidate'/c/'matching.npz');a={k:a_file[k] for k in a_file.files};a_file.close();before_file=np.load(old/'candidate'/c/'matching.npz');before={k:before_file[k] for k in before_file.files};before_file.close();report=json.loads((r/'candidate'/c/'report.json').read_text());native=report['native'][0]
 inputs=json.loads((r/'candidate/freeze.json').read_text())['inputs']
 for name in ['pca/scores.bin','mnn/report.json']:assert sha(source/c/name)==inputs[c+'/'+name]
 raw=np.fromfile(source/c/'pca/scores.bin',dtype=[('row','<u4'),('column','<u4'),('value','<f8')]);x=raw['value'].reshape(-1,20);norm=np.sqrt(np.sum(x*x,axis=1));unit=np.divide(x,norm[:,None],out=np.zeros_like(x),where=norm[:,None]>0)
 # Match authored sequential norm arithmetic rather than NumPy tree reduction.
 norm=np.zeros(len(x))
 for j in range(20):norm+=x[:,j]*x[:,j]
 norm=np.sqrt(norm);unit=np.divide(x,norm[:,None],out=np.zeros_like(x),where=norm[:,None]>0)
 meta=json.loads((source/c/'mnn/report.json').read_text());batch=np.array(meta['cellLevels']);rank=np.empty(len(x),dtype=np.int64);rank[np.argsort(batch,kind='stable')]=np.arange(len(x));checked=0;maximum=0.
 for direction in range(2):
  selected=[]
  for level in range(int(batch.max())+1):
   group=np.flatnonzero((batch==level)&(before['indices'][direction,:,0]>=0))
   if not len(group):continue
   ordered=sorted(map(int,group),key=lambda i:(-float(before['distances'][direction,i,-1]),i));chosen=ordered[:(len(group)+19)//20];selected.extend(chosen)
   eligible=np.flatnonzero(batch<level if direction==0 else batch>level)
   for start in range(0,len(chosen),32):
    queries=np.array(chosen[start:start+32]);dist=cdist(unit[queries],unit[eligible],metric='cityblock')
    for q,values in zip(queries,dist):
     take=np.lexsort((rank[eligible],values))[:20];ids=eligible[take]
     assert np.array_equal(ids,a['indices'][direction,q]),(c,direction,int(q))
     maximum=max(maximum,float(np.max(abs(values[take]-a['distances'][direction,q]))));checked+=1
  assert sorted(selected)==native['selectedRows'][direction]
  untouched=np.ones(len(x),dtype=bool);untouched[selected]=False
  assert np.array_equal(a['indices'][direction,untouched],before['indices'][direction,untouched])
  assert np.array_equal(a['distances'][direction,untouched],before['distances'][direction,untouched])
 assert checked==native['refinedQueries'] and maximum<1e-12
 results.append(dict(cohort=c,refinedQueries=checked,maximumDistanceError=maximum,allSelectedExact=True,unselectedUnchanged=True));print(results[-1],flush=True)
with (r/'refinement-oracle.json').open('x') as out:json.dump(dict(results=results,scriptSHA256=sha(Path(__file__)),outputsFreezeSHA256=sha(r/'candidate/outputs-frozen.json')),out,indent=2)
