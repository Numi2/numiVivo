import json, os, subprocess, time
from pathlib import Path
r=Path(__file__).parent
p=json.loads((r/'protocol.json').read_text())
env=dict(os.environ,NUMIVIVO_HDF5_LIBRARY='/Users/n/numivivo-integration-reference-py/lib/python3.13/site-packages/h5py/.dylibs/libhdf5.320.0.0.dylib',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1')
steps=[('pca',['singlecell-h5ad-pca',p['source'],'--plan',str(r/'pca-plan.json'),'--output',str(r/'pca')]),('mnn',['singlecell-pca-integrate',str(r/'pca'),'--plan',str(r/'mnn-plan.json'),'--output',str(r/'mnn')]),('verify',['singlecell-pca-integrate-verify',str(r/'mnn')])]
results=[]
for name,args in steps:
 start=time.time()
 with (r/(name+'.log')).open('w') as f: code=subprocess.call([p['cli']]+args,env=env,stdout=f,stderr=subprocess.STDOUT)
 results.append(dict(step=name,exitCode=code,seconds=time.time()-start))
 (r/'status.json').write_text(json.dumps(results,indent=2))
 if code: break
(r/'terminal.json').write_text(json.dumps(dict(steps=results,completedUnix=time.time()),indent=2))
