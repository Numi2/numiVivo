from pathlib import Path
import hashlib,json,os,subprocess,time,shutil
r=Path('/Users/n/numivivo-mnn-cli-lifecycle-20260912')
p=json.loads((r/'protocol.json').read_text())
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def tree(p):return {str(f.relative_to(p)):sha(f) for f in sorted(p.rglob('*')) if f.is_file()}
assert sha(Path(p['cli']))==p['cliSHA256']
env=dict(os.environ,NUMIVIVO_HDF5_LIBRARY='/Users/n/numivivo-integration-reference-py/lib/python3.13/site-packages/h5py/.dylibs/libhdf5.320.0.0.dylib')
results=[]
def run(name,args):
 t=time.time()
 with (r/(name+'.log')).open('w') as f:code=subprocess.call([p['cli']]+args,env=env,stdout=f,stderr=subprocess.STDOUT)
 results.append(dict(case=name,exitCode=code,seconds=time.time()-t));assert code!=0,name
before=tree(r/'mnn')
run('existing-output',['singlecell-pca-integrate',str(r/'pca'),'--plan',str(r/'mnn-plan.json'),'--output',str(r/'mnn')])
assert tree(r/'mnn')==before
plan=json.loads((r/'mnn-plan.json').read_text());plan['mnn']['maximumWork']=1
(r/'budget-plan.json').write_text(json.dumps(plan))
entries=set(r.iterdir())
run('work-budget',['singlecell-pca-integrate',str(r/'pca'),'--plan',str(r/'budget-plan.json'),'--output',str(r/'budget-rejected')])
assert not (r/'budget-rejected').exists()
assert set(r.iterdir())-entries=={r/'work-budget.log'}
assert not (r/'tampered').exists()
shutil.copytree(r/'mnn',r/'tampered')
f=r/'tampered/anchors.bin'
with f.open('r+b') as out:
 b=out.read(1);out.seek(0);out.write(bytes([b[0]^1]))
run('tampered-anchor',['singlecell-pca-integrate-verify',str(r/'tampered')])
assert tree(r/'mnn')==before
comparison={}
old=Path('/Users/n/numivivo-native-mnn-20260910/hagai')
for name in ['pca/scores.bin','mnn/scores.bin','mnn/anchors.bin','mnn/report.json']:
 comparison[name]=dict(fresh=sha(r/name),prior=sha(old/name))
 assert comparison[name]['fresh']==comparison[name]['prior'],name
(r/'qualification.json').write_text(json.dumps(dict(status='PASS',rejections=results,byteEquivalence=comparison,bundleFiles=before,scope=p['scope']),indent=2))
print(json.dumps(dict(status='PASS',rejections=results)))
