from pathlib import Path
import json,hashlib,tarfile
r=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert 'PASS' in (r/'sanitizers.log').read_text() and 'PASS' in (r/'cancel.log').read_text()
v=json.loads((r/'verification.json').read_text());assert len(v['results'])==3
v['sourceBaseCommit']='095aacc64a991dbed8ca4bbdfee52064b8f9fc88'
v['sanitizerTestsPassed']=True;v['swiftCancellationPassed']=True
v['maximumRSSBytes']=133906432
v['testSources']={n:sha(r/n) for n in ['Main.swift','Cancel.swift','Test.cpp']}
(r/'verification.json').write_text(json.dumps(v,indent=2)+'\n')
names=['verification.json','Main.swift','Cancel.swift','Test.cpp','package.py','build.log','owner-build.log','owner.log','cancel-build.log','cancel.log','sanitizers.log','build/sources.sha256','driver-attempt-1/Main.swift','driver-attempt-1/owner.log']
names+=['source/'+n for n in v['sourceSHA256']]
names += [str(p.relative_to(r)) for p in (r/'owner-output').glob('*/*.json')]
files=[r/n for n in names]
external=[r/'build/numivivo-omics',r/'build/libNumiVivoKit.a',r/'owner-check',r/'cancel-check',r/'test-sanitized',r/'driver-attempt-1/owner-check']+list((r/'owner-output').glob('*/*.bin'))
with tarfile.open(r/'evidence.tar.gz','w:gz') as t:
 for p in files:t.add(p,arcname=str(p.relative_to(r)),recursive=False)
m=dict(archiveSHA256=sha(r/'evidence.tar.gz'),members={str(p.relative_to(r)):sha(p) for p in files},externalArtifacts={str(p.relative_to(r)):dict(bytes=p.stat().st_size,SHA256=sha(p)) for p in external},remoteRoot=str(r),scope='Executed scoped Swift owner, CLI build, native sanitizer/cancellation checks; full package/app and fresh biological validation not performed')
(r/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print('archive bytes',(r/'evidence.tar.gz').stat().st_size)
