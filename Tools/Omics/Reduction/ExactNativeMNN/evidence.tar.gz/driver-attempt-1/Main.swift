import Foundation
@testable import NumiVivoKit
@main struct Main {
 static func main() async throws {
  let args=CommandLine.arguments
  let source=URL(fileURLWithPath:args[1]), out=URL(fileURLWithPath:args[2])
  try FileManager.default.createDirectory(at:out,withIntermediateDirectories:false)
  for cohort in ["hagai","kang","ding"] {
   let input=source.appendingPathComponent(cohort), target=out.appendingPathComponent(cohort)
   try FileManager.default.createDirectory(at:target,withIntermediateDirectories:false)
   let metadata=try JSONDecoder().decode(VivoSingleCellCountMetadata.self,from:Data(contentsOf:input.appendingPathComponent("pca/metadata.json")))
   let plan=try JSONDecoder().decode(VivoPCAIntegrationPlan.self,from:Data(contentsOf:input.appendingPathComponent("mnn/plan.json")))
   let cells=metadata.cells.map { VivoOmicsCellIdentity(sampleID:$0.sampleID,barcode:$0.barcode) }
   let reader=try VivoPCAScoreReader(input.appendingPathComponent("pca/scores.bin"),rows:cells.count,columns:20)
   let scores=try reader.readRows(0..<cells.count)
   let start=Date()
   let result=try VivoMNNIntegration.run(cells:cells,scores:scores,dimensions:20,samples:metadata.samples,options:plan.mnn!)
   let seconds=Date().timeIntervalSince(start)
   let prior=try JSONDecoder().decode(VivoMNNIntegrationReport.self,from:Data(contentsOf:input.appendingPathComponent("mnn/report.json")))
   let expected=try VivoPCAScoreReader(input.appendingPathComponent("mnn/scores.bin"),rows:cells.count,columns:20).readRows(0..<cells.count)
   let writer=try VivoCountRecordWriter(target.appendingPathComponent("scores.bin"))
   for i in 0..<cells.count { for j in 0..<20 { try writer.append(row:i,feature:j,bits:result.scores[i*20+j].bitPattern) } }
   _=try writer.finish()
   let anchors=try VivoCountRecordWriter(target.appendingPathComponent("anchors.bin"))
   for (i,a) in result.anchors.enumerated(){try anchors.append(row:a.first,feature:a.second,bits:result.anchorDistances[i].bitPattern)}
   _=try anchors.finish()
   try VivoCanonicalJSON.encode(result.report).write(to:target.appendingPathComponent("report.json"))
   let maximum=zip(expected,result.scores).map { abs($0-$1) }.max()!
   let exact=zip(expected,result.scores).allSatisfy{$0.bitPattern==$1.bitPattern}
   let summary:[String:Any]=["cohort":cohort,"cells":cells.count,"seconds":seconds,"maximumCoordinateError":maximum,"scoresBitwiseExact":exact,"reportExact":result.report==prior]
   try JSONSerialization.data(withJSONObject:summary,options:[.sortedKeys,.prettyPrinted]).write(to:target.appendingPathComponent("check.json"))
   print(cohort,seconds,"coordinate error",maximum,"bitwise",exact,"report",result.report==prior)
  }
 }
}
