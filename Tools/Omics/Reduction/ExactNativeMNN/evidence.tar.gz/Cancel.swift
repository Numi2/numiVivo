import Foundation
@testable import NumiVivoKit
@main struct Main {
 static func main() async throws {
  let p=URL(fileURLWithPath:"/Users/n/numivivo-native-mnn-20260910/hagai")
  let metadata=try JSONDecoder().decode(VivoSingleCellCountMetadata.self,from:Data(contentsOf:p.appendingPathComponent("pca/metadata.json")))
  let plan=try JSONDecoder().decode(VivoPCAIntegrationPlan.self,from:Data(contentsOf:p.appendingPathComponent("mnn/plan.json")))
  let cells=metadata.cells.map{VivoOmicsCellIdentity(sampleID:$0.sampleID,barcode:$0.barcode)}
  let reader=try VivoPCAScoreReader(p.appendingPathComponent("pca/scores.bin"),rows:cells.count,columns:20)
  var storage=[Double]();for first in stride(from:0,to:cells.count,by:2048){storage += try reader.readRows(first..<min(cells.count,first+2048))}
  let scores=storage, samples=metadata.samples, options=plan.mnn!
  let start=Date()
  let task=Task.detached { _=try VivoMNNIntegration.run(cells:cells,scores:scores,dimensions:20,samples:samples,options:options);return true }
  try await Task.sleep(nanoseconds:50_000_000);task.cancel()
  var cancelled=false
  do { _=try await task.value } catch is CancellationError { cancelled=true }
  guard cancelled else { throw NSError(domain:"ExpectedCancellation",code:1) }
  print("PASS Swift owner CancellationError after cancellation request; elapsed",Date().timeIntervalSince(start))
 }
}
