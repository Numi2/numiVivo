from pathlib import Path
import json,hashlib,tarfile,re
r=Path(__file__).parent
names=['Sources/NumiVivoKit/Omics/'+x+'.swift' for x in ['VivoMetalPCANeighbors','VivoWindowedPCANeighbors','VivoPCANeighborBundle','VivoPCAGraphStore']]+['Tools/Omics/H5AD/build.sh']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
checks=json.loads((r/'cli-terminal.json').read_text());assert len(checks['results'])==10
assert all(x['exitCode']==(65 if x['step'].startswith('reject') else 0) for x in checks['results'])
files=[]
for p in sorted(r.rglob('*')):
 if not p.is_file() or p.name in ['manifest.json','evidence.tar.gz'] or '__pycache__' in p.parts:continue
 # Only hash authored owners from source; full build source hashes are already retained.
 if 'source' in p.relative_to(r).parts and str(p.relative_to(r/'source')) not in names:continue
 files.append(dict(path=str(p.relative_to(r)),bytes=p.stat().st_size,sha256=sha(p)))
manifest=dict(baseCommit='0309d326bf585abb502e0a08317c21366527c6ba',externalRoot=str(r),sourceHashes={n:sha(r/'source'/n) for n in names},files=files)
(r/'manifest.json').write_text(json.dumps(manifest,indent=2))
with tarfile.open(r/'evidence.tar.gz','w:gz') as t:
 for f in files:
  p=r/f['path'];parts=p.relative_to(r).parts
  if parts[0] in ['pca','cpu','metal','metal-json','control-output','owner-output']:
   if p.name not in ['graph-check.json','reference-check.json']:continue
  if parts[0]=='build' and p.name!='sources.sha256':continue
  if p.suffix not in ['.json','.swift','.py','.log','.sh','.sha256']:continue
  t.add(p,arcname=f['path'])
 t.add(r/'manifest.json',arcname='manifest.json')
print('archiveBytes',(r/'evidence.tar.gz').stat().st_size)
