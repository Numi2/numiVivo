import subprocess,json,time
from pathlib import Path
r=Path(__file__).parent
for cmd in json.loads((r/"checks-commands.json").read_text()):
 code=subprocess.call(cmd)
 if code:break
(r/"checks-terminal.json").write_text(json.dumps(dict(returnCode=code,finishedUnix=time.time())))
raise SystemExit(code)
