# Fixed wider-query MNN development test

Before this fit, retain all original Hagai, Kang and Ding cells and the exact
original biological evaluation folds, labels, programs and margins. Existing
cohort outcomes and the Kang rare-cell failure are inspected development data.
Change only eligible-prefix/suffix HNSW query ef from 128 to 512. Keep M=16,
construction ef=200, seed=7, Manhattan row-normalized matching, k=20, panorama
assembly and qualified full-anchor Gaussian sigma=15 unchanged. No local-kernel
replacement, cohort exclusion or post-score parameter tuning. Freeze source,
protocol, input and library identities before fitting and output before scoring.
Check complete replay, exact anchor precision/recall and every original
biological gate. High anchor recall alone is not promotion. This test does not
qualify million-cell integration or independent biological generalization.
