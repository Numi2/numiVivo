import subprocess,json,time
from pathlib import Path
r=Path(__file__).parent
code=subprocess.call(json.loads((r/"command.json").read_text()))
(r/"terminal.json").write_text(json.dumps(dict(returnCode=code,finishedUnix=time.time())))
raise SystemExit(code)
