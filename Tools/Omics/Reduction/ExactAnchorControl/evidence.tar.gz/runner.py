import subprocess,json,time
from pathlib import Path
r=Path(__file__).parent
code=subprocess.call(["/Users/n/numivivo-mnn-wide-20260912/evaluation-py/bin/python",str(r/"run.py")])
(r/"terminal.json").write_text(json.dumps(dict(returnCode=code,finishedUnix=time.time())))
raise SystemExit(code)
