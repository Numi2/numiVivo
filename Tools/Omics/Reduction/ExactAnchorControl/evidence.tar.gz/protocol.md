# Exact-anchor assembly control

Diagnose the full-Gaussian approximate-matching failure without changing its
assembly, smoothing, parameters or biological gates. On all original Hagai,
Kang and Ding cells, replace approximate mutual anchors with the frozen native
exact anchors. Use the same original PCA, levels and qualified Gaussian library.
Run every correction step and compare every final coordinate to the original
native MNN result. Freeze inputs, code and library before execution. Retain all
step witnesses and failures. This is an implementation-isolation control, not a
new approximate matcher, independent biological test or product promotion.
Assembly order equality alone has already been observed; exact-anchor agreement
would isolate remaining divergence to matching for these cohorts, without proving
why any specific changed anchor causes a biological failure.
