from pathlib import Path
import json,hashlib,collections
import numpy as np
r=Path(__file__).parent;wide=Path('/Users/n/numivivo-mnn-wide-20260912');source=Path('/Users/n/numivivo-native-mnn-20260910')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads((wide/'candidate/outputs-frozen.json').read_text());ef=json.loads((wide/'evaluation/execution-freeze.json').read_text());results=[]
for c in ['hagai','kang','ding']:
 old=source/c/'mnn/anchors.bin';expected=json.loads((r/'freeze.json').read_text())['inputs'][c+'/mnn/anchors.bin'];assert sha(old)==expected
 p=wide/'candidate'/c/'anchors.npz';assert sha(p)==f['files'][c+'/anchors.npz']
 inp=wide/'inputs'/(c+'.npz');assert sha(inp)==ef['candidateBindings'][c]['inputsSHA256']
 x=np.load(inp);labels=x['cellTypes'] if 'cellTypes' in x else np.where(x['known'],x['types'],'unreported');n=len(labels)
 exact=np.fromfile(old,dtype=[('first','<u4'),('second','<u4'),('distance','<f8')]);e=exact['first'].astype(np.int64)*n+exact['second']
 a=np.load(p);pairs=np.concatenate([a[k] for k in a.files]);v=pairs[:,0]*n+pairs[:,1]
 assert len(np.unique(e))==len(e) and len(np.unique(v))==len(v)
 def describe(keys):
  endpoints=np.column_stack([keys//n,keys%n]);unique=np.unique(endpoints)
  return dict(anchors=len(keys),uniqueEndpointCells=len(unique),endpointOccurrences=dict(sorted(collections.Counter(map(str,labels[endpoints.ravel()])).items())),uniqueEndpointLabels=dict(sorted(collections.Counter(map(str,labels[unique])).items())))
 results.append(dict(cohort=c,inputsSHA256=sha(inp),exactAnchorsSHA256=sha(old),candidateAnchorsSHA256=sha(p),allExact=describe(e),missing=describe(np.setdiff1d(e,v)),added=describe(np.setdiff1d(v,e))))
out=dict(scope='Retrospective changed-anchor endpoint accounting; repeated endpoints are not independent cells and labels are not authoritative',results=results,scriptSHA256=sha(Path(__file__)))
with (r/'changed-anchors.json').open('x') as f:json.dump(out,f,indent=2)
for x in results:print(x['cohort'],'missing',x['missing'],'added',x['added'])
