import ctypes as C,sys,time,json
from pathlib import Path
import numpy as np
from fit import fit,sha,read,write,matrix
D=C.POINTER(C.c_double);U=C.c_uint32;L=C.c_uint64
class Gaussian:
 def __init__(self,path):
  self.lib=C.CDLL(str(path));self.f=self.lib.nvivo_omics_gaussian_bias
  self.f.restype=C.c_int32;self.f.argtypes=[D,D,U,D,U,U,C.c_double,L,L,L,D,L,D,L,D,L,C.POINTER(L),C.c_void_p,C.c_void_p]
 def __call__(self,source,bias,queries):
  start=time.perf_counter();source,bias,queries=[np.ascontiguousarray(x,dtype=np.float64) for x in (source,bias,queries)]
  na,d=source.shape;nq=len(queries);assert bias.shape==source.shape and queries.shape==(nq,d)
  delta=np.empty_like(queries);totals=np.empty(nq);workspace=np.empty(256*(d+32));terms=0;budget=2*na*nq*d
  ptr=lambda x:x.ctypes.data_as(D)
  for first in range(0,nq,32):
   q=queries[first:first+32];out=delta[first:first+32];total=totals[first:first+32];evaluated=L()
   status=self.f(ptr(source),ptr(bias),na,ptr(q),len(q),d,15.,source.size,q.size,budget-terms,ptr(out),out.size,ptr(total),len(total),ptr(workspace),workspace.size,C.byref(evaluated),None,None)
   assert status==0,('Gaussian status',status);terms+=evaluated.value
  assert na*nq*d<=terms<=budget and np.isfinite(delta).all() and np.isfinite(totals).all()
  return delta,totals,dict(distanceTerms=terms,maximumDistanceTerms=budget,workspaceBytes=workspace.nbytes,seconds=time.perf_counter()-start)

r=Path(__file__).parent;s=Path('/Users/n/numivivo-native-mnn-20260910')
prior=read(Path('/Users/n/numivivo-local-mnn-20260911/prior-artifacts.json'))
gaussian=Path(read(Path('/Users/n/numivivo-mnn-wide-20260912/build.json'))['gaussianLibrary']);kernel=Gaussian(gaussian)
inputs={}
for c in ['hagai','kang','ding']:
 entries=next(v['files'] for v in prior if v['cohort']==c)
 for name in ['pca/scores.bin','mnn/report.json','mnn/anchors.bin','mnn/scores.bin']:
  expected=next(x['sha256'] for x in entries if x['path']==name)
  assert sha(s/c/name)==expected;inputs[c+'/'+name]=expected
write(r/'freeze.json',dict(inputs=inputs,sourceSHA256={p.name:sha(p) for p in r.glob('*.py')},protocolSHA256=sha(r/'protocol.md'),gaussianLibrarySHA256=sha(gaussian),metricsRead=False))
results=[]
for c in ['hagai','kang','ding']:
 old=s/c;reference=read(old/'mnn/report.json');n=len(reference['cellLevels']);batch=np.array(reference['cellLevels'],dtype=np.uint32);x=matrix(old/'pca/scores.bin',n,20)
 anchors=np.fromfile(old/'mnn/anchors.bin',dtype=[('first','<u4'),('second','<u4'),('distance','<f8')]);pairs=np.column_stack([anchors['first'],anchors['second']]).astype(np.int64)
 out=r/c;out.mkdir();report=fit(None,x,batch,out,kernel=kernel,anchor_override=pairs);write(out/'report.json',report)
 y=np.load(out/'scores.npz')['scores'];expected=matrix(old/'mnn/scores.bin',n,20);err=abs(y-expected)
 result=dict(cohort=c,cells=n,anchors=len(pairs),orderExact=report['order']==reference['assemblyOrder'],maximumCoordinateError=float(err.max()),coordinateRMSE=float(np.sqrt(np.mean(err**2))),passed=bool(np.all(err<=1e-10*(1+abs(expected)))),fitSeconds=report['fitSeconds'])
 results.append(result);print(result,flush=True)
for n,h in inputs.items():assert sha(s/n)==h
write(r/'results.json',dict(scope='Exact-anchor assembly implementation control, no new biological qualification',results=results,allCohortsChecked=True,allCoordinatesPassed=all(x['passed'] for x in results),freezeSHA256=sha(r/'freeze.json')))
