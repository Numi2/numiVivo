#ifndef NUMIVIVO_OMICS_GAUSSIAN_H
#define NUMIVIVO_OMICS_GAUSSIAN_H
#include "NumiVivoCore/NumiVivoCore.h"
#ifdef __cplusplus
extern "C" {
#endif
/* All-anchor FP64 Gaussian bias average, fixed 32-query / 256-anchor tiles.
 * Input/output/workspace buffers must be disjoint, contiguous and remain valid
 * for the synchronous call. Source/bias are anchor-major, queries/delta row-major.
 * Duplicate anchors are retained. All arrays are borrowed; no full matrix copy.
 * Workspace requirement is (256*dimensions + 256*query_rows) doubles.
 * Status 0 success; 1 arguments/capacity; 2 work; 4 nonfinite; 5 cancelled.
 * Outputs are not a result on failure. Zero-weight rows receive zero delta.
 * Deterministic on the pinned executable/OS; Accelerate reduction differs from
 * scalar order. Totals below 1e-280 use an explicitly budgeted scalar fallback.
 * evaluated_scalar_terms reports direct distance terms, including fallback. Framework internal workspace is outside the explicit buffer size.
 */
NVIVO_EXPORT int32_t nvivo_omics_gaussian_bias(
    const double *source, const double *bias, uint32_t anchors,
    const double *queries, uint32_t query_rows, uint32_t dimensions, double sigma,
    uint64_t source_capacity, uint64_t query_capacity, uint64_t maximum_scalar_terms,
    double *delta, uint64_t delta_capacity, double *totals, uint64_t totals_capacity,
    double *workspace, uint64_t workspace_capacity, uint64_t *evaluated_scalar_terms,
    int32_t (*cancel)(void *), void *context);
#ifdef __cplusplus
}
#endif
#endif
