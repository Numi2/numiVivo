import json,subprocess,os,hashlib,time
from pathlib import Path
r=Path('/Users/n/numivivo-h5ad-20260909');root=Path('/Users/n/numivivo-gaussian-kernel-20260911');o=root/'native-phase';lib=o/'runtime';env={**os.environ,'VECLIB_MAXIMUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','NUMIVIVO_HDF5_LIBRARY':'/Users/n/numivivo-multiassay-hdf5-20260909/libhdf5.dylib'}
commands=[]
def run(label,cmd):
 start=time.time()
 with (o/(label+'.log')).open('x') as log:
  p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,env=env);(o/(label+'-process.json')).write_text(json.dumps(dict(pid=p.pid,driverPID=os.getpid(),command=cmd,startedUnix=start),indent=2)+'\n');code=p.wait()
 commands.append(dict(label=label,returnCode=code,seconds=time.time()-start));(o/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(commands[-1],flush=True);assert code==0,label
for source,name in [('Main.swift','mnn-gaussian-check'),('LifecycleMain.swift','gaussian-lifecycle')]:
 run('build-'+name,['swiftc','-swift-version','6','-O','-parse-as-library','-I',str(lib),'-I',str(r/'Sources/CNumiVivoZlib'),'-I',str(r/'Sources/NumiVivoCore/include'),'-L',str(lib),'-lNumiVivoKit',str(r/'Tools/Omics/Reduction/GaussianKernel'/source),str(lib/'OmicsHNSW.o'),str(lib/'OmicsGaussian.o'),'-framework','Accelerate','-lc++','-o',str(o/name)])
run('test-suite-driver',['python3',str(root/'build_tests_phase.py')])
run('library',['xcrun','clang++','-std=c++23','-O3','-shared','-fPIC','-I',str(r/'Sources/NumiVivoCore/include'),str(r/'Sources/NumiVivoCore/OmicsGaussian.cpp'),'-framework','Accelerate','-o',str(o/'libGaussian.dylib')])
run('independent-kernel',['/Users/n/numivivo-integration-reference-py/bin/python',str(r/'Tools/Omics/Reduction/GaussianKernel/check_kernel.py'),'--library',str(o/'libGaussian.dylib'),'--out',str(o/'kernel-checks.json')])
run('cohorts',['python3',str(r/'Tools/Omics/Reduction/GaussianKernel/run_cohorts.py'),'--binary',str(o/'mnn-gaussian-check'),'--source','/Users/n/numivivo-native-mnn-20260910','--prior-manifest','/Users/n/numivivo-local-mnn-20260911/prior-artifacts.json','--out',str(o/'cohorts')])
run('lifecycle',['/usr/bin/time','-l',str(o/'gaussian-lifecycle'),'/Users/n/numivivo-native-mnn-20260910/hagai',str(o/'lifecycle-hagai'),str(o/'cohorts/hagai-tiled')])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
comparisons={}
for c in ('hagai','kang','ding'):
 for mode in ('scan','tiled','tiled-replay'):
  for n in ('scores.bin','anchors.bin'):
   original=root/'cohorts'/(c+'-'+mode)/n;repaired=o/'cohorts'/(c+'-'+mode)/n;assert sha(original)==sha(repaired);comparisons[c+'-'+mode+'/'+n]=sha(repaired)
 for name in ('report.json',):
  original=json.loads((root/'cohorts'/(c+'-tiled')/name).read_text());repaired=json.loads((o/'cohorts'/(c+'-tiled')/name).read_text());assert all(original[k]==repaired[k] for k in original if k!='qualification')
# Verify normal application launches without an externally imposed BLAS thread cap.
env.pop('VECLIB_MAXIMUM_THREADS',None)
default_hashes={}
for c in ('hagai','kang','ding'):
 destination=o/(c+'-default-threads')
 run(c+'-default-threads',['/usr/bin/time','-l',str(o/'mnn-gaussian-check'),'/Users/n/numivivo-native-mnn-20260910/'+c,str(destination),'tiled'])
 for name in ('scores.bin','anchors.bin','report.json'):
  h=sha(destination/name);assert h==sha(o/'cohorts'/(c+'-tiled')/name);default_hashes[c+'/'+name]=h
(o/'default-thread-comparison.json').write_text(json.dumps(dict(status='passed',allThreeCompleteCohortsExact=True,files=default_hashes),indent=2)+'\n')
(o/'repair-comparison.json').write_text(json.dumps(dict(status='passed',allNineScoreAndAnchorPayloadsExact=True,allNumericalReportFieldsExact=True,allOriginalCohortFallbackTermsZero=True,originalCompleteSHA256=sha(root/'cohorts/complete.json'),repairedCompleteSHA256=sha(o/'cohorts/complete.json'),files=comparisons,scope='Original biological evaluation can be reused only through the exact checked score bytes; failed subnormal test remains retained.'),indent=2)+'\n')
print('Repaired full cohorts, lifecycle and exact biological-input reuse verified.',flush=True)
