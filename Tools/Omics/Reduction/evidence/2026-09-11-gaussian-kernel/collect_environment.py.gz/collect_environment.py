import hashlib,json,subprocess,time
from pathlib import Path
r=Path('/Users/n/numivivo-h5ad-20260909');root=Path('/Users/n/numivivo-gaussian-kernel-20260911')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=json.loads((root/'final-source-paths.json').read_text());bindings={n:sha(r/n) for n in paths}
compiled={}
for line in (root/'native-phase/runtime/sources.sha256').read_text().splitlines():
 digest,path=line.split(maxsplit=1);p=Path(path.strip());assert sha(p)==digest,str(p);compiled[str(p.relative_to(r))]=digest
binaries={}
for stage in ('','repaired/','final/','qualified/','release/','native-phase/'):
 for name in ('mnn-gaussian-check','gaussian-lifecycle','mnn-tests','libGaussian.dylib','runtime/h5ad-check','runtime/libNumiVivoKit.a'):
  p=root/stage/name
  if p.exists():binaries[stage+name]=dict(bytes=p.stat().st_size,SHA256=sha(p))
record=dict(baseCommit='9895348d5f14266a068b1626b04ece86e44c859d',createdUnix=time.time(),finalSourceSHA256=bindings,compiledSourceSHA256=compiled,binaries=binaries,compiler=subprocess.check_output(['swiftc','--version'],text=True),clang=subprocess.check_output(['xcrun','clang++','--version'],text=True),operatingSystem=subprocess.check_output(['sw_vers'],text=True),machine=subprocess.check_output(['sysctl','-n','machdep.cpu.brand_string'],text=True).strip(),memoryBytes=int(subprocess.check_output(['sysctl','-n','hw.memsize'],text=True)),baselineObservation=subprocess.check_output(['ps','-p','11290','-o','pid=,etime=,pcpu=,rss=,command='],text=True).strip(),hdf5SHA256=sha(Path('/Users/n/numivivo-multiassay-hdf5-20260909/libhdf5.dylib')),scope='Physical Mac mini. Qualified executable and source bindings; public parent reconstruction retains original implementation tag. Retained intermediate builds and active historical baseline are separate from final timing claims.')
(root/'environment.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');print('Environment and all current compiled source hashes verified.')
