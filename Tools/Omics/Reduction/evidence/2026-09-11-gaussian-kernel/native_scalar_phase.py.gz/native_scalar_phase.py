from pathlib import Path
r=Path('/Users/home/numivivo-single-cell-20260909');root=Path('/Users/home/numivivo-gaussian-kernel-20260911');saved=root/'pre-native-phase';saved.mkdir()
for n in ['Sources/NumiVivoCore/OmicsGaussian.cpp','Sources/NumiVivoCore/include/NumiVivoCore/NumiVivoOmicsGaussian.h','Sources/NumiVivoKit/Omics/VivoMNNIntegration.swift']:
 p=r/n;q=saved/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
p=r/'Sources/NumiVivoCore/OmicsGaussian.cpp';s=p.read_text();head,scalar=s.split('// Legacy scalar Gaussian sum.',1);scalar=scalar.replace('extern "C" int32_t nvivo_omics_gaussian_scalar(', 'static int32_t scalarSum(');scalar=scalar.replace('int32_t (*cancel)(void *), void *context) {','int32_t (*cancel)(void *), void *context, bool validate) {',1);scalar=scalar.replace('if (!std::isfinite(value)) return 4;','if (validate && !std::isfinite(value)) return 4;');s=head+'// Legacy scalar Gaussian sum.'+scalar
s+='''
extern "C" int32_t nvivo_omics_gaussian_scalar(
    const double *source, const double *bias, uint32_t anchors, const double *query,
    uint32_t dimensions, double sigma, uint64_t source_capacity, uint64_t query_capacity,
    double *numerator, uint64_t output_capacity, double *total,
    int32_t (*cancel)(void *), void *context) {
    return scalarSum(source,bias,anchors,query,dimensions,sigma,source_capacity,query_capacity,
        numerator,output_capacity,total,cancel,context,true);
}
extern "C" int32_t nvivo_omics_gaussian_scalar_apply(
    const double *source, const double *bias, uint32_t anchors, uint32_t dimensions,
    double sigma, uint64_t source_capacity, double *scores, uint32_t rows, uint64_t score_capacity,
    const intptr_t *selected, uint32_t selected_rows, uint64_t maximum_scalar_terms,
    NVivoGaussianScalarReport *report, int32_t (*cancel)(void *), void *context) {
    if (!source || !bias || !scores || !selected || !report || !anchors || anchors>200000000 ||
        !dimensions || dimensions>64 || !rows || rows>2000000 || !selected_rows || selected_rows>rows ||
        !std::isfinite(sigma) || sigma<.001 || sigma>1000 ||
        source_capacity<uint64_t(anchors)*dimensions || score_capacity<uint64_t(rows)*dimensions) return 1;
    if (uint64_t(anchors)*dimensions*selected_rows>maximum_scalar_terms) return 2;
    if (cancel && cancel(context)) return 5;
    // Validate immutable snapshots once per assembly phase, not once per query.
    for (uint64_t i=0;i<uint64_t(anchors)*dimensions;++i)
        if (!std::isfinite(source[i]) || !std::isfinite(bias[i])) return 4;
    for (uint32_t q=0;q<selected_rows;++q) if (selected[q]<0 || uint64_t(selected[q])>=rows) return 1;
    *report={0,INFINITY,0.,0.};
    double delta[64];
    for (uint32_t q=0;q<selected_rows;++q) {
        double *row=scores+uint64_t(selected[q])*dimensions,total=0.;
        const int32_t status=scalarSum(source,bias,anchors,row,dimensions,sigma,source_capacity,dimensions,
            delta,64,&total,cancel,context,false);
        if (status) return status;
        report->minimum_weight=std::min(report->minimum_weight,total);
        report->maximum_weight=std::max(report->maximum_weight,total);
        if (total==0.) ++report->zero_weight_rows;
        for (uint32_t j=0;j<dimensions;++j) {
            const double value=total>0. ? delta[j]/total : 0.;
            row[j]+=value;report->sum_squared+=value*value;
            if (!std::isfinite(row[j])) return 4;
        }
    }
    return 0;
}
''';p.write_text(s)
p=r/'Sources/NumiVivoCore/include/NumiVivoCore/NumiVivoOmicsGaussian.h';s=p.read_text();point='#ifdef __cplusplus\n}\n#endif\n#endif';new='''typedef struct NVivoGaussianScalarReport {
    uint64_t zero_weight_rows;
    double minimum_weight, maximum_weight, sum_squared;
} NVivoGaussianScalarReport;
/* Complete selected-row scalar phase. Immutable anchor snapshots are validated
 * once. Scores update in selected order, using the same per-query scalar sums.
 * All spans must be disjoint except the intentionally mutable scores span.
 * Maximum work counts anchors*dimensions*selected_rows. No heap allocation;
 * one 64-double stack accumulator. Partial scores/report are not a result on
 * failure. Status 0 success, 1 arguments, 2 work, 4 nonfinite, 5 cancellation. */
NVIVO_EXPORT int32_t nvivo_omics_gaussian_scalar_apply(
    const double *source, const double *bias, uint32_t anchors, uint32_t dimensions,
    double sigma, uint64_t source_capacity, double *scores, uint32_t rows, uint64_t score_capacity,
    const intptr_t *selected, uint32_t selected_rows, uint64_t maximum_scalar_terms,
    NVivoGaussianScalarReport *report, int32_t (*cancel)(void *), void *context);
''';s=s.replace(point,new+point);p.write_text(s)
p=r/'Sources/NumiVivoKit/Omics/VivoMNNIntegration.swift';s=p.read_text();start=s.index('    // The native helper preserves');end=s.index('    // Keep pointer/callback',start);s=s[:start]+s[end:]
start=s.index('            } else {\n                for i in selected {');end=s.index('            return .init(alignment:',start)
s=s[:start]+'''            } else {
                var scalar = NVivoGaussianScalarReport()
                let status = source.withUnsafeBufferPointer { src in bias.withUnsafeBufferPointer { b in
                    selected.withUnsafeBufferPointer { indices in corrected.withUnsafeMutableBufferPointer { values in
                        nvivo_omics_gaussian_scalar_apply(src.baseAddress,b.baseAddress,UInt32(matched.count),UInt32(d),
                            o.sigma,UInt64(src.count),values.baseAddress,UInt32(n),UInt64(values.count),indices.baseAddress,
                            UInt32(indices.count),UInt64(cost),&scalar,{ _ in Task.isCancelled ? 1 : 0 },nil)
                    } }
                } }
                if status == 5 { throw CancellationError() }
                guard status == 0 else { throw VivoOmicsError.invalid("MNN scalar phase status: \\(status)") }
                zero = Int(scalar.zero_weight_rows); minWeight = scalar.minimum_weight
                maxWeight = scalar.maximum_weight; sumSquared = scalar.sum_squared
            }
'''+s[end:];p.write_text(s)
p=root/'run_release.py';s=p.read_text().replace("o=root/'release'","o=root/'native-phase'").replace('build_tests_release.py','build_tests_phase.py');(root/'run_phase.py').write_text(s)
p=root/'build_tests_release.py';s=p.read_text().replace('20260911/release','20260911/native-phase');(root/'build_tests_phase.py').write_text(s)
p=r/'Tools/Omics/Reduction/GaussianKernel/PROTOCOL_SCALAR.md';s=p.read_text();s+='''

The production-restored library provides the authoritative scalar timing baseline.
Amortize source/bias finite validation once per complete scalar assembly phase,
rather than repeating it for every query. Borrow the selected-row list and mutable
local score buffer; use one 64-double stack accumulator. Keep scalar summation,
query order, division, coordinate update and RMS accumulation unchanged. Capacity,
selected-index, work and finite checks remain explicit; failures never publish
partial results. Repeat the full protocol against the preserved production build.
''';p.write_text(s)
