import ctypes as c,numpy as np,time,json
from pathlib import Path
r=Path('/Users/home/numivivo-gaussian-kernel-20260911');D=c.POINTER(c.c_double);U=c.c_uint32;L=c.c_uint64;F=c.CFUNCTYPE(c.c_int32,c.c_void_p);cb=F(lambda _:0);ptr=lambda x:x.ctypes.data_as(D)
rng=np.random.default_rng(17);s=rng.normal(size=(20000,20))*.1;b=rng.normal(size=s.shape);queries=rng.normal(size=(32,20))*.1;results={};arrays={}
for label,name in [('before','libGaussian-release.dylib'),('prevalidated','libGaussian-prevalidated.dylib')]:
 lib=c.CDLL(str(r/name));fn=lib.nvivo_omics_gaussian_scalar;fn.restype=c.c_int32;fn.argtypes=[D,D,U,D,U,c.c_double,L,L,D,L,D,F,c.c_void_p];out=np.zeros((32,20));total=np.zeros(32);times=[]
 for repeat in range(4):
  start=time.perf_counter()
  for i in range(32):assert fn(ptr(s),ptr(b),len(s),ptr(queries[i]),20,15.,s.size,20,ptr(out[i]),20,ptr(total[i:i+1]),cb,None)==0
  times.append(time.perf_counter()-start)
 results[label]=times;arrays[label]=(out.copy(),total.copy())
for x,y in zip(arrays['before'],arrays['prevalidated']):np.testing.assert_array_equal(x,y)
(r/'scalar-prevalidated-comparison.json').write_text(json.dumps(dict(times=results,allScalarNumeratorAndTotalBitsExact=True,scope='Local synthetic native-loop microbenchmark only; not cohort performance'),indent=2)+'\n');print(results)
