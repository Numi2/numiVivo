#include "NumiVivoCore/NumiVivoOmicsGaussian.h"
#define ACCELERATE_NEW_LAPACK
#include <Accelerate/Accelerate.h>
#include <algorithm>
#include <cmath>
#include <cstddef>
#pragma clang fp contract(off) reassociate(off)

extern "C" int32_t nvivo_omics_gaussian_bias(
    const double *source, const double *bias, uint32_t anchors,
    const double *queries, uint32_t query_rows, uint32_t dimensions, double sigma,
    uint64_t source_capacity, uint64_t query_capacity, uint64_t maximum_scalar_terms,
    double *delta, uint64_t delta_capacity, double *totals, uint64_t totals_capacity,
    double *workspace, uint64_t workspace_capacity,
    int32_t (*cancel)(void *), void *context) {
    constexpr uint32_t tile = 256;
    const uint64_t ad = uint64_t(anchors)*dimensions, qd = uint64_t(query_rows)*dimensions;
    if (!source || !bias || !queries || !delta || !totals || !workspace ||
        !anchors || anchors > 200000000 || !query_rows || query_rows > 32 ||
        !dimensions || dimensions > 64 || !std::isfinite(sigma) || sigma < .001 || sigma > 1000 ||
        source_capacity < ad || query_capacity < qd || delta_capacity < qd || totals_capacity < query_rows ||
        workspace_capacity < uint64_t(tile)*(dimensions+query_rows)) return 1;
    if (ad*query_rows > maximum_scalar_terms) return 2;
    if (cancel && cancel(context)) return 5;
    for (uint64_t i=0;i<qd;++i) if (!std::isfinite(queries[i])) return 4;
    std::fill_n(delta,qd,0.); std::fill_n(totals,query_rows,0.);
    double *packed = workspace, *weights = workspace + tile*dimensions;
    for (uint32_t start=0;start<anchors;start+=tile) {
        if (cancel && cancel(context)) return 5;
        const uint32_t count = std::min(tile,anchors-start);
        for (uint32_t a=0;a<count;++a) for (uint32_t j=0;j<dimensions;++j) {
            const auto pos = uint64_t(start+a)*dimensions+j;
            if (!std::isfinite(source[pos]) || !std::isfinite(bias[pos])) return 4;
            packed[j*tile+a] = source[pos];
        }
        std::fill_n(weights,query_rows*count,0.);
        for (uint32_t q=0;q<query_rows;++q) {
            double *dist = weights+q*count;
            for (uint32_t j=0;j<dimensions;++j) {
                const double v = queries[q*dimensions+j];
                const double *column = packed+j*tile;
                // Vectorize independent anchors; never reassociate the dimension sum.
                #pragma clang loop vectorize(enable)
                for (uint32_t a=0;a<count;++a) {
                    const double difference = v-column[a];
                    dist[a] += difference*difference;
                }
            }
            for (uint32_t a=0;a<count;++a) dist[a] *= -.5*sigma;
        }
        const int length = int(query_rows*count);
        vvexp(weights,weights,&length);
        for (uint32_t q=0;q<query_rows;++q)
            for (uint32_t a=0;a<count;++a) totals[q] += weights[q*count+a];
        cblas_dgemm(CblasRowMajor,CblasNoTrans,CblasNoTrans,int(query_rows),int(dimensions),int(count),
            1.,weights,int(count),bias+uint64_t(start)*dimensions,int(dimensions),1.,delta,int(dimensions));
    }
    if (cancel && cancel(context)) return 5;
    for (uint32_t q=0;q<query_rows;++q) {
        if (!std::isfinite(totals[q])) return 4;
        for (uint32_t j=0;j<dimensions;++j) {
            double &v = delta[q*dimensions+j];
            if (!std::isfinite(v)) return 4;
            v = totals[q] > 0 ? v/totals[q] : 0.;
            if (!std::isfinite(v)) return 4;
        }
    }
    return 0;
}
