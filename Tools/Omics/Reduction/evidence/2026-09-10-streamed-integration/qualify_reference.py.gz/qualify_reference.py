import hashlib,json,os,shutil,struct,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parent;local=root.parts[2]=='home'
python='/Users/home/numivivo-singlecell-benchmark-py/bin/python' if local else '/Users/n/numivivo-integration-reference-py/bin/python'
source=root/'check_streamed.py';out=root/('reference-controls' if local else 'reference-real');out.mkdir();env={**os.environ,'OPENBLAS_NUM_THREADS':'1','VECLIB_MAXIMUM_THREADS':'1','OMP_NUM_THREADS':'1'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(path,v):path.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
freeze=dict(sourceSHA256=sha(source),python=python,platform=subprocess.check_output([python,'-c','import platform,numpy,ijson; print(platform.platform(),numpy.__version__,ijson.__version__)'],text=True).strip(),createdAtUnix=time.time());write(out/'freeze.json',freeze);commands=[]
def run(label,bundle,success=True):
 command=[python,str(source),'--bundle',str(bundle),'--out',str(out/(label+'.json'))];start=time.time();r=subprocess.run(command,env=env,capture_output=True,text=True);(out/(label+'.log')).write_text(r.stdout+r.stderr);item=dict(label=label,command=command,returnCode=r.returncode,expectedSuccess=success,seconds=time.time()-start);commands.append(item);write(out/'commands.json',commands);print(label,r.returncode,flush=True);assert r.returncode==(0 if success else 1),(label,r.stderr)
if local:
 fixtures=root.parent/'integration-scratch/admission-fixtures'
 for name in ['fitted-integrated','query-integrated','fitted-adaptive','query-adaptive','fitted-batch']:run(name,fixtures/name)
 for mode in ['memberships','scores','assignment','objective','coordinates','levels']:
  target=out/('tamper-'+mode);shutil.copytree(fixtures/'fitted-integrated',target)
  if mode in ['objective','levels']:
   p=target/'report.json';v=json.loads(p.read_text())
   if mode=='objective':v['objectives'][-1]+=.25
   else:v['cellLevels'][0]=1-v['cellLevels'][0]
   write(p,v)
  else:
   name={'memberships':'memberships.bin','scores':'scores.bin','assignment':'assignment-scores.bin','coordinates':'scores.bin'}[mode];p=target/name;b=bytearray(p.read_bytes())
   if mode=='coordinates':struct.pack_into('<I',b,0,3)
   elif mode=='assignment':struct.pack_into('<d',b,8,float('nan'))
   else:struct.pack_into('<d',b,8,struct.unpack_from('<d',b,8)[0]+.5)
   p.write_bytes(b)
  run(mode,target,False)
else:
 for cohort in ['kang','hagai']:
  for seed in [7,19,41]:run(cohort+'-'+str(seed),root.parent/'integration-scratch/real'/cohort/('seed-'+str(seed)))
assert sha(source)==freeze['sourceSHA256']
write(out/'checks.json',dict(status='passed',commands=len(commands),expectedRejections=sum(not c['expectedSuccess'] for c in commands),sourceSHA256=sha(source),scope='Frozen streaming numerical checker qualification. Small fixtures cover fitted/query, fixed/adaptive and donor/batch behavior plus numerical corruption rejection; complete Kang/Hagai cases cross the 8192-row batch boundary. This is numerical evidence, not new biological preservation.'))
