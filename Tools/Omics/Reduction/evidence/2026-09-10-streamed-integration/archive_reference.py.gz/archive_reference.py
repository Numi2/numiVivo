import gzip,hashlib,json
from pathlib import Path
root=Path('/Users/home/numivivo-hiris-20260910/integration-full');repo=Path('/Users/home/numivivo-single-cell-20260909');out=repo/'Tools/Omics/Reduction/evidence/2026-09-10-streamed-integration'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
source=repo/'Tools/Omics/Reduction/check_streamed_integration.py';identity=sha(source)
for name,count,rejects in [('reference-controls',11,6),('reference-real',6,0)]:
 proof=json.loads((root/name/'checks.json').read_text());assert proof['status']=='passed' and proof['commands']==count and proof['expectedRejections']==rejects and proof['sourceSHA256']==identity
out.mkdir();sources=[]
for name in ['reference-controls','reference-real']:
 sources.extend(p for p in sorted((root/name).rglob('*')) if p.is_file())
sources += [root/name for name in ['check_streamed.py','qualify_reference.py','reference-execution-freeze.json','protocol.json','archive_reference.py']]
records=[]
for p in sources:
 assert not p.is_symlink() and p.stat().st_size<67108864
 raw=p.read_bytes();name=str(p.relative_to(root));stored=name+'.gz';target=out/stored;target.parent.mkdir(parents=True,exist_ok=True)
 with target.open('xb') as f:
  with gzip.GzipFile(fileobj=f,mode='wb',filename='',mtime=0,compresslevel=6) as z:z.write(raw)
 assert sha(p)==hashlib.sha256(raw).hexdigest()
 records.append(dict(sourcePath=name,sourceBytes=len(raw),sourceSHA256=sha(p),storedPath=stored,storedBytes=target.stat().st_size,storedSHA256=sha(target),gzipEncoded=True))
manifest=dict(schemaVersion=1,checkerSHA256=identity,records=records,archiveScriptSHA256=sha(Path(__file__)),scope='Frozen streamed final-objective and categorical ridge checker: fitted/query fixed/adaptive donor/batch fixtures, six numerical corruption rejects, and all six complete Kang/Hagai outputs. Full HIRISA check is predeclared but not completed in this archive; no biological preservation or optimization-trajectory equivalence claim.')
(out/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n');print(json.dumps(dict(members=len(records),storedBytes=sum(r['storedBytes'] for r in records),manifestSHA256=sha(out/'manifest.json'))))
