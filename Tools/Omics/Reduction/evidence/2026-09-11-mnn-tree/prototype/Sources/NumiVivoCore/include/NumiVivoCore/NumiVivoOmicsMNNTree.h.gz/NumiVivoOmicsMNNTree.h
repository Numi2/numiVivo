#ifndef NUMIVIVO_OMICS_MNN_TREE_H
#define NUMIVIVO_OMICS_MNN_TREE_H
#include "NumiVivoCore/NumiVivoCore.h"
#ifdef __cplusplus
extern "C" {
#endif
/* Exact L1 matching on already normalized, finite resident rows. Queries search
 * the union of strictly lower/upper covariate levels; ties use level then source
 * row. Output has k slots per row, -1 for an absent direction. Partial arrays
 * are invalid on failure. Borrowed inputs remain immutable for the call.
 * Work counts construction coordinate visits, bounding-box coordinate terms,
 * and actual point-distance coordinate terms. Bounds include equality for ties.
 * Status: 0 success,1 arguments,2 work limit,4 nonfinite,5 cancelled,7 allocation.
 * index_bytes counts reserved vector storage, excluding allocator bookkeeping.
 */
typedef struct NVivoMNNTreeReport {
    uint64_t construction_scalar_terms, bound_scalar_terms, distance_scalar_terms;
    uint64_t index_bytes;
} NVivoMNNTreeReport;
typedef int32_t (*NVivoMNNTreeCancel)(void *context);
NVIVO_EXPORT int32_t nvivo_omics_mnn_tree(const double *scores,
    const uint32_t *levels, uint32_t rows, uint32_t dimensions, uint32_t neighbors,
    uint32_t level_count, uint64_t maximum_work, int64_t *lower, int64_t *upper,
    uint64_t output_capacity, NVivoMNNTreeReport *report,
    NVivoMNNTreeCancel cancel, void *context);
#ifdef __cplusplus
}
#endif
#endif
