#include "NumiVivoCore/NumiVivoOmicsMNNTree.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <limits>
#include <numeric>
#include <vector>

namespace {
struct Node {
    uint32_t start, end, left, right, minimumLevel, maximumLevel;
};
static_assert(sizeof(Node)<=32);
struct Hit { double distance; uint32_t rank, row; };
bool better(const Hit &a,const Hit &b) {
    return a.distance<b.distance || (a.distance==b.distance && a.rank<b.rank);
}
class Tree {
    const double *x;
    const uint32_t *level;
    uint32_t n,d,k;
    uint64_t maximumWork;
    NVivoMNNTreeReport &report;
    NVivoMNNTreeCancel cancel;
    void *context;
    std::vector<uint32_t> order,rank;
    std::vector<Node> nodes;
    std::vector<double> boxes;
    std::vector<Hit> heap;
    void check() { if(cancel && cancel(context)) throw int32_t(5); }
    void charge(uint64_t &counter,uint64_t count) {
        uint64_t used=report.construction_scalar_terms+report.bound_scalar_terms+report.distance_scalar_terms;
        if(count>maximumWork-used) throw int32_t(2);
        counter+=count;
    }
    uint32_t build(uint32_t start,uint32_t end) {
        check(); const uint32_t id=uint32_t(nodes.size());
        nodes.push_back({start,end,0,0,UINT32_MAX,0});
        boxes.resize(size_t(id+1)*2*d);
        double *lo=boxes.data()+size_t(id)*2*d,*hi=lo+d;
        std::fill(lo,lo+d,INFINITY); std::fill(hi,hi+d,-INFINITY);
        for(uint32_t p=start;p<end;++p) {
            charge(report.construction_scalar_terms,d);
            uint32_t row=order[p];
            nodes[id].minimumLevel=std::min(nodes[id].minimumLevel,level[row]);
            nodes[id].maximumLevel=std::max(nodes[id].maximumLevel,level[row]);
            for(uint32_t j=0;j<d;++j) { double v=x[size_t(row)*d+j];lo[j]=std::min(lo[j],v);hi[j]=std::max(hi[j],v); }
        }
        if(end-start>16) {
            uint32_t axis=0;
            for(uint32_t j=1;j<d;++j) if(hi[j]-lo[j]>hi[axis]-lo[axis]) axis=j;
            uint32_t mid=start+(end-start)/2;
            std::nth_element(order.begin()+start,order.begin()+mid,order.begin()+end,[&](uint32_t a,uint32_t b){
                double av=x[size_t(a)*d+axis],bv=x[size_t(b)*d+axis];
                return av<bv || (av==bv && rank[a]<rank[b]);
            });
            nodes[id].left=build(start,mid); nodes[id].right=build(mid,end);
        }
        return id;
    }
    bool eligible(const Node &node,uint32_t query,bool upper) const {
        return upper ? node.maximumLevel>level[query] : node.minimumLevel<level[query];
    }
    double bound(uint32_t id,uint32_t query) {
        charge(report.bound_scalar_terms,d);
        const double *q=x+size_t(query)*d,*lo=boxes.data()+size_t(id)*2*d,*hi=lo+d;
        double sum=0;
        // Same coordinate order and nonnegative additions as point distances.
        // Each rounded term is <= its corresponding point-distance term.
        for(uint32_t j=0;j<d;++j) sum+=q[j]<lo[j]?lo[j]-q[j]:(q[j]>hi[j]?q[j]-hi[j]:0.0);
        return sum;
    }
    void visit(uint32_t id,uint32_t query,bool upper,double lowerBound) {
        if(heap.size()==k && lowerBound>heap.front().distance) return;
        const Node &node=nodes[id];
        if(!eligible(node,query,upper)) return;
        if(node.end-node.start<=16) {
            for(uint32_t p=node.start;p<node.end;++p) {
                uint32_t row=order[p];
                if(upper ? level[row]<=level[query] : level[row]>=level[query]) continue;
                charge(report.distance_scalar_terms,d);
                double distance=0;
                for(uint32_t j=0;j<d;++j) distance+=std::abs(x[size_t(query)*d+j]-x[size_t(row)*d+j]);
                if(!std::isfinite(distance)) throw int32_t(4);
                Hit h{distance,rank[row],row};
                if(heap.size()<k) { heap.push_back(h);std::push_heap(heap.begin(),heap.end(),better); }
                else if(better(h,heap.front())) { std::pop_heap(heap.begin(),heap.end(),better);heap.back()=h;std::push_heap(heap.begin(),heap.end(),better); }
            }
        } else {
            bool l=eligible(nodes[node.left],query,upper),r=eligible(nodes[node.right],query,upper);
            double lb=l?bound(node.left,query):INFINITY,rb=r?bound(node.right,query):INFINITY;
            if(lb<=rb) { if(l) visit(node.left,query,upper,lb);if(r) visit(node.right,query,upper,rb); }
            else { if(r) visit(node.right,query,upper,rb);if(l) visit(node.left,query,upper,lb); }
        }
    }
 public:
    Tree(const double *x,const uint32_t *level,uint32_t n,uint32_t d,uint32_t k,uint32_t b,
         uint64_t work,NVivoMNNTreeReport &r,NVivoMNNTreeCancel cancel,void *context):
         x(x),level(level),n(n),d(d),k(k),maximumWork(work),report(r),cancel(cancel),context(context),order(n),rank(n) {
        // A balanced nonroot leaf has at least 8 rows, so <= n/4+1 nodes.
        const size_t capacity=n/4+1;
        nodes.reserve(capacity);boxes.reserve(capacity*2*d);heap.reserve(k);
        std::array<uint32_t,128> counts{},offsets{};
        for(uint32_t i=0;i<n;++i) { if(level[i]>=b) throw int32_t(1);++counts[level[i]]; }
        for(uint32_t i=0;i<b;++i) { if(counts[i]<k) throw int32_t(1);if(i) offsets[i]=offsets[i-1]+counts[i-1]; }
        for(uint32_t i=0;i<n;++i) {
            check();rank[i]=offsets[level[i]]++;
            for(uint32_t j=0;j<d;++j) if(!std::isfinite(x[size_t(i)*d+j])) throw int32_t(4);
        }
        std::iota(order.begin(),order.end(),0);
        build(0,n);
        report.index_bytes=order.capacity()*sizeof(uint32_t)+rank.capacity()*sizeof(uint32_t)+
            nodes.capacity()*sizeof(Node)+boxes.capacity()*sizeof(double)+heap.capacity()*sizeof(Hit);
    }
    void query(int64_t *lower,int64_t *upper) {
        for(uint32_t row=0;row<n;++row) {
            check();
            for(int direction=0;direction<2;++direction) {
                heap.clear();visit(0,row,direction==1,0);
                std::sort(heap.begin(),heap.end(),better);
                int64_t *out=(direction?upper:lower)+size_t(row)*k;
                for(uint32_t j=0;j<k;++j) out[j]=j<heap.size()?int64_t(heap[j].row):-1;
            }
        }
    }
};
}
int32_t nvivo_omics_mnn_tree(const double *x,const uint32_t *levels,uint32_t n,uint32_t d,
    uint32_t k,uint32_t b,uint64_t work,int64_t *lower,int64_t *upper,uint64_t capacity,
    NVivoMNNTreeReport *report,NVivoMNNTreeCancel cancel,void *context) {
#pragma clang fp contract(off)
    if(!x || !levels || !lower || !upper || !report || n<2 || n>2000000 || d<1 || d>64 ||
       k<1 || k>100 || b<2 || b>128 || work<1 || work>10000000000000ULL || capacity<uint64_t(n)*k) return 1;
    *report={};
    try { Tree tree(x,levels,n,d,k,b,work,*report,cancel,context);tree.query(lower,upper);return 0; }
    catch(int32_t code) { return code; }
    catch(const std::bad_alloc &) { return 7; }
    catch(...) { return 1; }
}
