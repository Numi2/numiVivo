#!/usr/bin/env python3
"""Independent exhaustive checks of the native exact MNN spatial-tree bridge."""
import argparse,ctypes as C,hashlib,json,time
from pathlib import Path
import numpy as np
class Report(C.Structure):
 _fields_=[(k,C.c_uint64) for k in ('construction','bounds','distances','bytes')]
def invoke(lib,x,levels,k,work=10**13,cancel=False,capacity=None):
 x=np.ascontiguousarray(x,dtype=np.float64);levels=np.ascontiguousarray(levels,dtype=np.uint32);n,d=x.shape
 a=np.full((n,k),-99,dtype=np.int64);b=a.copy();r=Report();callback=C.CFUNCTYPE(C.c_int32,C.c_void_p)(lambda _:int(cancel))
 f=lib.nvivo_omics_mnn_tree
 f.argtypes=[C.POINTER(C.c_double),C.POINTER(C.c_uint32),C.c_uint32,C.c_uint32,C.c_uint32,C.c_uint32,C.c_uint64,C.POINTER(C.c_int64),C.POINTER(C.c_int64),C.c_uint64,C.POINTER(Report),type(callback),C.c_void_p];f.restype=C.c_int32
 start=time.perf_counter();status=f(x.ctypes.data_as(C.POINTER(C.c_double)),levels.ctypes.data_as(C.POINTER(C.c_uint32)),n,d,k,int(levels.max())+1,work,a.ctypes.data_as(C.POINTER(C.c_int64)),b.ctypes.data_as(C.POINTER(C.c_int64)),n*k if capacity is None else capacity,C.byref(r),callback,None)
 return status,a,b,{**{name:int(getattr(r,name)) for name,_ in r._fields_},'seconds':time.perf_counter()-start}
def exhaustive(x,levels,k):
 n=len(x);rank=np.empty(n,dtype=int);order=np.lexsort((np.arange(n),levels));rank[order]=np.arange(n);a=np.full((n,k),-1,dtype=np.int64);b=a.copy()
 for i in range(n):
  # Same scalar coordinate order but independent exhaustive candidate selection.
  ds=np.zeros(n)
  for j in range(x.shape[1]):ds+=np.abs(x[i,j]-x[:,j])
  for dst,mask in [(a,levels<levels[i]),(b,levels>levels[i])]:
   ids=np.flatnonzero(mask);best=ids[np.lexsort((rank[ids],ds[ids]))[:k]];dst[i,:len(best)]=best
 return a,b

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--library',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();lib=C.CDLL(str(a.library));rng=np.random.default_rng(7);checks=[]
 for d in (1,2,20,64):
  for tied in (False,True):
   n=321;levels=np.arange(n,dtype=np.uint32)%3;rng.shuffle(levels);x=rng.normal(size=(n,d))
   if tied:x=np.round(x);x[:40]=0;x[40:60]=x[60]
   for k in (1,20,100):
    status,lower,upper,r=invoke(lib,x,levels,k);assert status==0
    aa,bb=exhaustive(x,levels,k);np.testing.assert_array_equal(lower,aa);np.testing.assert_array_equal(upper,bb)
    status,ll,uu,rr=invoke(lib,x,levels,k);assert status==0;np.testing.assert_array_equal(ll,lower);np.testing.assert_array_equal(uu,upper)
    assert all(r[key]==rr[key] for key in ('construction','bounds','distances','bytes'))
    checks.append(dict(dimensions=d,tied=tied,neighbors=k,**r))
 x=rng.normal(size=(100,3));levels=np.arange(100,dtype=np.uint32)%2
 assert invoke(lib,x,levels,20,work=1)[0]==2
 full=invoke(lib,x,levels,20);w=sum(full[3][key] for key in ('construction','bounds','distances'))
 assert invoke(lib,x,levels,20,work=w)[0]==0 and invoke(lib,x,levels,20,work=w-1)[0]==2
 assert invoke(lib,x,levels,20,cancel=True)[0]==5
 assert invoke(lib,x,levels,20,capacity=1)[0]==1
 x[0,0]=np.nan;assert invoke(lib,x,levels,20)[0]==4
 a.out.write_text(json.dumps(dict(status='passed',cases=checks,budgetBoundaryExact=True,cancellationRejected=True,capacityRejected=True,nonfiniteRejected=True,librarySHA256=hashlib.sha256(a.library.read_bytes()).hexdigest(),scriptSHA256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='All lower/upper query neighbors compared with exhaustive independent ordering; numerical fixtures, no biological qualification.'),indent=2)+'\n');print('24 exhaustive cases and resource rejection checks passed')
if __name__=='__main__':main()
