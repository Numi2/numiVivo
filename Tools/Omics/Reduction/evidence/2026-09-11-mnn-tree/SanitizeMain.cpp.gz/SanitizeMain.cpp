#include "NumiVivoCore/NumiVivoOmicsMNNTree.h"
#include <vector>
#include <cmath>
#include <cstdio>
int main() {
    for(unsigned n: {2u,16u,17u,31u,32u,33u,321u,1025u}) {
        unsigned d=20,k=1;
        std::vector<double> x(n*d);std::vector<uint32_t> levels(n);
        std::vector<int64_t> a(n*k),b(n*k);NVivoMNNTreeReport report{};
        for(unsigned i=0;i<n;++i) { levels[i]=i%2;for(unsigned j=0;j<d;++j)x[i*d+j]=std::sin(double(i*j)); }
        auto run=[&](uint64_t work, NVivoMNNTreeCancel cancel) { return nvivo_omics_mnn_tree(x.data(),levels.data(),n,d,k,2,work,a.data(),b.data(),n*k,&report,cancel,nullptr); };
        if(run(100000000000ULL,nullptr)!=0 || run(1,nullptr)!=2 || run(100000000000ULL,[](void*)->int32_t{return 1;})!=5)return 1;
        x[0]=NAN;if(run(100000000000ULL,nullptr)!=4)return 2;
    }
    std::puts("passed: address/undefined sanitizers, balanced leaf boundaries, cancellation and budget failures");
}
