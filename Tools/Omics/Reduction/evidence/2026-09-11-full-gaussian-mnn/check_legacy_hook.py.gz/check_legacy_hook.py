import sys,ctypes,json,pathlib,time
sys.path.insert(0,'/Users/n/numivivo-h5ad-20260909/Tools/Omics/Reduction/LocalMNN')
from fit import fit,matrix,sha
import numpy as np
p=pathlib.Path('/Users/n/numivivo-native-mnn-20260910/hagai');old=json.loads(pathlib.Path('/Users/n/numivivo-local-mnn-20260911/candidate-v2/hagai/report.json').read_text());reference=json.loads((p/'mnn/report.json').read_text());x=matrix(p/'pca/scores.bin',old['cells'],20);batch=np.array(reference['cellLevels'],dtype=np.uint32)
r=fit(ctypes.CDLL('/Users/n/numivivo-local-mnn-20260911/libLocalNeighbors-v2.dylib'),x,batch,None,old['arraySHA256'])
for key in ('cells','components','scale','zeroDirectionCells','alignments','order','steps','panoramas','arraySHA256'):assert r[key]==old[key],key
out=pathlib.Path('/Users/n/numivivo-full-gaussian-mnn-20260911/legacy-hook-check.json');out.write_text(json.dumps(dict(status='passed',cells=len(x),allOriginalLocal64WitnessArraysAndReportsExact=True,sourceSHA256=sha(pathlib.Path('/Users/n/numivivo-h5ad-20260909/Tools/Omics/Reduction/LocalMNN/fit.py')),seconds=r['fitSeconds'],scope='Complete Hagai regression of unchanged default research assembly after adding an optional kernel callback.'),indent=2)+'\n');print(out.read_text())
