from pathlib import Path
repo=Path('/Users/home/numivivo-single-cell-20260909'); parent=repo/'Tools/Omics/Reduction';old=parent/'LocalMNN/fit.py';s=old.read_text();s=s.replace('def fit(lib,x,batch,out,expected=None):','def fit(lib,x,batch,out,expected=None,*,kernel=None):')
a=s.index('  chosen,ds,r=neighbors(lib,source,query,count);');b=s.index('  corrected[selected]+=delta',a)
block=s[a:b];block=block.replace(";emit('step-'+str(len(steps)),selected=selected,anchors=match,source=source,bias=bias,queries=query,indices=chosen,distances=ds,delta=delta,totalWeights=totals)",";extra=dict(indices=chosen,distances=ds)")
s=s[:a]+'''  if kernel is None:
'''+''.join(' '+line+'\n' for line in block.splitlines())+'''  else:
   delta,totals,r=kernel(source,bias,query);native.append(dict(stage='kernel-'+str(len(steps)),**r));extra={}
  assert np.isfinite(delta).all();emit('step-'+str(len(steps)),selected=selected,anchors=match,source=source,bias=bias,queries=query,delta=delta,totalWeights=totals,**extra)
'''+s[b:];old.write_text(s)
protocol='''# Eligible-level HNSW matching with full Gaussian correction

Declared before this trial's fitting and biological evaluation on 2026-09-11.
This isolates approximate anchor matching from the earlier combined HNSW/local64
failure. It is development on inspected cohorts, not independent validation.

Keep every original Hagai, Kang and Ding cell and original twenty PCs, donor/batch
eligibility, k=20, sigma=15, alignment threshold 0.1, global median norm, tie/order,
panorama/visit rules, merge multiplicity and duplicate anchors. No cell labels,
RNA programs or outcomes enter fit. No subsampling or parameter search.

Reuse the exact eligible-prefix/suffix native HNSW implementation and fixed
hnswlib 0.8.0 M=16, efConstruction=200, efSearch=128, seed=7, FP64 Manhattan
matching on normalized original PCs. Each index has the existing 500-million
metric-evaluation budget. Record every selected neighbor/distance and mutual pair.

Replace only local64 smoothing with the qualified production all-anchor Gaussian
C ABI from c2ce802bf8a77080339a6b46c3b3b12915199b60: direct FP64 squared distances,
32-query/256-anchor tiles, all anchor records retained, vForce exp/BLAS weighted
sum, original scalar fallback below 1e-280 total. Admit at most twice the exact
anchors*queries*dimensions distance work per correction, charging fallback terms.
Retain every full step source/bias/query/delta/total snapshot. No dense cells by
genes array, no truncated Gaussian, no approximate-kernel claim.

Freeze source/library/original input identities before fitting and all outputs
before biological evaluation. Replay every complete output/witness exactly.
Independently recompute every matching distance and all-anchor Gaussian update
from complete step snapshots with NumPy direct distances, exponentials and sums.
Require per-coordinate delta error <= 1e-10*(1+abs(reference)); reconstruct full
final coordinates and report all step and original-coordinate differences.
Compare every pair with the exact original anchors; require global precision and
recall >=0.95, preserve/report changed assembly order. Also compare candidate
matching and anchors with the previous eligible-level run to verify the isolated
intervention. A failure is retained, not repaired by changing parameters.

Use the unchanged complete-cohort 30-neighbor classifiers, every-type recall,
condition/program/within-stratum program margins and fixed original evaluation
inputs. Keep four missing Kang strata and partial Ding source labels. Record
fit/replay time separately from witness I/O and full process wall/RSS. The
physical M4 Pro original mapped-reader baseline remains active. This research
assembly driver is not native Swift public API, a prospective transform,
end-to-end speed comparison, million-cell integration or biological qualification.
Favorable results justify a separately qualified native matching implementation;
no production promotion from this trial alone.
'''
(parent/'FullGaussianMNN/PROTOCOL.md').write_text(protocol)
main=s[s.index('def main():'):]
main=main.replace("('source','manifest','library','out','protocol')","('source','manifest','library','gaussian-library','out','protocol')")
main=main.replace("owner=Path(__file__).parent;manifest", "owner=Path(__file__).parent;manifest")
main=main.replace("lib=C.CDLL(str(a.library));inputs={}","lib=C.CDLL(str(a.library));kernel=Gaussian(a.gaussian_library);inputs={}")
main=main.replace("sourceSHA256={p.name:sha(p) for p in owner.iterdir() if p.suffix in ('.py','.cpp','.md')},librarySHA256=sha(a.library)","sourceSHA256={str(p.relative_to(owner.parent)):sha(p) for p in list(owner.glob('*.py'))+list(owner.glob('*.md'))+[owner.parent/'LocalMNN/fit.py',owner.parent/'LocalMNN/LocalNeighbors.cpp']},librarySHA256=sha(a.library),gaussianLibrarySHA256=sha(a.gaussian_library)")
main=main.replace('r=fit(lib,x,batch,out);','r=fit(lib,x,batch,out,kernel=kernel);').replace("again=fit(lib,x,batch,out,r['arraySHA256']);","again=fit(lib,x,batch,out,r['arraySHA256'],kernel=kernel);")
main=main.replace("for key in ('stage','construction','query','indexBytes'):assert first[key]==second[key]","assert {k:v for k,v in first.items() if k!='seconds'}=={k:v for k,v in second.items() if k!='seconds'}")
head='''#!/usr/bin/env python3
"""Fixed eligible-level approximate matching with qualified all-anchor Gaussian."""
import argparse,ctypes as C,sys,time
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'LocalMNN'))
from fit import fit,sha,read,write,matrix
D=C.POINTER(C.c_double);U=C.c_uint32;L=C.c_uint64
class Gaussian:
 def __init__(self,path):
  self.lib=C.CDLL(str(path));self.f=self.lib.nvivo_omics_gaussian_bias
  self.f.restype=C.c_int32;self.f.argtypes=[D,D,U,D,U,U,C.c_double,L,L,L,D,L,D,L,D,L,C.POINTER(L),C.c_void_p,C.c_void_p]
 def __call__(self,source,bias,queries):
  start=time.perf_counter();source,bias,queries=[np.ascontiguousarray(x,dtype=np.float64) for x in (source,bias,queries)]
  na,d=source.shape;nq=len(queries);assert bias.shape==source.shape and queries.shape==(nq,d)
  delta=np.empty_like(queries);totals=np.empty(nq);workspace=np.empty(256*(d+32));terms=0;budget=2*na*nq*d
  ptr=lambda x:x.ctypes.data_as(D)
  for first in range(0,nq,32):
   q=queries[first:first+32];out=delta[first:first+32];total=totals[first:first+32];evaluated=L()
   status=self.f(ptr(source),ptr(bias),na,ptr(q),len(q),d,15.,source.size,q.size,budget-terms,ptr(out),out.size,ptr(total),len(total),ptr(workspace),workspace.size,C.byref(evaluated),None,None)
   assert status==0,('Gaussian status',status);terms+=evaluated.value
  assert na*nq*d<=terms<=budget and np.isfinite(delta).all() and np.isfinite(totals).all()
  return delta,totals,dict(distanceTerms=terms,maximumDistanceTerms=budget,workspaceBytes=workspace.nbytes,seconds=time.perf_counter()-start)

'''
(parent/'FullGaussianMNN/run.py').write_text(head+main)
