from pathlib import Path
root=Path('/Users/home/numivivo-single-cell-20260909/Tools/Omics/Reduction');s=(root/'LocalMNN/check_numerics.py').read_text().replace('Reconstruct every recorded local update and measure complete exact-anchor recall.','Independently reconstruct every full Gaussian update and all matching distances.')
s=s.replace("('source','root','out')","('source','root','previous','out')")
a=s.index("   z=np.load(r/('step-'");b=s.index('   current[selected]+=delta;',a)
s=s[:a]+'''   z=np.load(r/('step-'+str(number)+'.npz'));selected=z['selected'];match=z['anchors'];source=z['source'];bias=z['bias'];query=z['queries'];delta=z['delta']
   assert np.array_equal(selected,np.concatenate([rows[b] for b in step['target']]))
   assert np.array_equal(source,current[match[:,0]]) and np.array_equal(bias,current[match[:,1]]-source) and np.array_equal(query,current[selected])
   for first in range(0,len(query),64):
    end=min(len(query),first+64);count=end-first;denom=np.zeros(count);numerator=np.zeros((count,d))
    for anchor in range(0,len(source),256):
     ss=source[anchor:anchor+256];dd=np.zeros((count,len(ss)))
     for j in range(d):
      difference=query[first:end,j,None]-ss[None,:,j];dd+=difference*difference
     weights=np.exp(-7.5*dd);denom+=weights.sum(axis=1);numerator+=weights@bias[anchor:anchor+256]
    expected=np.divide(numerator,denom[:,None],out=np.zeros_like(numerator),where=denom[:,None]>0)
    # Original cohorts must not silently test a different underflow convention.
    assert np.all((denom==0)|(denom>=1e-280)),'Subnormal full-cohort row requires explicit independent scalar oracle'
    np.testing.assert_allclose(denom,z['totalWeights'][first:end],rtol=1e-10,atol=1e-280)
    error=float(np.max(np.abs(expected-delta[first:end])));max_delta_error=max(max_delta_error,error)
    assert np.all(np.abs(expected-delta[first:end])<=1e-10*(1+np.abs(expected)))
'''+s[b:]
a=s.index("  base=np.fromfile(old/'mnn/scores.bin'")
s=s[:a]+'''  previous=read(a.previous/c/'report.json')
  for name in ('matching','anchors'):assert report['arraySHA256'][name]==previous['arraySHA256'][name],('Changed matching intervention',c,name)
  assemblyOrderOriginalExact=report['order']==read(old/'mnn/report.json')['alignmentOrder']
'''+s[a:]
s=s.replace('maximumKernelDistanceError=max_kernel_error,','fullGaussianDistanceTerms=sum(s[\'distanceTerms\'] for s in report[\'native\'] if s[\'stage\'].startswith(\'kernel-\')),matchingAndAnchorsPreviousExact=True,assemblyOrderOriginalExact=assemblyOrderOriginalExact,')
s=s.replace('all selected updates checked','all full Gaussian updates checked')
s=s.replace('Every selected distance and local update checked; all complete-cohort anchors compared with exact original reference. No full-Gaussian approximation bound or biological qualification.','Every selected matching distance and every full-anchor Gaussian update independently checked; all original complete-cohort anchors compared. Matching is approximate; no independent biological or million-cell qualification.')
(root/'FullGaussianMNN/check_numerics.py').write_text(s)
# Reuse unchanged evaluator implementation, with honest method scope.
s=(root/'LocalMNN/evaluate.py').read_text().replace('Development local correction on inspected full cohorts','Development approximate matching with full Gaussian correction on inspected full cohorts')
(root/'FullGaussianMNN/evaluate.py').write_text(s)
