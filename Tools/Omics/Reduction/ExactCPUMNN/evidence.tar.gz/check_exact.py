from pathlib import Path
import json,hashlib
import numpy as np
r=Path(__file__).parent;source=Path('/Users/n/numivivo-native-mnn-20260910')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads((r/'candidate/outputs-frozen.json').read_text());inputs=json.loads((r/'candidate/freeze.json').read_text())['inputs'];results=[]
for name,h in f['files'].items():assert sha(r/'candidate'/name)==h
for c in ['hagai','kang','ding']:
 old=source/c;p=r/'candidate'/c
 for n in ['pca/scores.bin','mnn/scores.bin','mnn/anchors.bin','mnn/report.json']:assert sha(old/n)==inputs[c+'/'+n]
 meta=json.loads((old/'mnn/report.json').read_text());report=json.loads((p/'report.json').read_text());batch=np.array(meta['cellLevels']);n=len(batch)
 raw=np.fromfile(old/'pca/scores.bin',dtype=[('row','<u4'),('column','<u4'),('value','<f8')]);x=raw['value'].reshape(n,20);norm=np.zeros(n)
 for j in range(20):norm+=x[:,j]*x[:,j]
 norm=np.sqrt(norm);unit=np.divide(x,norm[:,None],out=np.zeros_like(x),where=norm[:,None]>0)
 matching=np.load(p/'matching.npz');ids=matching['indices'];ds=matching['distances'];maximum=0
 for direction in range(2):
  for start in range(0,n,1024):
   idx=ids[direction,start:start+1024];valid=idx>=0;q=unit[start:start+1024];dist=np.sum(abs(unit[np.maximum(idx,0)]-q[:,None,:]),axis=2)
   maximum=max(maximum,float(np.max(abs(dist[valid]-ds[direction,start:start+1024][valid]),initial=0)))
   relation=batch[np.maximum(idx,0)]<batch[start:start+len(q),None] if direction==0 else batch[np.maximum(idx,0)]>batch[start:start+len(q),None]
   assert relation[valid].all()
 assert maximum<1e-12
 exact=np.fromfile(old/'mnn/anchors.bin',dtype=[('first','<u4'),('second','<u4'),('distance','<f8')]);e=exact['first'].astype(np.int64)*n+exact['second'];a=np.load(p/'anchors.npz');pairs=np.concatenate([a[k] for k in a.files]);keys=pairs[:,0]*n+pairs[:,1]
 assert len(keys)==len(np.unique(keys)) and np.array_equal(np.sort(keys),np.sort(e))
 reference=np.fromfile(old/'mnn/scores.bin',dtype=raw.dtype)['value'].reshape(n,20);y=np.load(p/'scores.npz')['scores'];error=abs(y-reference)
 assert np.all(error<=1e-10*(1+abs(reference)))
 counts=np.bincount(batch);expected=int(n*n-np.sum(counts*counts));actual=report['native'][0]['query'];assert actual==expected
 assert report['order']==meta['assemblyOrder']
 results.append(dict(cohort=c,cells=n,anchors=len(e),allAnchorsExact=True,matchingDistanceEvaluations=actual,maximumMatchingDistanceError=maximum,maximumCoordinateError=float(error.max()),coordinateRMSE=float(np.sqrt(np.mean(error**2))),matchingSeconds=report['native'][0]['seconds'],fitSeconds=report['fitSeconds'],orderExact=True));print(results[-1],flush=True)
with (r/'exact-check.json').open('x') as out:json.dump(dict(results=results,outputsFreezeSHA256=sha(r/'candidate/outputs-frozen.json'),checkerSHA256=sha(Path(__file__)),scope='All selected matching distances, all exact native anchors and full final coordinates checked; no new independent biological validation'),out,indent=2)
