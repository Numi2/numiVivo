# Frozen distance-tail exact refinement

Development reuse of complete Hagai, Kang and Ding cohorts. Keep ef512 HNSW,
M16, construction200, seed7, k20 and full-Gaussian sigma15 panorama assembly.
For each donor/batch level and eligible lower/upper direction separately, choose
ceil(0.05 * number of level cells) queries with largest approximate kth-neighbor
Manhattan distance. Break selection ties by ascending original source row.
Exhaustively recompute all eligible neighbors for those queries with the native
exact grouped-source-index distance tie rule. Do not select using labels,
reference anchors, biological outcomes or comparison to another search width.
Keep other approximate queries unchanged. This is a fixed heuristic, not an
exactness certificate for unrefined queries. All original cohorts, cells,
biological margins, missing strata and full-kernel checks remain. Freeze inputs,
source and protocol before fitting. No post-score tuning or product promotion.
