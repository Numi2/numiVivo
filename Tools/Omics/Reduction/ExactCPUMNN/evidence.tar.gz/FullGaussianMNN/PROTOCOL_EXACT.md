# Exhaustive native CPU matching benchmark

Use the already qualified native exact-refinement kernel for every eligible
query on the complete original Hagai, Kang and Ding cohorts. Do not run HNSW or
select by geometry/labels. Match original normalized PCA with Manhattan distance,
k20 and grouped-source-index ties; preserve full Gaussian sigma15 and panorama
assembly. Partition execution by donor/batch level and search direction, with
500 million distance evaluations admitted per partition and every partition
required. No cohort or cell subset, no approximate admission or changed biological
gate. Record total matching distance evaluations and timing, complete replay and
all exact anchor comparisons. Freeze source/protocol/inputs/library before fit.
Existing cohorts are development evidence, not independent validation. This is
a research CPU benchmark, not yet a production Swift or million-cell run.
