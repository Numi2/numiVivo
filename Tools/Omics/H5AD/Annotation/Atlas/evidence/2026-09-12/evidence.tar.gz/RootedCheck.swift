import Foundation
import Darwin
func reject(_ body: () throws -> Void) throws {
    do { try body() } catch { return }
    throw NSError(domain: "expected rejection", code: 1)
}
@main struct Check {
 static func main() async throws {
    let root=URL(fileURLWithPath:CommandLine.arguments[1]);try FileManager.default.createDirectory(at:root,withIntermediateDirectories:false)
    let store=try VivoRootedFileStore(rootURL:root,createIfNeeded:false),source=root.appendingPathComponent("source")
    let bytes=Data((0..<(2_097_152+31)).map { UInt8($0%251) });try bytes.write(to:source)
    for clone in [true,false] {
      let name=clone ? "cloned" : "streamed"
      guard try store.writeFile(from:source,relative:name,maximumBytes:bytes.count,immutable:true,preferClone:clone),try store.readFile(name,maximumBytes:bytes.count)==bytes else { fatalError("copy mismatch") }
      guard try !store.writeFile(from:source,relative:name,maximumBytes:bytes.count,immutable:true,preferClone:clone) else { fatalError("overwrite") }
      try reject { _ = try store.writeFile(from:source,relative:"too-large",maximumBytes:bytes.count-1,immutable:true,preferClone:clone) }
      let attrs=try FileManager.default.attributesOfItem(atPath:root.appendingPathComponent(name).path),original=try FileManager.default.attributesOfItem(atPath:source.path)
      guard attrs[.systemFileNumber] as! NSNumber != original[.systemFileNumber] as! NSNumber,(attrs[.posixPermissions] as! NSNumber).intValue==0o600 else { fatalError("inode or permissions") }
    }
    let handle=try FileHandle(forWritingTo:source);try handle.write(contentsOf:Data([255]));try handle.close()
    guard try store.readFile("cloned",maximumBytes:bytes.count)==bytes,try store.readFile("streamed",maximumBytes:bytes.count)==bytes else { fatalError("source mutation leaked") }
    let cloneHandle=try FileHandle(forWritingTo:root.appendingPathComponent("cloned"));try cloneHandle.seek(toOffset:1);try cloneHandle.write(contentsOf:Data([254]));try cloneHandle.close()
    let changed=try Data(contentsOf:source);guard changed[0]==255,changed[1]==1 else { fatalError("clone mutation leaked") }
    try FileManager.default.createSymbolicLink(atPath:root.appendingPathComponent("alias").path,withDestinationPath:source.path)
    try FileManager.default.createSymbolicLink(atPath:root.appendingPathComponent("linked-parent").path,withDestinationPath:root.path)
    for clone in [true,false] {
      try reject { _ = try store.writeFile(from:root.appendingPathComponent("alias"),relative:"bad-source",maximumBytes:bytes.count,immutable:true,preferClone:clone) }
      try reject { _ = try store.writeFile(from:source,relative:"linked-parent/escape",maximumBytes:bytes.count,immutable:true,preferClone:clone) }
      try reject { _ = try store.writeFile(from:source,relative:"../escape",maximumBytes:bytes.count,immutable:true,preferClone:clone) }
      guard try !store.writeFile(from:source,relative:"alias",maximumBytes:bytes.count,immutable:true,preferClone:clone) else { fatalError("symlink overwrite") }
      guard try store.writeFile(from:source,relative:"mutable",maximumBytes:bytes.count,immutable:false,preferClone:clone) else { fatalError("mutable publication") }
      guard try store.readFile("mutable",maximumBytes:bytes.count)==changed else { fatalError("replacement mismatch") }
      let task=Task { while !Task.isCancelled { await Task.yield() };return try store.writeFile(from:source,relative:"cancelled",maximumBytes:bytes.count,immutable:true,preferClone:clone) };task.cancel()
      do { _ = try await task.value;fatalError("cancellation ignored") } catch is CancellationError {} 
    }
    guard try FileManager.default.contentsOfDirectory(atPath:root.path).allSatisfy({ !$0.hasPrefix(".nv-") }),!FileManager.default.fileExists(atPath:root.appendingPathComponent("cancelled").path) else { fatalError("temporary leak") }
    print("PASS: preferred cloning and forced streaming; bytes, independent inodes, bidirectional mutation isolation, permissions, bounds, immutable/mutable publication, source/parent symlinks, traversal, cancellation and cleanup")
 }
}
