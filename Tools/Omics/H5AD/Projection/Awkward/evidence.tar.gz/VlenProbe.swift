import Foundation
@main struct Probe { static func main() throws {
 let data=try Data(contentsOf:URL(fileURLWithPath:CommandLine.arguments[1]))
 for capacity in [1024,4096,8192,16384,32768,65536,131072] {
 var output=[UInt8](repeating:0,count:capacity)
 let count=data.withUnsafeBytes { input in output.withUnsafeMutableBufferPointer { out in VivoHDF5.decodeLZF(input:input.baseAddress!.assumingMemoryBound(to:UInt8.self),count:data.count,output:out.baseAddress!,capacity:capacity) } }
 print(capacity,count)
 }
} }
