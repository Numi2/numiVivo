import Foundation

public enum VivoOmicsError: Error, LocalizedError, Sendable {
    case invalid(String)
    case limit(String)
    public var errorDescription: String? {
        switch self {
        case .invalid(let value): return "omics: \(value)"
        case .limit(let value): return "omics resource limit: \(value)"
        }
    }
}

