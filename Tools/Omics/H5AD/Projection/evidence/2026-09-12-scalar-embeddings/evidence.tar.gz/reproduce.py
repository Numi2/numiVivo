from pathlib import Path
import shutil,h5py,numpy as np,anndata as ad,json,hashlib,subprocess,warnings
r=Path(__file__).parent;p=r/'scalar.h5ad';shutil.copy2('/Users/home/numivivo-numeric-categories-20260912/integer.h5ad',p)
with h5py.File(p,'r+') as f:
 for name,n in [('obsm',len(f['obs'])),('varm',len(f['var'])),('raw.varm',len(f['raw.var']))]:
  if name in f:del f[name]
  a=np.zeros(n,dtype=[('scalar','<f8'),('vector','<f4',(2,))]);a['scalar']=np.arange(n)*.25;a['vector']=np.arange(n*2).reshape(n,2);f[name]=a
with warnings.catch_warnings():warnings.simplefilter('ignore');x=ad.read_h5ad(p)
print('Reference shapes',x.obsm['scalar'].shape,x.varm['scalar'].shape,x.raw.varm['scalar'].shape)
plan=r/'plan.json';plan.write_text(json.dumps({'schemaVersion':1,'source':{'bytes':list(hashlib.sha256(p.read_bytes()).digest())},'provenance':'Scalar legacy embedding interoperability reproduction'}))
x=subprocess.run(['/Users/home/numivivo-numeric-categories-20260912/build/h5ad-check','project',str(p),str(plan),str(r/'before')],capture_output=True,text=True);(r/'before.log').write_text(x.stdout+x.stderr);print(x.returncode,x.stdout,x.stderr)
