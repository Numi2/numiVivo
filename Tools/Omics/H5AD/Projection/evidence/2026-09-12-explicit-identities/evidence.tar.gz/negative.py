from pathlib import Path
import json,subprocess,shutil,hashlib
import h5py,numpy as np
r=Path(__file__).parent;out=r/'negative';out.mkdir(exist_ok=False);source=r/'checks/modern-signed-annotated.h5ad';mapping=json.loads((r/'checks/modern-signed-X-mapping.json').read_text());cases=[]
def reject(name,p,plan):
 f=out/(name+'.json');f.write_text(json.dumps(plan));dest=out/name;x=subprocess.run([str(r/'build/h5ad-check'),'count-store',str(p),str(f),str(dest)],capture_output=True,text=True);(out/(name+'.log')).write_text(x.stdout+x.stderr);assert x.returncode!=0 and not dest.exists(),name;cases.append({'case':name,'status':'expected-rejection','diagnostic':x.stdout+x.stderr})
for key in ['barcodeColumn','featureIDColumn','featureNameColumn']:
 m=dict(mapping);del m[key];reject('no-'+key,source,m)
for name in ['short-barcode','duplicate-barcode','missing-barcode','bad-index-shape']:
 p=out/(name+'.h5ad');shutil.copy2(source,p)
 with h5py.File(p,'r+') as f:
  if name=='bad-index-shape':
   idx=f['obs'].attrs['_index'];del f['obs'][idx];d=f['obs'].create_dataset(idx,data=np.zeros((7,1),dtype='i8'));d.attrs['encoding-type']='array';d.attrs['encoding-version']='0.2.0'
  else:
   del f['obs/mapped_barcode']
   if name=='missing-barcode':
    g=f['obs'].create_group('mapped_barcode');g.attrs['encoding-type']='nullable-string-array';g.attrs['encoding-version']='0.1.0';g.attrs['na-value']='NaN';g.create_dataset('values',data=np.array(['x']*7,dtype=object),dtype=h5py.string_dtype());g.create_dataset('mask',data=np.array([True]+[False]*6))
   else:
    a=['x']*7 if name=='duplicate-barcode' else [f'c{i}' for i in range(6)];d=f['obs'].create_dataset('mapped_barcode',data=np.array(a,dtype=object),dtype=h5py.string_dtype());d.attrs['encoding-type']='string-array';d.attrs['encoding-version']='0.2.0'
 reject(name,p,mapping)
(out/'summary.json').write_text(json.dumps({'status':'passed','cases':cases},indent=2)+'\n');print('Passed',len(cases),'rejections')
