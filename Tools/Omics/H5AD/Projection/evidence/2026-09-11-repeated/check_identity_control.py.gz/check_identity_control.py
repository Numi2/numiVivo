import os,json,hashlib,subprocess
from pathlib import Path
r=Path('/Users/home/numivivo-repeated-projection-20260911');binary=r/'h5ad-check';env={**os.environ,'NUMIVIVO_HDF5_LIBRARY':'/Users/home/numivivo-multiassay-hdf5-20260909/libhdf5.dylib'};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan=json.loads((r/'identity-plan.json').read_text());plan.update(observationIndices=[0],featureIndices=[0]);(r/'identity-control-plan.json').write_text(json.dumps(plan)+'\n')
source='/Users/home/numivivo-file-integration-20260909/prepared/kang.h5ad';mapping=str(r/'checks-v2/real-0-mapping.json')
commands=[('control-project',[str(binary),'project',source,str(r/'identity-control-plan.json'),str(r/'identity-control')],0),('control-import',[str(binary),str(r/'identity-control/projected.h5ad'),mapping,str(r/'identity-control-import')],0),('repeat-verify',[str(binary),'verify-project',str(r/'identity-projection')],0),('repeat-import',[str(binary),str(r/'identity-projection/projected.h5ad'),mapping,str(r/'identity-import-recheck')],1)]
checks=[]
for name,args,expected in commands:
 p=subprocess.run(args,env=env,capture_output=True,text=True);log=p.stdout+p.stderr;(r/(name+'.log')).write_text(log);assert (p.returncode==0)==(expected==0),(name,log)
 if expected:assert not Path(args[-1]).exists() and 'cell identity, sample reference or group' in log
 checks.append(dict(case=name,exitCode=p.returncode,logSHA256=sha(r/(name+'.log'))))
d=json.loads((r/'boundaries.json').read_text());d['identityControl']=checks;d['scope']='Repeated-axis files preserve names; a matched one-cell/feature count import succeeds while repeated cell identities are rejected. Legacy unversioned input and resident count-import source bounds remain.';d['retainedHarnessFailure']='The first small-file assertion expected the word unique; native correctly reports its existing compound cell identity diagnostic. Matched unique control and repeat verification/rejection now pass.';(r/'boundaries.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(checks))
