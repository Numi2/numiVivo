from pathlib import Path
p=Path('/Users/home/numivivo-single-cell-20260909/Tools/Omics/H5AD/Projection/check.py');s=p.read_text().replace("'NUMIVIVO_HDF5_LIBRARY':'/opt/homebrew/opt/hdf5/lib/libhdf5.dylib'","'NUMIVIVO_HDF5_LIBRARY':os.environ.get('NUMIVIVO_HDF5_LIBRARY','/opt/homebrew/opt/hdf5/lib/libhdf5.dylib')")
s=s.replace("lookup=np.full(minor_length,-1,dtype='int64');lookup[minor]=np.arange(len(minor))", "multiplicity=np.bincount(minor,minlength=minor_length);offsets=np.r_[0,np.cumsum(multiplicity)];destinations=np.argsort(minor,kind='stable')")
s=s.replace("start,end=int(ptr[row]),int(ptr[row+1]);index=old['indices'][start:end];values=old['data'][start:end];mapped=lookup[index];keep=mapped>=0\n      expected_indices.append(mapped[keep]);expected_data.append(values[keep]);expected_ptr.append(expected_ptr[-1]+int(keep.sum()))", "start,end=int(ptr[row]),int(ptr[row+1]);index=old['indices'][start:end];values=old['data'][start:end];copies=multiplicity[index]\n      source_positions=np.repeat(np.arange(len(index)),copies);rank=np.arange(len(source_positions))-np.repeat(np.cumsum(copies)-copies,copies)\n      mapped=destinations[offsets[index[source_positions]]+rank]\n      expected_indices.append(mapped);expected_data.append(values[source_positions]);expected_ptr.append(expected_ptr[-1]+len(mapped))")
s=s.replace(" case(kind+'-reorder',source,[5,1,6,0],[8,2,0,6], 'format-regression')", " case(kind+'-reorder',source,[5,1,6,0],[8,2,0,6], 'format-regression')\n case(kind+'-repeat',source,[5,1,5,6,1,0],[8,2,8,0,2,6], 'repeated-axis-format')")
s=s.replace("case('sparse-duplicates',source,[0,5,1],[2,8,1,0],'format-regression')", "case('sparse-duplicates',source,[0,5,1],[2,8,1,0],'format-regression')\ncase('sparse-duplicates-repeat',source,[0,5,0,1],[2,8,2,1,0,2],'repeated-axis-format')\n# A single sparse source entry expands beyond the 65,536-value transfer bound.\nfor kind in ('csr','csc','dense'):\n values=np.array([[11,0,7],[0,4,0]],dtype='uint64')\n values[0,0]=2**53+3\n matrix=sparse.csr_matrix(values) if kind=='csr' else sparse.csc_matrix(values) if kind=='csc' else values\n large=a.out/(kind+'-repeat-buffer-source.h5ad');ad.AnnData(matrix).write_h5ad(large)\n rr,cc=([1,0,1],[1]*65537+[2,0,1]) if kind!='csc' else ([1]*65537+[0,1,0],[1,0,1])\n case(kind+'-repeat-buffer',large,rr,cc,'repeated-axis-transfer-boundary')")
# Add repeated full-axis cases after the regular source reimport loop, separately.
needle='# Rejection must never publish a partial destination.'
s=s.replace(needle,"""# Retain every original real cell/feature, reorder and repeat declared positions.
for i,source in enumerate(a.real):
 original=ad.read_h5ad(source);n,m=original.shape
 rr=list(range(n-1,-1,-1))+[0,n//2,n-1];cc=list(range(m-1,-1,-1))+[0,m//2,m-1]
 case('real-repeat-'+str(i),source,rr,cc,'complete-source-repeated-axis-interoperability')
 del original
"""+needle)
s=s.replace("('duplicate',{'observationIndices':[0,0]})","('negative-index',{'observationIndices':[-1,0]})")
# Explicit small source / large repeated sparse-output admission rejection.
needle='# Unknown aligned encoding cannot be silently retained with the original axis.'
s=s.replace(needle,"""expanded=a.out/'expanded-source.h5ad';ad.AnnData(sparse.csr_matrix([[1]],dtype='uint64')).write_h5ad(expanded)
expanded_plan=a.out/'expanded-plan.json';expanded_plan.write_text(json.dumps(plan_for(expanded,[0]*70000,[0]*70000))+'\\n')
summary['negativeCases'].append(dict(name='repeated-sparse-work-limit',**invoke(expanded,expanded_plan,a.out/'expanded-output','expanded-work',reject=True)))
"""+needle)
p.write_text(s)
