import os,json,hashlib,subprocess
from pathlib import Path
r=Path('/Users/home/numivivo-repeated-projection-20260911');binary=r/'h5ad-check';env={**os.environ,'NUMIVIVO_HDF5_LIBRARY':'/Users/home/numivivo-multiassay-hdf5-20260909/libhdf5.dylib'};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();results=[]
legacy=Path('/Users/home/numivivo-file-integration-20260909/kang-original.h5ad');plan=dict(schemaVersion=1,source=dict(bytes=list(bytes.fromhex(sha(legacy)))),provenance='Retain explicit legacy-encoding boundary',observationIndices=[0,0],featureIndices=[0]);(r/'legacy-plan.json').write_text(json.dumps(plan)+'\n')
commands=[('legacy-projection',[str(binary),'project',str(legacy),str(r/'legacy-plan.json'),str(r/'legacy-output')]),('repeated-analysis-identities',[str(binary),str(r/'checks-v2/real-repeat-0/projected.h5ad'),str(r/'checks-v2/real-0-mapping.json'),str(r/'repeated-import')])]
for name,args in commands:
 p=subprocess.run(args,env=env,capture_output=True,text=True);log=p.stdout+p.stderr;(r/(name+'.log')).write_text(log);assert p.returncode!=0 and not Path(args[-1]).exists(),(name,p.returncode);print(name,log[-1200:]);results.append(dict(case=name,exitCode=p.returncode,noPartialOutput=True,command=args,logSHA256=sha(r/(name+'.log'))))
(r/'boundaries.json').write_text(json.dumps(dict(status='expected-rejections-retained',cases=results,scope='Repeated-index file projection does not relax unique analytical identities; legacy unversioned source remains unsupported.'),indent=2)+'\n')
