from pathlib import Path
import hashlib,json
r=Path('/Users/home/numivivo-legacy-projection-20260911');remote=Path('/Users/n/numivivo-legacy-projection-20260911')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
j=json.loads((r/'native-checks/summary.json').read_text());assert j['status']=='passed';records=[]
for c in j['cases']:
 for name in ['original.h5ad','projected.h5ad']:
  retained=r/'checks'/c['name']/name;assert sha(retained)==c['files'][name]
  records.append(dict(path=str(remote/'native-checks'/c['name']/name),retainedPath=str(retained),bytes=retained.stat().st_size,SHA256=sha(retained)))
for retained in sorted((r/'native-reference').glob('*.h5ad')):
 records.append(dict(path=str(remote/'native-reference'/retained.name),retainedPath=str(retained),bytes=retained.stat().st_size,SHA256=sha(retained)))
(r/'cleanup-plan.json').write_text(json.dumps(dict(scope='Only this turn duplicate Mac mini H5AD payloads, verified against retained local files; logs, plans, receipts, source and runtimes stay',files=records,totalBytes=sum(x['bytes'] for x in records)),indent=2)+'\n');print(len(records),sum(x['bytes'] for x in records))
