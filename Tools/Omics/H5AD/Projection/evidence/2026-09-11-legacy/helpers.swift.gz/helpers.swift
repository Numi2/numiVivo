
private extension VivoH5ADProjector {
    func legacyScalarKind(_ type: Int64) throws -> String {
        switch try h.legacyTypeKind(type) {
        case 0,1,8:return "array"
        case 3:return "string-array"
        default:throw VivoOmicsError.invalid("unsupported legacy scalar datatype")
        }
    }
    func elementKind(_ object: Int64) throws -> String {
        if try h.legacyHasAttribute(object,"encoding-type") { return try h.text(object,"encoding-type") }
        guard legacy,try !h.legacyHasAttribute(object,"encoding-version") else { throw VivoOmicsError.invalid("missing aligned encoding") }
        if try h.legacyObjectKind(object)==2 {
            guard try h.legacyHasAttribute(object,"h5sparse_format") else { throw VivoOmicsError.invalid("unsupported legacy aligned group") }
            let format=try h.text(object,"h5sparse_format")
            guard ["csr","csc"].contains(format) else { throw VivoOmicsError.invalid("unsupported legacy sparse format") };return format+"_matrix"
        }
        guard try h.legacyObjectKind(object)==5 else { throw VivoOmicsError.invalid("legacy aligned object kind") }
        let t=try h.type(object,attribute: false);defer { h.close(t,"H5Tclose") };return try legacyScalarKind(t)
    }
    func legacyMember(_ source: Int64,_ destination: Int64,_ name: String,member: String,type: Int64,rows: [Int],length: Int,trailing: [UInt64],path: String) throws {
        guard fields.count<100_000,trailing.allSatisfy({ $0>0 && $0<=2_000_000 }) else { throw VivoOmicsError.limit("legacy field shape") }
        let base=try h.legacyBaseType(type);defer { h.close(base,"H5Tclose") }
        let kind=try legacyScalarKind(base),components=try h.count(trailing,maximum: 65_536)
        guard rows.count<=remaining/components else { throw VivoOmicsError.limit("legacy aligned element visits") }
        let count=rows.count*components;try consume(count);try reserveStorage(count*typeWidth(base),output: destination)
        let shape=[UInt64(rows.count)]+trailing
        let out=try h.projectionDataset(destination,name,type: base,shape: shape);defer { h.close(out,"H5Dclose") }
        try h.encoding(out,kind,"0.2.0")
        let memory=try h.legacyMemoryType(member,type);defer { h.close(memory,"H5Tclose") }
        guard try typeWidth(memory)==components*typeWidth(base) else { throw VivoOmicsError.invalid("legacy member storage width") }
        for start in stride(from: 0,to: rows.count,by: 65_536/components) {
            let end=min(rows.count,start+65_536/components)
            try h.legacyTransfer(source,out,memoryType: memory,outputType: base,rows: rows[start..<end].map(UInt64.init),components: components,
                outputStart: [UInt64(start)]+trailing.map { _ in 0 },outputCount: [UInt64(end-start)]+trailing,
                reserveVariableBytes: { try self.reserveStorage($0,output: out) })
        }
        fields.append(.init(path: path,encoding: "legacy-compound/"+kind,sourceShape: [length]+trailing.map(Int.init),outputShape: shape.map(Int.init)))
    }
    func legacyCategory(_ source: Int64,_ destination: Int64,column: String,type: Int64,rows: [Int],length: Int,path: String) throws -> Bool {
        guard ["obs","var"].contains(path),try h.legacyTypeKind(type)==0,try h.exists(root,"uns") else { return false }
        let uns=try h.object(root,"uns");defer { h.close(uns,"H5Oclose") }
        let matches=try h.projectionNames(uns).filter { $0.hasSuffix("_categories") && $0.replacingOccurrences(of: "_categories",with: "")==column }
        guard matches.count<=1 else { throw VivoOmicsError.invalid("ambiguous legacy category definitions") }
        guard let key=matches.first else { return false }
        let cats=try h.dataset(uns,key);defer { h.close(cats,"H5Dclose") }
        let shape=try h.projectionShape(cats)
        guard shape.count<=1 else { throw VivoOmicsError.invalid("legacy categories must be scalar or vector") }
        let count=shape.isEmpty ? 1 : Int(shape[0]);guard count<=100_000 else { throw VivoOmicsError.limit("legacy categories") }
        var tooLarge=false,tooSmall=false
        for start in stride(from: 0,to: length,by: 65_536) {
            let range=start..<min(length,start+65_536);try consume(range.count)
            let codes=try h.legacyCodes(source,member: column,range: range)
            tooLarge = tooLarge || codes.contains { $0>=Int64(count) };tooSmall = tooSmall || codes.contains { $0 < -1 }
        }
        // AnnData checks every original code before slicing or moving categories.
        if tooLarge { return false }
        guard !tooSmall else { throw VivoOmicsError.invalid("legacy categorical code below missing sentinel") }
        let ct=try h.type(cats,attribute: false);defer { h.close(ct,"H5Tclose") }
        guard try h.legacyTypeKind(ct)==3 else { throw VivoOmicsError.invalid("legacy category migration currently requires string labels") }
        let labels=try h.strings(cats,maximum: 100_000)
        guard labels.count==count,Set(labels).count==count else { throw VivoOmicsError.invalid("duplicate legacy category labels") }
        let group=try h.projectionGroup(destination,column);defer { h.close(group,"H5Gclose") }
        try h.encoding(group,"categorical","0.2.0");try h.writeBooleans(group,"ordered",shape: [],values: [false],attribute: true)
        try legacyMember(source,group,"codes",member: column,type: type,rows: rows,length: length,trailing: [],path: path+"/"+column+"/codes")
        try consume(count);try reserveStorage(count*typeWidth(ct),output: group)
        let output=try h.projectionDataset(group,"categories",type: ct,shape: [UInt64(count)]);defer { h.close(output,"H5Dclose") }
        try h.projectionAttributes(cats,output,excluding: ["encoding-type","encoding-version"]);try h.encoding(output,"string-array","0.2.0")
        for start in stride(from: 0,to: count,by: 65_536) {
            let end=min(count,start+65_536)
            try h.legacyTransfer(cats,output,memoryType: ct,outputType: ct,rows: (start..<end).map(UInt64.init),components: 1,
                outputStart: [UInt64(start)],outputCount: [UInt64(end-start)],scalarSource: shape.isEmpty,
                reserveVariableBytes: { try self.reserveStorage($0,output: output) })
        }
        movedLegacyCategories.insert(key);return true
    }
    func legacyFrame(_ source: Int64,_ destination: Int64,_ name: String,selection: [Int]?,length: Int,path: String) throws {
        guard try frameLength(source)==length else { throw VivoOmicsError.invalid("legacy dataframe alignment") }
        let names=try h.legacyMembers(source),rows=try indices(selection,length: length)
        guard Set(names).count==names.count else { throw VivoOmicsError.invalid("duplicate legacy dataframe fields") }
        let group=try h.projectionGroup(destination,name);defer { h.close(group,"H5Gclose") }
        try h.projectionAttributes(source,group,excluding: ["encoding-type","encoding-version","_index","column-order"])
        try h.encoding(group,"dataframe","0.2.0");try h.writeStrings(group,"_index",[names[0]],attribute: true,scalar: true)
        try h.writeStrings(group,"column-order",Array(names.dropFirst()),attribute: true)
        for (i,column) in names.enumerated() {
            let type=try h.legacyMemberType(source,i);defer { h.close(type,"H5Tclose") }
            guard try h.legacyArrayShape(type).isEmpty else { throw VivoOmicsError.invalid("legacy dataframe field must be scalar") }
            if i==0 { guard try h.legacyTypeKind(type)==3 else { throw VivoOmicsError.invalid("legacy dataframe index must be string") } }
            if i>0,try legacyCategory(source,group,column: column,type: type,rows: rows,length: length,path: path) { continue }
            try legacyMember(source,group,column,member: column,type: type,rows: rows,length: length,trailing: [],path: path+"/"+column)
        }
    }
    func legacyMapping(_ source: Int64,_ destination: Int64,_ name: String,selections: [[Int]?],expected: [Int?],path: String) throws {
        guard ["obsm","varm","raw/varm"].contains(path),selections.count==1,expected.count==1,let length=expected[0],try h.projectionShape(source)==[UInt64(length)] else { throw VivoOmicsError.invalid("legacy compound mapping alignment") }
        let rows=try indices(selections[0],length: length),names=try h.legacyMembers(source)
        let output=try h.projectionGroup(destination,name);defer { h.close(output,"H5Gclose") }
        try h.projectionAttributes(source,output,excluding: ["encoding-type","encoding-version"]);try h.encoding(output,"dict","0.1.0")
        for (i,member) in names.enumerated() {
            let type=try h.legacyMemberType(source,i);defer { h.close(type,"H5Tclose") }
            let trailing=try h.legacyArrayShape(type)
            guard !trailing.isEmpty else { throw VivoOmicsError.invalid("legacy embedding member must be a fixed array") }
            try legacyMember(source,output,member,member: member,type: type,rows: rows,length: length,trailing: trailing,path: path+"/"+member)
        }
    }
}
