from pathlib import Path
p=Path('/Users/home/numivivo-single-cell-20260909/Sources/NumiVivoKit/Omics/VivoH5ADProjection.swift');s=p.read_text()
s=s.replace('    let h: VivoHDF5\n    var remaining:', '    let h: VivoHDF5\n    let legacy: Bool\n    let root: Int64\n    var movedLegacyCategories=Set<String>()\n    var remaining:')
s=s.replace('init(_ h: VivoHDF5,limit: Int) { self.h=h;remaining=limit }','init(_ h: VivoHDF5,limit: Int,root: Int64,legacy: Bool) { self.h=h;remaining=limit;self.root=root;self.legacy=legacy }')
s=s.replace('    func encoding(_ object: Int64,_ kind: String,_ version: String) throws {\n', '''    func encoding(_ object: Int64,_ kind: String,_ version: String) throws {
        if legacy,try !h.legacyHasAttribute(object,"encoding-type"),try !h.legacyHasAttribute(object,"encoding-version") {
            if kind=="anndata" || kind=="dict" || kind=="raw" {
                guard try [1,2].contains(h.legacyObjectKind(object)) else { throw VivoOmicsError.invalid("legacy group encoding") };return
            }
            if kind=="csr_matrix" || kind=="csc_matrix" {
                guard try h.text(object,"h5sparse_format")==String(kind.prefix(3)) else { throw VivoOmicsError.invalid("legacy sparse format") };return
            }
            if kind=="array" || kind=="string-array" { return }
        }
''')
s=s.replace('    func frameLength(_ frame: Int64) throws -> Int {\n', '''    func frameLength(_ frame: Int64) throws -> Int {
        if legacy,try h.legacyCompound(frame) {
            let dims=try h.projectionShape(frame);guard dims.count==1,dims[0]<=2_000_000 else { throw VivoOmicsError.limit("legacy dataframe axis") };return Int(dims[0])
        }
''')
s=s.replace('    func frame(_ source: Int64,_ destination: Int64,_ name: String,selection: [Int]?,length: Int,path: String) throws {\n', '''    func frame(_ source: Int64,_ destination: Int64,_ name: String,selection: [Int]?,length: Int,path: String) throws {
        if legacy,try h.legacyCompound(source) { try legacyFrame(source,destination,name,selection: selection,length: length,path: path);return }
''')
s=s.replace('let attr=try h.attribute(source,"shape");defer', 'let legacySparse=legacy && (try !h.legacyHasAttribute(source,"encoding-type"))\n        let attr=try h.attribute(source,legacySparse ? "h5sparse_shape" : "shape");defer')
s=s.replace('try h.projectionAttributes(source,group,excluding: ["shape"])','try h.projectionAttributes(source,group,excluding: legacySparse ? ["h5sparse_shape","h5sparse_format"] : ["shape"])\n        if legacySparse { try h.encoding(group,kind,"0.1.0") }')
s=s.replace('        let kind=try h.text(object,"encoding-type")\n        switch kind {','        let kind=try elementKind(object)\n        switch kind {')
s=s.replace('        try h.projectionAttributes(source,output)\n        fields.append(.init(path: path,encoding: kind', '        try h.projectionAttributes(source,output)\n        if legacy,try !h.legacyHasAttribute(source,"encoding-type") { try h.encoding(output,kind,"0.2.0") }\n        fields.append(.init(path: path,encoding: kind')
s=s.replace('func mapping(_ source: Int64,_ destination: Int64,_ name: String,selections: [[Int]?],expected: [Int?],path: String) throws {', 'func mapping(_ source: Int64,_ destination: Int64,_ name: String,selections: [[Int]?],expected: [Int?],path: String,outputName: String? = nil) throws {')
s=s.replace('let input=try h.object(source,name);defer { h.close(input,"H5Oclose") };try encoding(input,"dict","0.1.0")\n        let output=try h.projectionGroup(destination,name);', 'let input=try h.object(source,name);defer { h.close(input,"H5Oclose") }\n        if legacy,try h.legacyCompound(input) { try legacyMapping(input,destination,outputName ?? name,selections: selections,expected: expected,path: path);return }\n        try encoding(input,"dict","0.1.0")\n        let output=try h.projectionGroup(destination,outputName ?? name);')
s=s.replace('try h.projectionAttributes(input,output)\n        for key', 'try h.projectionAttributes(input,output)\n        if legacy,try !h.legacyHasAttribute(input,"encoding-type") { try h.encoding(output,"dict","0.1.0") }\n        for key')
s=s.replace('let engine=VivoH5ADProjector(h,limit: plan.maximumElementVisits)','let legacy=try !h.legacyHasAttribute(input,"encoding-type") && !h.legacyHasAttribute(input,"encoding-version")\n            let engine=VivoH5ADProjector(h,limit: plan.maximumElementVisits,root: input,legacy: legacy)')
s=s.replace('guard children.isSubset(of: ["X","obs","var","layers","obsm","varm","obsp","varp","raw","uns"])','guard children.isSubset(of: Set(["X","obs","var","layers","obsm","varm","obsp","varp","raw","uns"]+(legacy ? ["raw.X","raw.var","raw.varm"] : [])))')
s=s.replace('try h.projectionAttributes(input,out)\n            try engine.frame','try h.projectionAttributes(input,out)\n            if legacy { try h.encoding(out,"anndata","0.1.0") }\n            try engine.frame')
a=s.index('            if children.contains("raw") {');b=s.index('            let repeated=',a)
s=s[:a]+'''            let dotted=children.contains("raw.X") || children.contains("raw.var") || children.contains("raw.varm")
            guard !(dotted && children.contains("raw")) else { throw VivoOmicsError.invalid("mixed legacy raw representations") }
            if children.contains("raw") || dotted {
                let raw=try h.object(input,dotted ? "." : "raw");defer { h.close(raw,"H5Oclose") }
                let varName=dotted ? "raw.var" : "var",xName=dotted ? "raw.X" : "X",varmName=dotted ? "raw.varm" : "varm"
                if !dotted {
                    try engine.encoding(raw,"raw","0.1.0")
                    guard Set(try h.projectionNames(raw)).isSubset(of: ["X","var","varm"]) else { throw VivoOmicsError.invalid("unknown raw fields") }
                }
                let rg=try h.projectionGroup(out,"raw");defer { h.close(rg,"H5Gclose") }
                if !dotted { try h.projectionAttributes(raw,rg) }
                if dotted || (legacy && (try !h.legacyHasAttribute(raw,"encoding-type"))) { try h.encoding(rg,"raw","0.1.0") }
                let rv=try h.object(raw,varName);defer { h.close(rv,"H5Oclose") };let rawP=try engine.frameLength(rv)
                try engine.frame(rv,rg,"var",selection: nil,length: rawP,path: "raw/var")
                if try h.exists(raw,xName) { try engine.element(raw,xName,rg,selections: [oi,nil],expected: [n,rawP],path: "raw/X",frameAllowed: false,outputName: "X") }
                try engine.mapping(raw,rg,varmName,selections: [nil],expected: [rawP],path: "raw/varm",outputName: "varm")
            }
            if children.contains("uns") {
                try h.projectionCopy(input,"uns",out,"uns")
                let uns=try h.object(out,"uns");defer { h.close(uns,"H5Oclose") }
                let remove: @convention(c) (Int64,UnsafePointer<CChar>,Int64) -> Int32 = try h.symbol("H5Ldelete")
                for name in engine.movedLegacyCategories.sorted() { try h.check(remove(uns,name,0),"relocate legacy categories") }
            }
'''+s[b:]
s=s.replace('frameAllowed: Bool = true) throws {','frameAllowed: Bool = true,outputName: String? = nil) throws {')
# In element dispatch, output name can differ for dotted raw.X.
a=s.index('    func element(');b=s.index('    func mapping(',a);part=s[a:b].replace('destination,name,','destination,outputName ?? name,').replace('h.projectionGroup(destination,name)','h.projectionGroup(destination,outputName ?? name)');s=s[:a]+part+s[b:]
s=s.replace('method: repeated ? "native-H5AD-repeated-axis-projection-v1" : "native-H5AD-axis-projection-v1"','method: legacy ? "native-H5AD-legacy-axis-projection-v1" : repeated ? "native-H5AD-repeated-axis-projection-v1" : "native-H5AD-axis-projection-v1"')
s=s.replace('qualification: (repeated ?','qualification: (legacy ? "Legacy compound annotations and embeddings split without numeric conversion; category definitions relocated from uns; original source retained. Cell/feature selection and reordering;" : repeated ?')
p.write_text(s)
