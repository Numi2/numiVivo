from pathlib import Path
import subprocess,json,hashlib
r=Path(__file__).parent;out=r/'regression';out.mkdir(exist_ok=False);old=Path('/Users/home/numivivo-numeric-categories-20260912/string-regression');rows=[]
for name in ['csc-repeated','csr-full','dense-empty','scalar']:
 src=old/name;dest=out/name
 result=subprocess.run([str(r/'build/h5ad-check'),'project',str(src/'original.h5ad'),str(src/'plan.json'),str(dest)],capture_output=True,text=True);(out/(name+'.log')).write_text(result.stdout+result.stderr);assert result.returncode==0
 hashes={}
 for f in ['original.h5ad','plan.json','projected.h5ad','report.json']:
  a=(src/f).read_bytes();b=(dest/f).read_bytes();assert a==b,(name,f);hashes[f]=hashlib.sha256(b).hexdigest()
 result=subprocess.run([str(r/'build/h5ad-check'),'verify-project',str(dest)],capture_output=True,text=True);assert result.returncode==0;rows.append({'case':name,'status':'passed','unchangedSHA256':hashes,'replay':True})
(out/'summary.json').write_text(json.dumps({'status':'passed','cases':rows},indent=2)+'\n');print('Passed four unchanged-byte regressions')
