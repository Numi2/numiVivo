from pathlib import Path
import shutil,json,hashlib,subprocess,warnings
import h5py,numpy as np,anndata as ad
r=Path(__file__).parent;seed=Path('/Users/home/numivivo-scalar-embedding-20260912/scalar.h5ad');results=[]
for mode in ['legacy','modern']:
 p=r/(mode+'.h5ad')
 if mode=='legacy':shutil.copy2(seed,p)
 else:
  with warnings.catch_warnings():warnings.simplefilter('ignore');ad.read_h5ad(seed).write_h5ad(p)
 with h5py.File(p,'r+') as f:
  for key in (['obs','var','raw.var'] if mode=='legacy' else ['obs','var','raw/var']):
   if mode=='legacy':
    a=f[key][()];names=a.dtype.names;b=np.empty(len(a),dtype=[(names[0],'<i8')]+[(n,a.dtype.fields[n][0]) for n in names[1:]]);b[names[0]]=np.arange(len(a))-10
    for n in names[1:]:b[n]=a[n]
    del f[key];f[key]=b
   else:
    frame=f[key];index=frame.attrs['_index'];n=len(frame[index]['values']) if isinstance(frame[index],h5py.Group) else len(frame[index]);del frame[index];d=frame.create_dataset(index,data=np.arange(n,dtype='i8')-10);d.attrs['encoding-type']='array';d.attrs['encoding-version']='0.2.0'
 with warnings.catch_warnings():warnings.simplefilter('ignore');a=ad.read_h5ad(p)
 plan=r/(mode+'-plan.json');plan.write_text(json.dumps({'schemaVersion':1,'source':{'bytes':list(hashlib.sha256(p.read_bytes()).digest())},'provenance':'Numeric index interoperability reproduction'}))
 run=subprocess.run(['/Users/home/numivivo-scalar-embedding-20260912/build/h5ad-check','project',str(p),str(plan),str(r/(mode+'-before'))],capture_output=True,text=True);results.append({'mode':mode,'referenceObsNames':list(a.obs_names),'nativeExit':run.returncode,'nativeDiagnostic':run.stdout+run.stderr})
(r/'reproduction.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
