from pathlib import Path
import hashlib,json,subprocess,shutil,warnings
import h5py,numpy as np,anndata as ad
root=Path(__file__).parent
source=Path('/Users/home/numivivo-legacy-count-route-20260911/legacy-checks-v2/numeric-categories.h5ad')
binary=Path('/Users/home/numivivo-legacy-count-route-20260911/h5ad-check')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cases=[]
for name,labels in [('integer',[1,2,3]),('large-unsigned',np.array([2**63+1,2**63+2,2**63+3],dtype='u8')),('float',[1.25,-0.0,3.5]),('duplicate',[1,1,3]),('nan',[1.,float('nan'),3.])]:
 path=root/(name+'.h5ad');shutil.copy2(source,path)
 with h5py.File(path,'r+') as f:
  del f['uns/donor_categories'];f['uns/donor_categories']=labels
 record={'case':name,'sourceSHA256':sha(path)}
 try:
  with warnings.catch_warnings():
   warnings.simplefilter('ignore');obj=ad.read_h5ad(path)
  record.update(reference='accepted',dtype=str(obj.obs['donor'].cat.categories.dtype),categories=[str(x) for x in obj.obs['donor'].cat.categories],codes=obj.obs['donor'].cat.codes.tolist())
 except Exception as e:record.update(reference='rejected',error=str(e))
 plan=root/(name+'-plan.json');plan.write_text(json.dumps({'schemaVersion':1,'source':{'bytes':list(bytes.fromhex(sha(path)))},'provenance':'Numeric category interoperability reproduction; no biological evidence'}))
 run=subprocess.run([str(binary),'project',str(path),str(plan),str(root/(name+'-native'))],capture_output=True,text=True)
 (root/(name+'-native.log')).write_text(run.stdout+run.stderr);record.update(nativeExit=run.returncode,nativeDiagnostic=(run.stdout+run.stderr).strip());cases.append(record)
report={'anndataVersion':ad.__version__,'binarySHA256':sha(binary),'checkerSHA256':sha(Path(__file__)),'cases':cases};(root/'reproduction.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
