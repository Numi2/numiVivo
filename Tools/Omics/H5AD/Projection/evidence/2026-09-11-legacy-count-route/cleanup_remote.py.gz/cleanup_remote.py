from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
root=Path('/Users/n/numivivo-legacy-count-route-20260911');raw=(root/'cleanup-plan.json').read_bytes();plan=json.loads(raw)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
paths=[Path(x['path']) for x in plan['files']];assert len(paths)==len(set(paths))==4
before=shutil.disk_usage(root).free
for p,record in zip(paths,plan['files']):
 rel=p.relative_to(root);assert str(rel) in ['annotated.h5ad','count-store/original.h5ad','count-store/counts.bin','aggregate/original.h5ad']
 assert p.resolve()==p and not p.is_symlink() and p.is_file()
 assert p.stat().st_size==record['bytes'] and sha(p)==record['SHA256']
 if rel.parts[0]=='count-store':assert {q.name for q in p.parent.iterdir()}=={'original.h5ad','counts.bin','plan.json','receipt.json','quality.json','metadata.json'}
 if rel.parts[0]=='aggregate':assert {q.name for q in p.parent.iterdir()}=={'original.h5ad','plan.json','receipt.json','report.json'}
handles=subprocess.run(['/usr/sbin/lsof','-nP','--',*[str(p) for p in paths]],capture_output=True,text=True)
assert handles.returncode==1 and not handles.stdout and not handles.stderr,(handles.returncode,handles.stdout,handles.stderr)
assert (root/'cleanup-plan.json').read_bytes()==raw
for p,record in zip(paths,plan['files']):
 assert p.stat().st_size==record['bytes'] and sha(p)==record['SHA256'];p.unlink()
assert not any(p.exists() for p in paths)
after=shutil.disk_usage(root).free
receipt=dict(status='completed',planSHA256=hashlib.sha256(raw).hexdigest(),filesRemoved=len(paths),payloadBytes=plan['totalBytes'],availableBefore=before,availableAfter=after,measuredRecoveredBytes=after-before,openHandleCheck='lsof returned 1 with empty stdout and stderr before deletion',remainingTargets=0,retainedCopies='Every exact payload is hash-bound to its verified laptop copy in cleanup-plan.json',timestamp=time.time())
(root/'cleanup-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
