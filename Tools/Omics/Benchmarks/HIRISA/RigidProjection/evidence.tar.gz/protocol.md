# Full-HIRISA rigid projection development test

Freeze before candidate fitting/scoring on 2026-09-12. Extend the previously
specified donor-wise centered orthogonal Procrustes method to every original
1,612,594 HIRISA cell and all 20 PCs. Use the original seed-7 native integration
as target. Fit one orthogonal matrix (reflections allowed) and translation for
each donor, without scaling. No author labels, RNA programs or scoring outcomes
enter fitting. No parameter or seed sweep and no threshold changes.

Minimize sum_b ||(X_b-mean(X_b)) Q_b - (Y_b-mean(Y_b))||_F^2,
Q_b.T Q_b = I; restore mean(Y_b). Compute cross-products in bounded row blocks.
Compare NumPy SVD solution against SciPy polar decomposition and verify all
output rows, objective and within-donor centered norms. Bind input hashes before
fitting and output hash before scoring. Donor metadata are the prior frozen row
ledger; they carry original cell-order identities.

Apply all original 114 donor-held-out annotation folds and all 471 comparisons,
retaining the same support/sensitivity and recall margins. Apply unchanged
response, mixed-program and within-library program checks; independently check
all annotation and within-library program fits. Report donor scatter alongside
preservation so weaker correction is not mistaken for useful integration.

This is a Python development experiment on previously inspected data, not a
native algorithm, prospective mapping or fresh independent biological test.
Within-donor distance preservation alone is not cross-donor preservation.
No production promotion follows automatically, even if a diagnostic passes.
