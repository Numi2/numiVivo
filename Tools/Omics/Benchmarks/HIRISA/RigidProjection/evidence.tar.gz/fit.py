from pathlib import Path
import sys,json,time,hashlib
import numpy as np
from scipy.linalg import polar
s=Path(sys.argv[1]);r=Path(sys.argv[2]);sys.path.insert(0,str(s/'protected-regression'))
from fit_protected_regression import records,append
from check_integration_response import sha
from prepare_annotation_retention import read,write
old=s/'annotation-retention';f=read(old/'freeze.json');ledger=read(old/'ledger.json');n=f['cells'];d=f['components']
assert n==1612594 and d==20
for name,h in f['files'].items():assert sha(old/name)==h
paths={k:s/f['matrices'][k]['path'] for k in ['baseline','native']}
for k,p in paths.items():assert sha(p)==f['matrices'][k]['SHA256']
donors=np.load(old/'rows.npz')['donor'];B=len(ledger['donors']);assert len(donors)==n and B==5
write(r/'execution-freeze.json',dict(createdUnix=time.time(),protocolSHA256=sha(r/'protocol.md'),scriptSHA256=sha(Path(__file__)),annotationFreezeSHA256=sha(old/'freeze.json'),inputs={k:dict(path=str(v),SHA256=sha(v)) for k,v in paths.items()},metricsRead=False))
count=np.bincount(donors,minlength=B);sx=np.zeros((B,d));sy=sx.copy();cross=np.zeros((B,d,d))
for (a,b,x),(aa,bb,y) in zip(records(paths['baseline'],n,d),records(paths['native'],n,d)):
 assert (a,b)==(aa,bb)
 for k in np.unique(donors[a:b]):
  mask=donors[a:b]==k;xx=x[mask];yy=y[mask];sx[k]+=xx.sum(0);sy[k]+=yy.sum(0);cross[k]+=xx.T@yy
mx=sx/count[:,None];my=sy/count[:,None];Q=[];oracle=[];fits=[]
for k in range(B):
 C=cross[k]-np.outer(sx[k],sy[k])/count[k];u,v,vt=np.linalg.svd(C);q=u@vt;ref,_=polar(C);err=float(np.max(abs(q-ref)));orth=float(np.max(abs(q.T@q-np.eye(d))));assert err<1e-10 and orth<1e-10
 Q.append(q);oracle.append(ref);fits.append(dict(donor=ledger['donors'][k],cells=int(count[k]),rotation=q.tolist(),inputMean=mx[k].tolist(),targetMean=my[k].tolist(),singularValues=v.tolist(),polarError=err,orthogonalityError=orth))
maxerr=0.;normerr=0.;sse=np.zeros(B)
with (r/'rigid.bin').open('xb') as out:
 for (a,b,x),(aa,bb,y) in zip(records(paths['baseline'],n,d),records(paths['native'],n,d)):
  assert (a,b)==(aa,bb);z=np.empty_like(x)
  for k in np.unique(donors[a:b]):
   mask=donors[a:b]==k;xc=x[mask]-mx[k];zz=xc@Q[k];ref=np.einsum('ij,jk->ik',xc,oracle[k],optimize=False)
   maxerr=max(maxerr,float(np.max(abs(zz-ref))));normerr=max(normerr,float(np.max(abs(np.sum(zz*zz,axis=1)-np.sum(xc*xc,axis=1))/(1+np.sum(xc*xc,axis=1)))))
   z[mask]=zz+my[k];sse[k]+=np.sum((z[mask]-y[mask])**2)
  append(out,a,z)
assert maxerr<1e-8 and normerr<1e-10
write(r/'models.json',dict(fits=fits,maximumCoordinateOracleError=maxerr,maximumRelativeCenteredNormError=normerr,targetSSE=sse.tolist(),allCells=n))
write(r/'output-freeze.json',dict(status='passed',metricsRead=False,files={p.name:sha(p) for p in [r/'rigid.bin',r/'models.json']},inputFreezeSHA256=sha(r/'execution-freeze.json')))
print('PASS all full-cohort coordinates, polar oracle and isometry',flush=True)
