# Full-HIRISA translation-only ablation

Declared before this candidate is fitted or scored. HIRISA outcomes and the
previous native/rigid failures are inspected development data. This is not a new
independent validation cohort. Retain all 1,612,594 cells and all 20 original PCs.

For each of five donors, compute original PCA mean mx and frozen native corrected
mean my from the existing source-bound matrices. Set z = x + (my - mx). There is
no rotation, scaling, label input, feature selection or fitted hyperparameter.
This isolates the donor-mean shift from the rotations in the prior Procrustes
candidate; it does not establish a new batch-removal mechanism. Native target
means inherit the existing correction's assumptions and transductive data use.

Hash all inputs and this protocol before fitting; freeze output before scoring.
Independently apply centered x - mx + my to every output coordinate and check
numerical equality and within-donor centered norms. Run the unchanged complete
114-fold annotation evaluation and its SVD oracle, coarse responses, sensitive
mixed programs and within-library calibrated programs plus their existing oracle.
Retain all insufficient and insensitive comparisons. Compare original PCA and
the existing native/rigid results; no threshold or passing-subset changes.

No product promotion follows from this ablation or numerical agreement. A lower
failure count alone is insufficient. Any later method selection using these
results is development reuse and requires an untouched validation cohort.
