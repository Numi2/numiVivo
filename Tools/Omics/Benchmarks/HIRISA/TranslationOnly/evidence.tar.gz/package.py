from pathlib import Path
import json,hashlib,tarfile,platform,sys
import numpy,scipy,h5py
r=Path(sys.argv[1]);s=Path('/Users/n/numivivo-hirisa-20260910')
def read(p):return json.loads(p.read_text())
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1048576):h.update(b)
 return h.hexdigest()
assert read(r/'terminal.json')['returnCode']==0 and read(r/'complete.json')['allNumericalChecksPassed']
a=read(r/'evaluation/translation.json');old=read(s/'annotation-retention/native.json');eligible=[x for x in a['comparisons'] if x['sufficientSupport'] and x['controlSensitive']]
(r/'prior-native.json').write_text(json.dumps(old,sort_keys=True)+'\n')
oldmap={(x['stratum'],x['label']):x for x in old['comparisons']}
summary={'status':'completed-development-experiment-not-promoted','cells':a['cells'],'folds':a['foldCount'],'comparisons':len(a['comparisons']),'eligible':len(eligible),'failures':sum(x['marginFailure'] for x in eligible),'rareEligible':sum(x['rare'] for x in eligible),'rareFailures':sum(x['rare'] and x['marginFailure'] for x in eligible),'originalFailures':sum(x['marginFailure'] for x in old['comparisons']),'resolvedFailures':sum(oldmap[x['stratum'],x['label']]['marginFailure'] and not x['marginFailure'] for x in eligible),'newFailures':sum(not oldmap[x['stratum'],x['label']]['marginFailure'] and x['marginFailure'] for x in eligible),'meanEligibleRecall':sum(x['candidateMeanRecall'] for x in eligible)/len(eligible),'numerical':{k:v for k,v in read(r/'models.json').items() if k!='fits'},'versions':{'python':sys.version,'numpy':numpy.__version__,'scipy':scipy.__version__,'h5py':h5py.__version__,'platform':platform.platform()},'setupFailures':[]}
for name in ['response','mixed-programs','within-programs']:
 m=read(r/'evaluation'/(name+'.json'));c=m['comparisons'];e=[x for x in c if x.get('controlSensitive',True)];summary[name]={'comparisons':len(c),'sensitive':len(e),'passedAmongSensitive':sum(all(x['gates'].values()) for x in e),'completeGate':m.get('allResponseDiagnosticGatesPassed',m.get('allProgramGradientGatesPassed'))}
 if name=='response':summary[name].update(meanConditionalDonorScatter=sum(x['fraction'] for x in m['conditionalDonorScatter'])/len(m['conditionalDonorScatter']),meanRelativeResponseDrift=sum(x['meanRelativeResponseDrift'] for x in c)/len(c))
(r/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files=[p for p in r.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name not in ['translation.bin','evidence.tar.gz','manifest.json']]
with tarfile.open(r/'evidence.tar.gz','w:gz') as t:
 for p in sorted(files):t.add(p,arcname=str(p.relative_to(r)),recursive=False)
m={'archiveSHA256':sha(r/'evidence.tar.gz'),'members':{str(p.relative_to(r)):sha(p) for p in sorted(files)},'externalCoordinate':{'path':str(r/'translation.bin'),'bytes':(r/'translation.bin').stat().st_size,'SHA256':sha(r/'translation.bin')},'scope':'All declared full-cohort results, protocols, models and source scripts; full coordinates external. Failed preservation; no promotion.'}
(r/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps(summary));print('archive bytes',(r/'evidence.tar.gz').stat().st_size)
