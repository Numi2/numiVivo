from pathlib import Path
import sys,time
import numpy as np
s=Path(sys.argv[1]);r=Path(sys.argv[2]);sys.path.insert(0,str(s/'protected-regression'))
from fit_protected_regression import records,append
from check_integration_response import sha
from prepare_annotation_retention import read,write
old=s/'annotation-retention';f=read(old/'freeze.json');ledger=read(old/'ledger.json');n=f['cells'];d=f['components']
assert (n,d)==(1612594,20)
for name,h in f['files'].items():assert sha(old/name)==h
paths={k:s/f['matrices'][k]['path'] for k in ['baseline','native']}
for k,p in paths.items():assert sha(p)==f['matrices'][k]['SHA256']
donors=np.load(old/'rows.npz')['donor'];B=len(ledger['donors']);assert len(donors)==n and B==5
write(r/'execution-freeze.json',dict(createdUnix=time.time(),protocolSHA256=sha(r/'protocol.md'),scriptSHA256=sha(Path(__file__)),annotationFreezeSHA256=sha(old/'freeze.json'),inputs={k:dict(path=str(v),SHA256=sha(v)) for k,v in paths.items()},metricsRead=False))
count=np.bincount(donors,minlength=B);sx=np.zeros((B,d));sy=sx.copy()
for (a,b,x),(aa,bb,y) in zip(records(paths['baseline'],n,d),records(paths['native'],n,d)):
 assert (a,b)==(aa,bb)
 for k in np.unique(donors[a:b]):
  mask=donors[a:b]==k;sx[k]+=x[mask].sum(0);sy[k]+=y[mask].sum(0)
mx=sx/count[:,None];my=sy/count[:,None];shift=my-mx
maxerr=0.;normerr=0.;seen=0
with (r/'translation.bin').open('xb') as out:
 for a,b,x in records(paths['baseline'],n,d):
  z=x+shift[donors[a:b]];ref=(x-mx[donors[a:b]])+my[donors[a:b]]
  maxerr=max(maxerr,float(np.max(abs(z-ref))))
  before=x-mx[donors[a:b]];after=z-my[donors[a:b]]
  normerr=max(normerr,float(np.max(abs(np.sum(before**2,axis=1)-np.sum(after**2,axis=1))/(1+np.sum(before**2,axis=1)))))
  append(out,a,z);seen+=b-a
assert seen==n and maxerr<1e-10 and normerr<1e-10
write(r/'models.json',dict(donors=ledger['donors'],counts=count.tolist(),inputMeans=mx.tolist(),targetMeans=my.tolist(),translations=shift.tolist(),maximumCoordinateOracleError=maxerr,maximumRelativeCenteredNormError=normerr,allCells=n))
write(r/'output-freeze.json',dict(status='passed',metricsRead=False,files={p.name:sha(p) for p in [r/'translation.bin',r/'models.json']},inputFreezeSHA256=sha(r/'execution-freeze.json')))
print('PASS all translation coordinates and algebraic isometry checks',flush=True)
