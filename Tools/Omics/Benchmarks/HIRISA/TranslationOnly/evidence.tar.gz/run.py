from pathlib import Path
import subprocess,os,json,time
r=Path(__file__).parent;py="/Users/n/numivivo-integration-reference-py/bin/python";s="/Users/n/numivivo-hirisa-20260910"
commands=[[py,str(r/"fit.py"),s,str(r)],[py,str(r/"evaluate.py"),"--study",s,"--root",str(r),"--python",py]]
for cmd in commands:
 code=subprocess.call(cmd)
 if code:break
(r/"terminal.json").write_text(json.dumps(dict(returnCode=code,finishedUnix=time.time())))
raise SystemExit(code)
