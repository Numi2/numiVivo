# Matched-control donor shift, full HIRISA

Frozen before fitting this candidate. Existing HIRISA outcomes have been inspected;
this is development reuse, not prospective validation. Retain every original cell,
PC and all existing annotation, response and program acceptance rules.

Use only original PCA values for controls: treatment none in Bcell, Monocyte, NK
and Tcell preparations, and culture_no_stim in PBMC. Fresh PBMC is excluded from
shift estimation because it is not the cultured intervention control. All five
donors must have at least one cell in each of these five declared control strata.
Compute each donor/stratum mean, then the equally weighted donor grand mean in
each stratum. A donor's additive shift is the equal-stratum mean of grand mean
minus its mean. Apply that one shift to every cell from that donor. No treated
values, author cell labels, native corrected coordinates, scaling, rotations,
hyperparameter selection or outcome-dependent exclusions enter shift estimation.

Existing PCA was fitted on the full cohort; only shift estimation is control-only.
Observed query-donor controls enter fitting, so this is transductive integration,
not an unseen-donor prediction. Equal donor and stratum weighting prevents raw
cell yields from determining the overall nuisance estimate, but can still remove
true donor biology and does not correct cell-composition differences within a
control stratum. Evaluate those risks rather than assuming biological preservation.

Hash inputs/protocol before fitting, freeze coordinates before scoring, run all
114 annotation folds and SVD oracle, all 16 response contrasts, 32 mixed programs
and 32 within-library programs with original sensitivity flags and oracle. Compare
against original PCA; retain existing native/rigid/translation evidence. No product
promotion from fewer failures or a selected subset. Fresh independent validation
is required before claiming biological generalization.
