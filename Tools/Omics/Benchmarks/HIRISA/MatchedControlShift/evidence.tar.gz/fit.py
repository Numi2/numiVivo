from pathlib import Path
import sys,time
import numpy as np
s=Path(sys.argv[1]);r=Path(sys.argv[2]);sys.path.insert(0,str(s/'protected-regression'))
from fit_protected_regression import records,append
from check_integration_response import sha
from prepare_annotation_retention import read,write
old=s/'annotation-retention';f=read(old/'freeze.json');ledger=read(old/'ledger.json');n=f['cells'];d=f['components']
assert (n,d)==(1612594,20)
for name,h in f['files'].items():assert sha(old/name)==h
paths={k:s/f['matrices'][k]['path'] for k in ['baseline']}
for k,p in paths.items():assert sha(p)==f['matrices'][k]['SHA256']
donors=np.load(old/'rows.npz')['donor'];B=len(ledger['donors']);assert len(donors)==n and B==5
write(r/'execution-freeze.json',dict(createdUnix=time.time(),protocolSHA256=sha(r/'protocol.md'),scriptSHA256=sha(Path(__file__)),annotationFreezeSHA256=sha(old/'freeze.json'),inputs={k:dict(path=str(v),SHA256=sha(v)) for k,v in paths.items()},metricsRead=False))
rows=np.load(old/'rows.npz');strata=rows['stratum']
control_names=[('Bcell','none'),('Monocyte','none'),('NK','none'),('PBMC','culture_no_stim'),('Tcell','none')]
control_ids=[next(i for i,v in enumerate(ledger['strata']) if (v['preparation'],v['treatment'])==pair) for pair in control_names]
sums=np.zeros((5,B,d));count=np.zeros((5,B),dtype=np.int64)
for a,b,x in records(paths['baseline'],n,d):
 for j,si in enumerate(control_ids):
  for k in range(B):
   mask=(strata[a:b]==si)&(donors[a:b]==k)
   sums[j,k]+=x[mask].sum(0);count[j,k]+=np.count_nonzero(mask)
assert np.all(count>0)
control_means=sums/count[:,:,None];grand=control_means.mean(axis=1)
shift=(grand[:,None,:]-control_means).mean(axis=0)
# Independent scalar accumulation of the 25 small means/offsets.
import math
oracle=np.array([[math.fsum(math.fsum(float(control_means[j,q,h]) for q in range(B))/B-float(control_means[j,k,h]) for j in range(5))/5 for h in range(d)] for k in range(B)])
assert np.max(abs(shift-oracle))<1e-12
mx=np.zeros((B,d));my=oracle
maxerr=0.;normerr=0.;seen=0
with (r/'translation.bin').open('xb') as out:
 for a,b,x in records(paths['baseline'],n,d):
  z=x+shift[donors[a:b]];ref=x+oracle[donors[a:b]]
  maxerr=max(maxerr,float(np.max(abs(z-ref))))
  before=x-mx[donors[a:b]];after=z-my[donors[a:b]]
  normerr=max(normerr,float(np.max(abs(np.sum(before**2,axis=1)-np.sum(after**2,axis=1))/(1+np.sum(before**2,axis=1)))))
  append(out,a,z);seen+=b-a
assert seen==n and maxerr<1e-10 and normerr<1e-10
write(r/'models.json',dict(donors=ledger['donors'],counts=count.tolist(),controlStrata=control_names,controlMeans=control_means.tolist(),targetControlMeans=grand.tolist(),translations=shift.tolist(),maximumCoordinateOracleError=maxerr,maximumRelativeCenteredNormError=normerr,allCells=n))
write(r/'output-freeze.json',dict(status='passed',metricsRead=False,files={p.name:sha(p) for p in [r/'translation.bin',r/'models.json']},inputFreezeSHA256=sha(r/'execution-freeze.json')))
print('PASS all translation coordinates and algebraic isometry checks',flush=True)
