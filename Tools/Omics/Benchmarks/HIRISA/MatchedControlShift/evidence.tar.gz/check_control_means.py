"""Recompute control sufficient statistics with indexed accumulation."""
from pathlib import Path
import sys,json,hashlib
import numpy as np
r=Path(__file__).parent;s=Path('/Users/n/numivivo-hirisa-20260910')
sys.path.insert(0,str(s/'protected-regression'))
from fit_protected_regression import records
from check_integration_response import sha
m=json.loads((r/'models.json').read_text());f=json.loads((r/'execution-freeze.json').read_text())
p=Path(f['inputs']['baseline']['path']);assert sha(p)==f['inputs']['baseline']['SHA256']
old=s/'annotation-retention';ledger=json.loads((old/'ledger.json').read_text());rows=np.load(old/'rows.npz')
original=json.loads((old/'freeze.json').read_text())
for name in ['rows.npz','ledger.json']:assert sha(old/name)==original['files'][name]
assert sha(old/'freeze.json')==f['annotationFreezeSHA256']
ids=[next(i for i,x in enumerate(ledger['strata']) if [x['preparation'],x['treatment']]==pair) for pair in m['controlStrata']]
lookup=np.full(len(ledger['strata']),-1,dtype=np.int64);lookup[ids]=np.arange(5)
group=lookup[rows['stratum']]*5+rows['donor'];valid=lookup[rows['stratum']]>=0
counts=np.bincount(group[valid],minlength=25).reshape(5,5);sums=np.zeros((25,20))
for a,b,x in records(p,1612594,20):
 good=valid[a:b];g=group[a:b][good]
 for col in range(20):sums[:,col]+=np.bincount(g,weights=x[good,col],minlength=25)
means=sums.reshape(5,5,20)/counts[:,:,None]
assert np.array_equal(counts,np.array(m['counts']))
err=float(np.max(abs(means-np.array(m['controlMeans']))));assert err<1e-10
shift=means.mean(1)[:,None,:]-means;shift=shift.mean(0)
shift_err=float(np.max(abs(shift-np.array(m['translations']))));assert shift_err<1e-10
out=dict(status='passed',scope='Independent indexed control-count and mean accumulation; not scientific validation',maximumControlMeanError=err,maximumShiftError=shift_err,controlCells=int(counts.sum()),counts=counts.tolist(),scriptSHA256=sha(Path(__file__)),modelsSHA256=sha(r/'models.json'))
with (r/'control-means-oracle.json').open('x') as stream:json.dump(out,stream,indent=2)
print(out)
