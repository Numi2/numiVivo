import hashlib,json,os,subprocess,sys,time
from pathlib import Path
import numpy as np
p=Path(__file__).resolve().parent;q=p/'qualification';source=Path(json.loads((q/'source.json').read_text())['root'])
command=[sys.executable,str(p/'run_harmony_integration.py'),'--scores',str(source/'scores.bin'),'--metadata',str(source/'metadata.json'),'--protocol',str(q/'protocol.json'),'--seed','7','--out',str(q/'kang')]
began=time.time()
with (q/'run.log').open('x') as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'OPENBLAS_NUM_THREADS':'1','VECLIB_MAXIMUM_THREADS':'1','OMP_NUM_THREADS':'1'})
(q/'run-status.json').write_text(json.dumps(dict(returnCode=r.returncode,seconds=time.time()-began,command=command),indent=2)+'\n');assert r.returncode==0
sys.path.insert(0,str(p));from check_integration_response import blocks,sha
reference=Path('/Users/home/numivivo-file-integration-20260909/reference-kang/harmony-7.npz');assert reference.is_file()
y=np.load(reference)['scores'];assert y.shape==(24673,20);error=0.
for start,end,x in blocks(q/'kang/scores.bin',24673,20,8192):
 error=max(error,float(np.max(np.abs(x-y[start:end]))));np.testing.assert_allclose(x,y[start:end],atol=1e-10,rtol=1e-10)
(q/'checks.json').write_text(json.dumps(dict(status='passed',cells=24673,allCorrectedCoordinatesCompared=True,maximumAbsoluteError=error,priorHarmonyOutputSHA256=sha(reference),outputSHA256=sha(q/'kang/scores.bin'),runnerSHA256=sha(p/'run_harmony_integration.py'),readerSHA256=sha(p/'check_integration_response.py'),protocolSHA256=sha(q/'protocol.json'),scope='Complete Kang seed7 reference coordinates versus previous full-cohort Harmony2 output; validates metadata coding, matrix orientation and exact binary transport, not full HIRISA biological qualification.'),indent=2)+'\n');print('Runner qualification passed',error,flush=True)
