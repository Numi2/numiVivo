"""Run three complete reference fits and the same frozen response diagnostics."""
import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
study=Path('/Users/n/numivivo-hirisa-20260910');root=study/'integration-harmony';full=study/'integration-full';response=study/'integration-response-v2';python='/Users/n/numivivo-integration-reference-py/bin/python'
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def write(name,v):
 with (root/name).open('x') as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n')
freeze=json.loads((root/'execution-freeze.json').read_text());protocol=json.loads((root/'protocol.json').read_text())
for name,identity in freeze['files'].items():assert sha(root/name)==identity,name
qualification=json.loads((root/'qualification/checks.json').read_text());assert qualification['status']=='passed' and qualification['maximumAbsoluteError']==0
assert qualification['runnerSHA256']==sha(root/'run_harmony_integration.py') and qualification['readerSHA256']==sha(root/'check_integration_response.py')
coordinator=json.loads((full/'resume-start.json').read_text())['coordinatorPID'];write('wait-start.json',dict(coordinatorPID=os.getpid(),existingNativeCoordinatorPID=coordinator,startedAtUnix=time.time(),executionFreezeSHA256=sha(root/'execution-freeze.json')))
print('Waiting for existing native replay and declared disk headroom',flush=True)
try:
 while not (full/'native-complete.json').exists():
  status=full/'full-verify-status.json'
  if status.exists():assert json.loads(status.read_text())['returnCode']==0,'Native replay failed'
  os.kill(coordinator,0);time.sleep(15)
 assert json.loads((full/'native-complete.json').read_text())['status']=='passed'
 began=time.time()
 while shutil.disk_usage(root).free<8*1024**3:
  with (root/'headroom.jsonl').open('a') as f:f.write(json.dumps(dict(observedUnix=time.time(),freeBytes=shutil.disk_usage(root).free,requiredBytes=8*1024**3))+'\n')
  assert time.time()-began<1200,'Reference headroom gate after 20 minutes';time.sleep(15)
 commands=[];env={**os.environ,'OPENBLAS_NUM_THREADS':'1','VECLIB_MAXIMUM_THREADS':'1','OMP_NUM_THREADS':'1'}
 for seed in protocol['seeds']:
  assert shutil.disk_usage(root).free>=4*1024**3,'Reference next-seed headroom'
  fit=[python,str(root/'run_harmony_integration.py'),'--scores',str(full/'native/input/scores.bin'),'--metadata',str(full/'native/metadata.json'),'--protocol',str(root/'protocol.json'),'--seed',str(seed),'--out',str(root/f'seed-{seed}')]
  evaluate=[python,str(response/'check_integration_response.py'),'--source',str(study/'native-release/original.h5ad'),'--metadata',str(full/'native/metadata.json'),'--design',str(study/'design.json'),'--protocol',str(response/'protocol.json'),'--scores',str(root/f'seed-{seed}/scores.bin'),'--baseline',str(response/'baseline.json'),'--out',str(root/f'seed-{seed}/response.json')]
  for label,command in [(f'seed-{seed}-fit',fit),(f'seed-{seed}-evaluate',evaluate)]:
   started=time.time()
   with (root/(label+'.log')).open('x') as f:
    process=subprocess.Popen(command,env=env,stdout=f,stderr=subprocess.STDOUT)
    write(label+'-start.json',dict(command=command,processPID=process.pid,startedAtUnix=started));print(label,'started',process.pid,flush=True);code=process.wait()
   status=dict(command=command,returnCode=code,seconds=time.time()-started);commands.append(status);write(label+'-status.json',status);assert code==0,label
  report=json.loads((root/f'seed-{seed}/report.json').read_text());scores=json.loads((root/f'seed-{seed}/response.json').read_text());assert report['output']==scores['bindings']['scores']
 for name,identity in freeze['files'].items():assert sha(root/name)==identity,name
 write('complete.json',dict(status='three-complete-reference-fits-and-response-evaluations',commands=commands,cells=1612594,seeds=protocol['seeds'],nativeReplay='passed',scope=protocol['scope']));print('All complete independent reference fits and response diagnostics measured',flush=True)
except Exception as error:
 write('coordinator-failure.json',dict(status='failed',error=repr(error),observedAtUnix=time.time()));raise
