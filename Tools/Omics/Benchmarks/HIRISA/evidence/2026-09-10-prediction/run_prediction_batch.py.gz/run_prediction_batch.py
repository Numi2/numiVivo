import hashlib,json,os,subprocess,time
from pathlib import Path

root=Path('/Users/n/numivivo-hirisa-20260910');repo=Path('/Users/n/numivivo-h5ad-20260909')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''): h.update(b)
 return h.hexdigest()
runtime=root/'prediction-runtime-release';binary=runtime/'numivivo';manifest=json.loads((runtime/'manifest.json').read_text())
transport=json.loads((root/'prediction-transport-receipt.json').read_text())
assert sha(binary)==manifest['binarySHA256']
assert sha(root/'prediction-batch-plan.json')==transport['planSHA256']
assert all(sha(repo/p)==h for p,h in transport['currentOwnerSourceSHA256'].items())
assert json.loads((root/'prediction-product-check-release.json').read_text())['status']=='passed'
environment={**manifest,'driverSHA256':sha(Path(__file__)),'transportReceiptSHA256':sha(root/'prediction-transport-receipt.json'),
 'productCheckSHA256':sha(root/'prediction-product-check-release.json'),'psBefore':subprocess.check_output(['ps','-axo','pid,etime,pcpu,rss,command'],text=True)}
(root/'prediction-execution-environment.json').write_text(json.dumps(environment,indent=2)+'\n')
env={**os.environ,'NUMIVIVO_HDF5_LIBRARY':'/Users/n/numivivo-multiassay-hdf5-20260909/libhdf5.dylib'}
for name,args in [('publish',['singlecell-perturbation-batch',str(root/'native-release'),'--plan',str(root/'prediction-batch-plan.json'),'--output',str(root/'prediction-batch')]),
                  ('verify',['singlecell-perturbation-batch-verify',str(root/'prediction-batch')])]:
 assert not (root/('prediction-batch-'+name+'-status.json')).exists()
 command=['/usr/bin/time','-l',str(binary),*args];start=time.time()
 with (root/('prediction-batch-'+name+'.log')).open('x') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=env)
 status=dict(returnCode=r.returncode,seconds=time.time()-start,command=command,binarySHA256=sha(binary))
 (root/('prediction-batch-'+name+'-status.json')).write_text(json.dumps(status,indent=2)+'\n')
 print(name,json.dumps(status),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 if name=='publish':
  bundle=root/'prediction-batch';receipt=json.loads((bundle/'receipt.json').read_text())
  paths=[bundle/'receipt.json',bundle/'plan.json',*sorted((bundle/'folds').rglob('*.json'))]
  frozen=dict(createdAtUnix=time.time(),targetsOpenedForScoring=False,files={str(p.relative_to(bundle)):sha(p) for p in paths},
     folds=len(receipt['folds']),completed=sum(f['status']=='completed' for f in receipt['folds']))
  (root/'prediction-native-output-freeze.json').write_text(json.dumps(frozen,indent=2)+'\n')
