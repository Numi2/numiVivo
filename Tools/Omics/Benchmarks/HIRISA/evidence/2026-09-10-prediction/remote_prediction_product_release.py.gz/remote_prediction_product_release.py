#!/usr/bin/env python3
import hashlib, shlex, subprocess, sys
from pathlib import Path

remote='/Users/n/numivivo-hirisa-20260910/batch-reader-mirror-release'
binary='/Users/n/numivivo-hirisa-20260910/prediction-runtime-release/numivivo'
args=sys.argv[1:]
assert args and args[0] in ['singlecell-perturbation-batch','singlecell-perturbation-batch-verify']
def mapped(p):
    return remote+'/'+hashlib.sha256(str(Path(p).resolve()).encode()).hexdigest()[:24]
def copy(p):
    source=Path(p); target=mapped(p)
    assert str(source.resolve()).startswith('/Users/home/numivivo-')
    subprocess.run(['rsync','-a','-e','ssh -4',str(source)+('/' if source.is_dir() else ''),'macmini:'+target+('/' if source.is_dir() else '')],check=True,stdout=subprocess.DEVNULL)
    return target
subprocess.run(['ssh','-4','macmini','mkdir','-p',remote],check=True,stdout=subprocess.DEVNULL)
if args[0].endswith('-verify'):
    assert len(args)==2
    command=[args[0],copy(args[1])]; destination=None
else:
    assert len(args)==6 and args[2]=='--plan' and args[4]=='--output'
    destination=Path(args[5]); output=mapped(destination)
    if destination.exists(): copy(destination)
    command=[args[0],copy(args[1]),'--plan',copy(args[3]),'--output',output]
command=['env','NUMIVIVO_HDF5_LIBRARY=/Users/n/numivivo-multiassay-hdf5-20260909/libhdf5.dylib',binary,*command]
r=subprocess.run(['ssh','-4','macmini',shlex.join(command)])
if r.returncode==0 and destination is not None:
    destination.mkdir(exist_ok=True)
    subprocess.run(['rsync','-a','-e','ssh -4','macmini:'+output+'/',str(destination)+'/'],check=True,stdout=subprocess.DEVNULL)
sys.exit(r.returncode)
