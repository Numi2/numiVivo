# Integration scale preflight after full HIRISA graph/clustering

The complete source-metadata audit in `admission.json` retains all 1,612,594
cells, their five donor levels, thirteen batch levels and condition connectivity.
Both donor and batch identities are known and the condition designs are connected.

Exact native MNN matching alone needs 20,684,720,015,420 scalar distance terms
for donor integration and 23,620,379,972,960 for batch integration. Both exceed
the supported ten-trillion ceiling before Gaussian anchor correction is counted.
With k=20, the base latent memory estimate is 3,225,188,000 bytes, before anchor
buffers, metadata and source-PCA verification. Raising a work bound alone does
not address quadratic matching or dense cell-by-anchor kernel assembly. Retain
the exact route as the small-cohort oracle while adding a scalable matching and
correction route with measured neighbor/anchor recall and coordinate/biology gates.

The existing file-backed ridge route with 100 clusters, 20 PCs and ten iterations
has a native admission-work estimate of 64,503,760,000 (within its supported
100-billion ceiling). Its complete membership record file is 2,580,150,400 bytes,
which exceeds the stale 1,600,000,000-byte snapshot and verification limit in
`VivoPCAIntegration.swift`. Derive witness bounds from supported rows and cluster/
neighbor counts rather than independently copied constants. Keep method defaults,
source cells and biological acceptance margins unchanged. Publication currently
can write such a membership file and subsequent verification rejects it, so repair
that inconsistency before a full run.

Next implementation order: finish the already-live graph and queued clustering
qualification/publication; repair integration artifact admission; qualify full
ridge execution as a named baseline with preserved negative biological results;
then scale MNN matching and correction against the exact method, preserving the
complete cohort and independent biological-preservation requirements. Do not
substitute an aggregate or reduced-cell cohort for the million-cell integration
claim. No integration run or biological preservation is established by this audit.


## Current progress after graph publication

Graph qualification is published as `362e7d1331db5c3e86385e34dc969dd24fb73169`.
Full graph clustering is actively running with its frozen graph executable; do
not restart it or replace its receipts with the integration executable.
Integration membership/anchor bounds now derive from the admitted two-million
cell and 100-cluster/neighbor axes. Thirteen native tests in four suites passed,
including a real sparse 1,600,000,016-byte snapshot, exact clone fingerprint and
oversize rejection. Complete release build and fresh fitted/query ridge/MNN
lifecycle checks are sequenced by `continue_admission.py` and `continue_fixtures.py`.
Their terminal status files, not the launch messages, decide acceptance.

Before full ridge execution, account for the owning matrix's random-access cost:
`VivoIntegrationMatrix.pointer` retains one 64 MiB mapping, while each of the
four block sweeps shuffles all rows. The full 100-cluster membership scratch is
1,651,296,256 bytes (24 full windows plus the tail). Random row traversal can
remap on almost every access. This is a source-derived performance concern, not
a measured regression or justification for changing the frozen numerical order.
Measure the actual mapping path before launching predictably expensive full
ridge sweeps. Preserve the original deterministic solver trajectory when changing
storage, and qualify any access/cache improvement against the frozen legacy
oracle and resident/windowed paths before full-cohort execution.
