import hashlib,json,subprocess,time
from pathlib import Path
root=Path('/Users/home/numivivo-hiris-20260910/integration');repo=Path('/Users/home/numivivo-single-cell-20260909');remote='/Users/n/numivivo-hirisa-20260910/integration';marker='/Users/n/numivivo-hirisa-20260910/graph-publication/publication-verified.json'
print('Waiting for verified graph publication before changing remote source',flush=True)
while True:
 p=subprocess.run(['ssh','-4','macmini','test -f '+marker])
 if p.returncode==0:break
 assert p.returncode==1,p.returncode
 time.sleep(5)
published=json.loads(subprocess.check_output(['ssh','-4','macmini','cat '+marker]));assert published['status']=='published' and published['commit']=='362e7d1331db5c3e86385e34dc969dd24fb73169'
patch=json.loads((root/'admission-patch-source.json').read_text());assert all(hashlib.sha256((repo/p).read_bytes()).hexdigest()==h for p,h in patch.items())
assert not subprocess.check_output(['ssh','-4','macmini','git -C /Users/n/numivivo-h5ad-20260909 status --porcelain'],text=True).strip()
subprocess.run(['rsync','-rct','--files-from='+str(root/'admission-patch-paths.txt'),'-e','ssh -4',str(repo)+'/', 'macmini:/Users/n/numivivo-h5ad-20260909/'],check=True)
subprocess.run(['ssh','-4','macmini','mkdir -p '+remote],check=True)
subprocess.run(['rsync','-rct','-e','ssh -4',str(root/'admission-patch-source.json'),str(root/'validate_admission_remote.py'),'macmini:'+remote+'/'],check=True)
print('Graph published; integration admission tests and release build launched',flush=True)
p=subprocess.run(['ssh','-4','macmini','python3 '+remote+'/validate_admission_remote.py'])
subprocess.run(['rsync','-rct','-e','ssh -4','--exclude=runtime-release/','macmini:'+remote+'/',str(root)+'/'],check=True)
assert p.returncode==0,p.returncode
print('Integration admission validation terminal 0',flush=True)
