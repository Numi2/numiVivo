import gzip,hashlib,json
from pathlib import Path
study=Path(__file__).parent
repo=Path('/Users/home/numivivo-single-cell-20260909')
base=repo/'Tools/Omics/Benchmarks/HIRISA'
out=base/'evidence/2026-09-11-prediction-sensitivity'
out.mkdir()
def sha(b):return hashlib.sha256(b).hexdigest()
assert (study/'sensitivity-final.json').read_bytes()==(study/'remote/sensitivity.json').read_bytes()
assert (base/'DONOR_SCORE_SENSITIVITY.md').read_bytes()==(study/'remote/SENSITIVITY.md').read_bytes()
assert (study/'independent-check.json').read_bytes()==(study/'remote/independent-check.json').read_bytes()
records=[]
files={'sensitivity.json':study/'sensitivity-final.json','independent-check.json':study/'independent-check.json','remote/independent-check.json':study/'remote/independent-check.json','prediction_sensitivity.py':base/'prediction_sensitivity.py','check_prediction_sensitivity.py':base/'check_prediction_sensitivity.py','DONOR_SCORE_SENSITIVITY.md':base/'DONOR_SCORE_SENSITIVITY.md','archive.py':Path(__file__)}
for name,p in sorted(files.items()):
 b=p.read_bytes();compressed=gzip.compress(b,mtime=0);q=out/(name+'.gz');q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(compressed)
 records.append(dict(sourcePath=name,sourceBytes=len(b),sourceSHA256=sha(b),storedPath=name+'.gz',storedBytes=len(compressed),storedSHA256=sha(compressed),gzipEncoded=True))
manifest=dict(schemaVersion=1,status='passed',scope='Retrospective sensitivity of 199 completed HIRISA donor prediction scores; no fitting or new prediction',sourceBase='28a5862a140e31bc402d7f3bbef5a92fb43119d3',sourceFolds=199,comparisons=368,sourceScores=1592,records=records,physicalMacmini={'diagnosticBytesExact':True,'renderedReportBytesExact':True,'independentCheckBytesExact':True,'nativeModelRebuilt':False},limitations=['No confidence or predictive intervals','No independent-study validation','No donor deletion from fitted models','Shared training donors and contexts','Primary metric is all-source-gene response RMSE'],archiveScriptSHA256=sha(Path(__file__).read_bytes()))
(out/'manifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(members=len(records),storedBytes=sum(x['storedBytes'] for x in records),manifestSHA256=sha((out/'manifest.json').read_bytes()))))
