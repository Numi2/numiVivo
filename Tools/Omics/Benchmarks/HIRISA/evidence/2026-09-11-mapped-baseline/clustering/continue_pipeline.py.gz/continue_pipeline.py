import hashlib,json,os,shlex,shutil,subprocess,time
from pathlib import Path
root=Path('/Users/home/numivivo-hiris-20260910/clustering');graph=root.parent/'graph';remote='/Users/n/numivivo-hirisa-20260910/clustering';python='/Users/home/numivivo-singlecell-benchmark-py/bin/python'
def write(path,value):
 with path.open('x') as f:json.dump(value,f,sort_keys=True,indent=2);f.write('\n')
def read(path):return json.loads(path.read_text())
def sha(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def remote_state():
 code="from pathlib import Path;import json;r=Path("+repr(remote)+");print(json.dumps(dict(published=(r/'full-output-freeze.json').exists(),complete=(r/'native-complete.json').exists(),statuses={p.stem:json.loads(p.read_text()) for p in r.glob('full-*-status.json')})))"
 return json.loads(subprocess.check_output(['ssh','-4','macmini','python3 -c '+shlex.quote(code)],text=True))
for name,value in read(root/'source-freeze.json').items():assert sha(root/name)==value,name
assert read(root/'baron-check/checks.json')['status']=='passed'
print('Waiting for complete graph native replay and independent recall gate',flush=True)
while not (graph/'collection-complete.json').exists():
 status=graph/'independent-check-status.json'
 if status.exists():assert read(status)['returnCode']==0,'Graph independent gate failed; clustering not launched'
 time.sleep(30)
assert read(graph/'collection-complete.json')['status']=='passed'
check=graph/'independent-check/checks.json';assert read(check)['status']=='passed'
subprocess.run(['rsync','-e','ssh -4',str(check),'macmini:'+remote+'/graph-independent-checks.json'],check=True)
log=(root/'full-native-driver.log').open('x')
native=subprocess.Popen(['ssh','-4','macmini','python3 '+remote+'/run_full_native.py'],stdout=log,stderr=subprocess.STDOUT)
write(root/'pipeline-launch.json',dict(startedAtUnix=time.time(),sshPID=native.pid,graphReceiptSHA256=sha(graph/'full/receipt.json'),graphIndependentCheckSHA256=sha(check),protocolSHA256=sha(root/'protocol.json')))
print('Full native clustering launched after graph gates',flush=True)
command=['/usr/bin/time','-l',python,str(root/'reference_clustering.py'),'prepare','--graph',str(graph/'full'),'--protocol',str(root/'protocol.json'),'--graph-check',str(check),'--out',str(root/'independent-reference')]
started=time.time()
with (root/'reference-prepare.log').open('x') as f:reference=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
write(root/'reference-prepare-status.json',dict(returnCode=reference.returncode,seconds=time.time()-started,command=command))
print('Full reference preparation terminal',reference.returncode,flush=True)
while True:
 state=remote_state()
 if state['published']:break
 if native.poll() is not None:raise RuntimeError('Native clustering stopped before publication; inspect full-native-driver.log')
 time.sleep(30)
# Reuse the exact, already-qualified immutable graph bytes locally. The native
# child receipt and every input hash must agree; no duplicate gigabyte transfer.
(root/'full').mkdir(exist_ok=False)
shutil.copytree(graph/'full',root/'full/input',copy_function=os.link)
subprocess.run(['rsync','-r','-e','ssh -4','--exclude=input/','macmini:'+remote+'/full/',str(root/'full')+'/'],check=True)
assert bytes(read(root/'full/receipt.json')['input']['bytes']).hex()==sha(graph/'full/receipt.json')
command=['/usr/bin/time','-l',python,str(root/'reference_clustering.py'),'check','--bundle',str(root/'full'),'--protocol',str(root/'protocol.json'),'--graph-check',str(check),'--reference',str(root/'independent-reference'),'--out',str(root/'independent-check')]
if reference.returncode==0:
 started=time.time()
 with (root/'independent-check.log').open('x') as f:comparison=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
 write(root/'independent-check-status.json',dict(returnCode=comparison.returncode,seconds=time.time()-started,command=command))
 print('Full independent clustering check terminal',comparison.returncode,flush=True)
else:comparison=None
native_code=native.wait();log.close();print('Full native driver terminal',native_code,flush=True)
subprocess.run(['rsync','-r','-e','ssh -4','--exclude=full/','--exclude=baron/','--exclude=hagai/','--exclude=fixtures/','--exclude=legacy-clustering','macmini:'+remote+'/',str(root)+'/'],check=True)
assert native_code==0 and read(root/'native-complete.json')['status']=='passed'
assert reference.returncode==0 and comparison is not None and comparison.returncode==0
write(root/'collection-complete.json',dict(status='passed',nativeReplayPassed=True,independentFullGraphClusteringCheckPassed=True))
print('Full clustering native and independent qualification complete',flush=True)
