import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
root=Path('/Users/n/numivivo-hirisa-20260910/clustering');graph=root.parent/'graph';binary=graph/'runtime-release/numivivo'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def read(p):return json.loads(p.read_text())
def write(p,v):
 with p.open('x') as f:json.dump(v,f,sort_keys=True,indent=2);f.write('\n')
assert sha(binary)=='ee332d69aa3b3514444f00c4474f03332c296e236ed61d26cf2e2fb933e3d699'
protocol=read(root/'protocol.json');check=read(root/'graph-independent-checks.json')
assert check['status']=='passed' and check['receiptSHA256']==sha(graph/'full/receipt.json')
assert check['protocolSHA256']==protocol['graphProtocolSHA256']==sha(graph/'protocol.json')
assert read(graph/'native-complete.json')['status']=='passed'
assert read(root/'small-native-complete.json')['status']=='passed'
assert read(root/'fixtures/checks.json')['status']=='passed'
assert '6 tests in 2 suites passed' in (root/'native-tests.log').read_text()
assert read(root/'baron-exact.json')['allFrozenResultBytesExact']
assert read(root/'hagai-exact.json')['allFrozenResultBytesExact']
plan=read(root/'plan.json');assert plan['clustering']['resolution']==protocol['resolution'] and plan['clustering']['seed']==protocol['nativeSeed']
write(root/'full-launch-context.json',dict(protocolSHA256=sha(root/'protocol.json'),planSHA256=sha(root/'plan.json'),graphReceiptSHA256=sha(graph/'full/receipt.json'),graphIndependentCheckSHA256=sha(root/'graph-independent-checks.json'),binarySHA256=sha(binary),freeBytes=shutil.disk_usage(root).free,psBefore=subprocess.check_output(['ps','-axo','pid,pcpu,rss,etime,comm'],text=True)))
env={**os.environ,'NUMIVIVO_HDF5_LIBRARY':'/Users/n/numivivo-multiassay-hdf5-20260909/libhdf5.dylib'}
commands=[]
for label,args in [('full-publish',['singlecell-graph-cluster',graph/'full','--plan',root/'plan.json','--output',root/'full']),('full-verify',['singlecell-graph-cluster-verify',root/'full'])]:
 command=['/usr/bin/time','-l',str(binary),*map(str,args)];started=time.time()
 write(root/(label+'-launch.json'),dict(command=command,startedAtUnix=started,binarySHA256=sha(binary)))
 with (root/(label+'.log')).open('x') as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,env=env)
 status=dict(returnCode=r.returncode,seconds=time.time()-started,command=command,binarySHA256=sha(binary))
 write(root/(label+'-status.json'),status);commands.append(status)
 print(label,r.returncode,status['seconds'],flush=True);assert r.returncode==0,label
 if label=='full-publish':
  write(root/'full-output-freeze.json',{p.name:dict(bytes=p.stat().st_size,SHA256=sha(p)) for p in (root/'full').iterdir() if p.is_file()})
write(root/'native-complete.json',dict(status='passed',commands=commands,protocolSHA256=sha(root/'protocol.json'),scope='Full graph/PCA lineage and clustering publication/reconstruction; independent objective and reference comparison remains separate.'))
