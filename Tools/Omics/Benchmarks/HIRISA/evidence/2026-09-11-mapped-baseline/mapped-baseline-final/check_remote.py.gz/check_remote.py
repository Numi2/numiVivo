from pathlib import Path
import hashlib,json,subprocess,time
r=Path('/Users/n/numivivo-hirisa-20260910');a=r/'clustering/full';b=r/'optimized-clustering/clustering';read=lambda p:json.loads(p.read_text())
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for c in iter(lambda:f.read(1048576),b''):h.update(c)
 return h.hexdigest()
for root,freeze in [(a,r/'clustering/full-output-freeze.json'),(b,r/'optimized-clustering/clustering-output-freeze.json')]:
 for name,e in read(freeze).items():assert (root/name).stat().st_size==e['bytes'] and sha(root/name)==e['SHA256'],str(root/name)
assert sha(a/'result.json')==sha(b/'result.json') and (a/'plan.json').read_bytes()==(b/'plan.json').read_bytes()
publish=read(r/'clustering/full-publish-status.json');verify=read(r/'clustering/full-verify-status.json');opt=read(r/'optimized-clustering/clustering-publish-status.json');optverify=read(r/'optimized-clustering/clustering-verify-status.json')
assert publish['returnCode']==opt['returnCode']==optverify['returnCode']==0 and verify['returnCode']==65
assert 'No space left on device' in (r/'clustering/full-verify.log').read_text()
assert sha(Path(publish['command'][2]))==publish['binarySHA256']==verify['binarySHA256']
ps=subprocess.run(['ps','-p','11287,11289,11290','-o','pid=,command='],capture_output=True,text=True);assert ps.returncode==1 and not ps.stdout.strip()
record=dict(status='published-baseline-result-exact-reconstruction-disk-failure',observedUnix=time.time(),allBaselinePIDsAbsent=True,resultBytes=(a/'result.json').stat().st_size,resultSHA256=sha(a/'result.json'),allResultBytesMatchOptimized=True,plansExact=True,originalPublicationSeconds=publish['seconds'],originalPublicationCode=publish['returnCode'],originalVerificationSeconds=verify['seconds'],originalVerificationCode=verify['returnCode'],originalVerificationFailure='ENOSPC during reconstruction',optimizedPublicationSeconds=opt['seconds'],optimizedVerificationSeconds=optverify['seconds'],optimizedVerificationPassed=True,observedPublicationTimeRatio=publish['seconds']/opt['seconds'],originalBinarySHA256=publish['binarySHA256'],scope='Complete1.6M-cell result and plan bytes exact between historical mapped-reader and verified buffered-reader runs. Shared-host different-executable timings are descriptive, not controlled benchmarking. Historical original reconstruction failed and is not relabeled as passed.')
out=r/'mapped-baseline-final';out.mkdir(exist_ok=True);(out/'comparison.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
