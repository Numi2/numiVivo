import hashlib,json,subprocess
from pathlib import Path
root=Path('/Users/home/numivivo-hiris-20260910/graph');repo=Path('/Users/home/numivivo-single-cell-20260909');binary='/Users/home/numivivo-singlecell-benchmark-py/bin/python'
def sha(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
p=json.loads((root/'protocol.json').read_text());bundle=root/'baron-graph'
p.update(cells=8569,plan=json.loads((bundle/'plan.json').read_text()))
for name in ['scores','metadata','quality']:
 p[name+'SHA256']=sha(bundle/'input'/(name+('.bin' if name=='scores' else '.json')))
p['sourceSHA256']=bytes(json.loads((bundle/'input/receipt.json').read_text())['source']['bytes']).hex()
path=root/'baron-reference-protocol.json';path.write_text(json.dumps(p,sort_keys=True,indent=2)+'\n')
for mode,args in [('prepare',['--scores',bundle/'input/scores.bin']),('check',['--bundle',bundle,'--reference',root/'baron-independent-reference'])]:
 out=root/('baron-independent-reference' if mode=='prepare' else 'baron-independent-check')
 subprocess.run([binary,str(repo/'Tools/Omics/Benchmarks/HIRISA/reference_graph.py'),mode,'--protocol',str(path),'--out',str(out),*map(str,args)],check=True)
