import hashlib,json,shlex,subprocess,time
from pathlib import Path
root=Path('/Users/home/numivivo-hiris-20260910/graph');remote='/Users/n/numivivo-hirisa-20260910/graph';repo=Path('/Users/home/numivivo-single-cell-20260909');python='/Users/home/numivivo-singlecell-benchmark-py/bin/python'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def state():
 code="from pathlib import Path;import json;r=Path("+repr(remote)+");print(json.dumps(dict(statuses={p.stem:json.loads(p.read_text()) for p in r.glob('*-status.json')},freeze=(r/'full-output-freeze.json').exists(),complete=(r/'native-complete.json').exists())))"
 result=subprocess.check_output(['ssh','-4','macmini','python3 -c '+shlex.quote(code)],text=True)
 value=json.loads(result);(root/'collection-checkpoint.json').write_text(json.dumps(dict(checkedAtUnix=time.time(),**value),indent=2)+'\n')
 failed=[k for k,v in value['statuses'].items() if v['returnCode']!=0]
 assert not failed,failed
 return value
def collect():
 command=['rsync','-r','-e','ssh -4','--exclude=runtime-release/numivivo','--exclude=original.h5ad','--exclude=.numivivo-*','macmini:'+remote+'/',str(root)+'/']
 with (root/'collection-rsync.log').open('a') as f:subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,check=True)
last=None
while True:
 value=state();names=sorted(value['statuses'])
 if names!=last:print('Native completed stages',names,flush=True);last=names
 if value['freeze']:break
 time.sleep(30)
collect()
freeze=json.loads((root/'full-output-freeze.json').read_text())
for name,record in freeze.items():
 p=root/'full'/name;assert p.stat().st_size==record['bytes'] and sha(p)==record['SHA256'],name
print('Complete native graph collected and hashes verified',flush=True)
command=['/usr/bin/time','-l',python,str(repo/'Tools/Omics/Benchmarks/HIRISA/reference_graph.py'),'check','--protocol',str(root/'protocol.json'),'--bundle',str(root/'full'),'--reference',str(root/'independent-reference'),'--out',str(root/'independent-check')]
start=time.time()
with (root/'independent-check.log').open('x') as f: result=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
(root/'independent-check-status.json').write_text(json.dumps(dict(returnCode=result.returncode,seconds=time.time()-start,command=command),indent=2)+'\n')
assert result.returncode==0,'Independent graph check failed; evidence retained'
print('Complete independent numerical and sampled recall checks passed',flush=True)
while not state()['complete']:time.sleep(30)
collect()
(root/'collection-complete.json').write_text(json.dumps(dict(status='passed',nativeReplayPassed=True,independentNumericalAndRecallPassed=True),indent=2)+'\n')
print('Native replay and independent qualification complete',flush=True)
