import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
root=Path('/Users/n/numivivo-hirisa-20260910/graph');repo=Path('/Users/n/numivivo-h5ad-20260909');study=root.parent

def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def write(path,value):
 with path.open('x') as f:json.dump(value,f,indent=2,sort_keys=True);f.write('\n')
assert "Build of product 'numivivo' complete!" in (root/'release-build.log').read_text()
assert '12 tests in 4 suites passed' in (root/'scale-tests.log').read_text()
runtime=root/'runtime-release';runtime.mkdir(exist_ok=False);binary=runtime/'numivivo'
shutil.copy2(repo/'.build/release/numivivo',binary);binary.chmod(0o555)
sources={p:sha(repo/p) for p in subprocess.check_output(['git','-C',str(repo),'ls-files','Sources','Package.swift','Package.resolved'],text=True).splitlines() if (repo/p).is_file()}
hdf=Path('/Users/n/numivivo-multiassay-hdf5-20260909/libhdf5.dylib')
hardware=subprocess.check_output(['system_profiler','SPHardwareDataType'],text=True)
hardware='\n'.join(line for line in hardware.splitlines() if not any(v in line for v in ['Serial Number','Hardware UUID','Provisioning UDID']))
manifest=dict(binarySHA256=sha(binary),baseCommit=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),sourceFiles=sources,configuration='release',buildLogSHA256=sha(root/'release-build.log'),HDF5SHA256=sha(hdf),swift=subprocess.check_output(['swift','--version'],text=True),hardware=hardware,frozenAtUnix=time.time(),freeBytes=shutil.disk_usage(root).free)
write(runtime/'environment.json',manifest)
env={**os.environ,'NUMIVIVO_HDF5_LIBRARY':str(hdf)}
commands=[]
def run(label,args):
 command=['/usr/bin/time','-l',*map(str,args)];start=time.time()
 write(root/(label+'-launch.json'),dict(command=command,binarySHA256=manifest['binarySHA256'],startedAtUnix=start))
 with (root/(label+'.log')).open('x') as f:result=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,env=env)
 record=dict(label=label,command=command,returnCode=result.returncode,seconds=time.time()-start,binarySHA256=manifest['binarySHA256'])
 write(root/(label+'-status.json'),record);commands.append(record)
 print(label,result.returncode,record['seconds'],flush=True);assert result.returncode==0,label
run('fixture-fit',[binary,'singlecell-h5ad-pca',root/'fixture-csr.h5ad','--plan',root/'fixture-fit-plan.json','--output',root/'fixture-fit'])
run('fixture-query',[binary,'singlecell-h5ad-pca-query',root/'fixture-query.h5ad','--plan',root/'fixture-query-plan.json','--reference',root/'fixture-fit','--output',root/'fixture-query'])
for name,script in [('hnsw-gate','check_hnsw.py'),('graph-store-gate','check_graph_store.py')]:
 run(name,['python3',repo/'Tools/Omics/Reduction'/script,'--binary',binary,'--fitted',root/'fixture-fit','--query',root/'fixture-query','--out',root/name])
# Retain full smaller-cohort graph-byte regressions under the new executable.
for case in ['baron','hagai']:
 original=study/'pca/regression-inputs'/case/'prepared.h5ad'
 oldplan=json.loads((study/'pca/quality-repair'/('regression-'+case)/'plan.json').read_text())
 fitplan={key:oldplan[key] for key in ['schemaVersion','mapping','reduction']}
 fitplan['featureNamespace']=case+'-qualified-gene-ID';fitpath=root/(case+'-fit-plan.json');write(fitpath,fitplan)
 run(case+'-fit',[binary,'singlecell-h5ad-pca',original,'--plan',fitpath,'--output',root/(case+'-pca')])
 smallplan=dict(schemaVersion=1,inputKind='fitted',storage='binary',neighbors=dict(neighbors=15),execution=dict(workers=1),approximation=dict(connections=16,constructionWidth=200,searchWidth=128,seed=7,maximumDistanceEvaluations=500000000,scoreCacheBytes=33554432))
 planpath=root/(case+'-graph-plan.json');write(planpath,smallplan)
 run(case+'-graph',[binary,'singlecell-pca-neighbors',root/(case+'-pca'),'--plan',planpath,'--output',root/(case+'-graph')])
 run(case+'-graph-verify',[binary,'singlecell-pca-neighbors-verify',root/(case+'-graph')])
protocol=json.loads((root/'protocol.json').read_text())
assert json.loads((root/'plan.json').read_text())==protocol['plan']
assert sha(study/'native-release/original.h5ad')==protocol['sourceSHA256']
write(root/'full-launch-context.json',dict(protocolSHA256=sha(root/'protocol.json'),runtimeManifestSHA256=sha(runtime/'environment.json'),psBefore=subprocess.check_output(['ps','-axo','pid,etime,pcpu,rss,comm'],text=True)))
run('full-pca-refit',[binary,'singlecell-h5ad-pca',study/'native-release/original.h5ad','--plan',study/'pca/quality-repair/full-plan.json','--output',root/'full-pca'])
for name in ['scores','metadata','quality']:
 path=root/'full-pca'/(name+('.bin' if name=='scores' else '.json'))
 assert sha(path)==protocol[name+'SHA256'],name
old=study/'pca/quality-repair/full'
for name in ['scores.bin','loadings.bin','model.json','metadata.json','quality.json','plan.json']:
 assert sha(root/'full-pca'/name)==sha(old/name),name
write(root/'full-pca-regression.json',dict(status='passed',allSixFittedArtifactsByteExact=True,implementationChanged=True))
run('full-graph-publish',[binary,'singlecell-pca-neighbors',root/'full-pca','--plan',root/'plan.json','--output',root/'full'])
write(root/'full-output-freeze.json',{p.name:dict(bytes=p.stat().st_size,SHA256=sha(p)) for p in (root/'full').iterdir() if p.is_file()})
run('full-graph-verify',[binary,'singlecell-pca-neighbors-verify',root/'full'])
write(root/'native-complete.json',dict(status='passed',binarySHA256=manifest['binarySHA256'],protocolSHA256=sha(root/'protocol.json'),commands=commands,scope='Native full-source graph publication and reconstruction; independent numerical and recall check remains separate.'))
