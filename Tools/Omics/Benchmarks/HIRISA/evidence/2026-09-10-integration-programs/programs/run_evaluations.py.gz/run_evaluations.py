import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/Users/n/numivivo-hirisa-20260910/integration-programs');study=root.parent
python='/Users/n/numivivo-integration-reference-py/bin/python'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 return h.hexdigest()
def read(p):return json.loads(p.read_text())
def write(name,value):
 with (root/name).open('x') as f:json.dump(value,f,indent=2,sort_keys=True);f.write('\n')
freeze=read(root/'evaluation-execution-freeze.json');protocol=read(root/'protocol.json')
assert all(sha(root/name)==digest for name,digest in freeze['files'].items())
source=study/'native-release/original.h5ad';metadata=study/'integration-full/native/metadata.json';baseline=study/'integration-full/pca/scores.bin'
assert read(study/'integration-full/native-complete.json')['status']=='passed'
assert sha(source)==protocol['sourceSHA256'] and sha(metadata)==protocol['metadataSHA256'] and sha(baseline)==protocol['baselineScoresSHA256']
commands=[];env={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','VECLIB_MAXIMUM_THREADS':'1'}
write('start.json',dict(pid=os.getpid(),startedUnix=time.time(),executionFreezeSHA256=sha(root/'evaluation-execution-freeze.json')))
def run(name,scores,extra=[]):
 command=[python,str(root/'check_integration_programs.py'),'--source',str(source),'--metadata',str(metadata),'--design',str(root/'design.json'),'--protocol',str(root/'protocol.json'),'--scores',str(scores),'--program-reference',str(root/'reference'),'--out',str(root/(name+'.json'))]+extra
 began=time.time()
 with (root/(name+'.log')).open('x') as f:result=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,env=env)
 status=dict(name=name,returnCode=result.returncode,seconds=time.time()-began,command=command);write(name+'-status.json',status);commands.append(status);print(name,'terminal',result.returncode,flush=True)
 assert result.returncode==0,name
try:
 run('baseline',baseline)
 comparison=['--baseline',str(root/'baseline.json')]
 run('identity',baseline,comparison)
 run('library-mean-only',baseline,comparison+['--library-mean-only'])
 b=read(root/'baseline.json');identity=read(root/'identity.json');erased=read(root/'library-mean-only.json')
 assert b['folds']==identity['folds'] and b['moments']==identity['moments']
 assert all(v['withinLibraryR2'] is None or abs(v['withinLibraryR2'])<=1e-10 for f in erased['folds'] for v in f['measurements'])
 bindings={}
 native=study/'integration-full/native/scores.bin';original=read(study/'integration-full/full-output-freeze.json')['files']['scores.bin']
 assert sha(native)==original['SHA256'] and native.stat().st_size==original['bytes'];bindings['native']=dict(output=original,publicationSHA256=sha(study/'integration-full/full-output-freeze.json'))
 run('native',native,comparison)
 for seed in [7,19,41]:
  parent=study/'integration-harmony'/('seed-'+str(seed));report=read(parent/'report.json');scores=parent/'scores.bin'
  assert report['status']=='measured' and report['seed']==seed and report['cells']==protocol['cells']
  assert report['bindings']['scores']['SHA256']==protocol['baselineScoresSHA256']
  assert sha(scores)==report['output']['SHA256'] and scores.stat().st_size==report['output']['bytes']
  name='harmony-'+str(seed);bindings[name]=dict(output=report['output'],reportSHA256=sha(parent/'report.json'))
  run(name,scores,comparison)
 assert all(sha(root/name)==digest for name,digest in freeze['files'].items())
 write('complete.json',dict(status='seven-complete-program-evaluations',commands=commands,candidateBindings=bindings,identityExact=True,withinLibraryErasureZeroVerified=True,scope='Complete original measured RNA program-gradient diagnostics. Scientific margin failures and insensitive controls are retained in each result; completion does not mean all biological gates passed.'))
 print('All seven evaluations completed',flush=True)
except Exception as error:
 write('coordinator-failure.json',dict(status='failed',error=repr(error),observedUnix=time.time()));raise
