import json,os,subprocess,time,hashlib
from pathlib import Path
root=Path('/Users/n/numivivo-hirisa-20260910/integration-programs');study=root.parent
assert json.loads((root/'complete.json').read_text())['status']=='seven-complete-program-evaluations'
commands=[]
for name,scores in [('baseline',study/'integration-full/pca/scores.bin'),('native',study/'integration-full/native/scores.bin')]+[('harmony-'+str(s),study/'integration-harmony'/('seed-'+str(s))/'scores.bin') for s in [7,19,41]]:
 command=['/Users/n/numivivo-integration-reference-py/bin/python',str(root/'check_program_dense_oracle.py'),'--source',str(study/'native-release/original.h5ad'),'--metadata',str(study/'integration-full/native/metadata.json'),'--design',str(root/'design.json'),'--protocol',str(root/'protocol.json'),'--scores',str(scores),'--program-reference',str(root/'reference'),'--result',str(root/(name+'.json')),'--out',str(root/(name+'-dense-oracle.json'))]
 began=time.time()
 with (root/(name+'-dense-oracle.log')).open('x') as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','VECLIB_MAXIMUM_THREADS':'1'})
 status=dict(name=name,returnCode=r.returncode,seconds=time.time()-began,command=command)
 with (root/(name+'-dense-oracle-status.json')).open('x') as f:json.dump(status,f,indent=2);f.write('\n')
 commands.append(status);print(name,r.returncode,flush=True);assert r.returncode==0
with (root/'dense-oracles-complete.json').open('x') as f:json.dump(dict(status='passed',commands=commands,scope='All five real representations checked independently on every donor/program fold; original preservation failures unchanged.'),f,indent=2);f.write('\n')
