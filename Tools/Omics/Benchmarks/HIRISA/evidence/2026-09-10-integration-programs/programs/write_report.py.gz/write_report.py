import json
from pathlib import Path
root=Path(__file__).parent
repo=Path('/Users/home/numivivo-single-cell-20260909')
out=repo/'Tools/Omics/Benchmarks/HIRISA/INTEGRATION_PROGRAMS.md'
stages=['native','harmony-7','harmony-19','harmony-41']
data={s:json.loads((root/(s+'.json')).read_text()) for s in stages}
text='''# Complete HIRISA program-preservation diagnostic

**FAIL on the frozen complete preservation gate for native seed 7 and all three
Harmony references.** All four candidates lose more than the declared margins
in the same three control-sensitive comparisons. Eighteen of 32 comparisons
have insufficient erasure-control sensitivity. The previous [coarse response
checks](INTEGRATION_RESPONSE.md) still pass; they did not test these gradients.
The separate [raw-count donor-response predictions](PREDICTION_RESULTS.md) are
unchanged and do not use integrated PCA.

## Cohort, timing and measured targets

All **1,612,594 cells, 18,082 genes and 131 libraries** remain in preparation and
library moments. The original 79 matched donor folds evaluate 1,275,710 distinct
cells; the other 336,884 are accounted for outside these folds. No gene-count
matrix is densified. Original source SHA256 is
`0873e698ebf8770a54e6dba09724ffbeda5e1a67dbf24d4e223552d4aca7969c`.

The two existing Kang program definitions are unchanged. Exact unique original
symbol-to-Ensembl mapping retains 93/97 Hallmark interferon-alpha members and
5/5 five-gene members. CASP1, HLA-C, PNPT1 and WARS1 are missing from the first
mapping and retained as missing. Coverage thresholds are 0.8 and 1.0. There is
no alias expansion or outcome-selected membership. The five-gene set overlaps
the Hallmark set and is not independent replication. These weighted expression
summaries are not calibrated pathway activities or authoritative cell labels.

Protocol SHA256 is
`90e55cab09b15de892208a21b43ca6cb8ddfd6811c5c5fac723645b4e518c1d9`.
It was frozen after prior coarse HIRISA outcomes, Kang failures and metadata-only
symbol coverage were known, but before HIRISA per-cell program scores or gradient
metrics were inspected. The archive retains this disclosure and execution
freezes. No new result selected a different margin, cohort or model.

Program scores use signed L1-weighted log1p expression normalized to 10,000,
with every source count contributing to each cell's total. The independent
stream reads all 3,845,991,249 stored entries and 7,700,096,227 UMIs, compares
every cell total with the prior independent source QC, and compares each score
with a separate SciPy sparse matrix product. Maximum discrepancy is 2.67e-15.
Preparation took 56.65 seconds and 218,169,344 bytes peak RSS. All cells have
nonzero totals. Missing/empty targets would remain unavailable rather than zero.

## Frozen diagnostic

For each representation and program, equal-library-weighted linear ridge uses
all 20 PCs, training-only centering/scaling, ridge 1 and an unpenalized intercept.
Each donor fold scores original RNA targets withheld from fitting. Full-cohort
PCA and integration precede the diagnostic, so it is transductive information
preservation, not prospective donor-response prediction.

Within-library R² is one minus centered prediction-error variance divided by
measured target variance. Both prediction and target are centered within each
held-out library at scoring. Fitting uses the full weighted training response,
including between-library differences. Frozen allowed losses are **0.05 in the
contrast mean and 0.10 in every fold**. Near-zero target variance is unavailable.

Identity reproduces all moments/folds exactly. The library-PC-mean-only control
removes all within-library coordinate variation while retaining original RNA;
its within-library skill is zero. Baseline mean skill must exceed 0.05 to qualify
control sensitivity. Fourteen comparisons are sensitive and eighteen are not.
Even identity cannot qualify the complete gate when controls are insufficient.

Some baseline decoder R² values are negative. They mean this fitted decoder is
worse than each held-out library's own mean under this metric, not that the RNA
or PCs contain no signal. The fit mixes between- and within-library objectives;
decoder calibration requires a separate development experiment. These frozen
failures must remain intact if later models change that objective.

## Complete comparisons

H = 93 matched Hallmark members; F = the overlapping five-gene program.
Each method column is **mean loss / maximum fold loss**, baseline minus candidate.
Negative loss indicates improvement. A sensitive comparison fails when either
loss exceeds its margin. Insensitive rows remain measured but cannot qualify
biological preservation.

| Population | Treatment | Program | Baseline mean R² | Sensitive | Native 7 | Harmony 7 | Harmony 19 | Harmony 41 |
| --- | --- | --- | ---: | --- | ---: | ---: | ---: | ---: |
'''
for i,c in enumerate(data['native']['comparisons']):
 vals=[]
 for s in stages:
  x=data[s]['comparisons'][i]
  assert (x['population'],x['treatment'],x['programID'])==(c['population'],c['treatment'],c['programID'])
  fail=not(x['gates']['meanPreserved'] and x['gates']['everyFoldPreserved'])
  v=f"{x['meanWithinLibraryR2Loss']:.6f} / {x['maximumFoldWithinLibraryR2Loss']:.6f}"
  vals.append('**'+v+'**' if fail else v)
 text+='| '+ ' | '.join([c['population'],c['treatment'],'H' if c['programID'].startswith('HALLMARK') else 'F',f"{c['baselineMeanWithinLibraryR2']:.6f}",'yes' if c['controlSensitive'] else 'no',*vals])+' |\n'
text+='''
The three sensitive failures are Monocyte IFNg for both programs and Monocyte
IFN-L1 for the five-gene program. Each candidate passes both margins in 11/14
sensitive comparisons. Two additional raw margin failures occur in insensitive
NK IFNa/IFNb five-gene comparisons; they are retained without promoting them to
strong biological evidence. These observational proxy/engineering gates do not
by themselves establish causal biological damage.

## Numerical verification and runtime scope

Six focused tests pass, including exact mapping/coverage rejection, signed
sparse scoring, empty/constant targets, shuffled library moments, independent
weighted scikit-learn fitting, identity and erasure controls. Seven full data
evaluations complete in roughly ten seconds each with at most 132,300,800 bytes
peak RSS. Five independent checks then fit every actual fold/program directly
from weighted per-cell rows using augmented SVD least squares, rather than
library sufficient statistics. They compare coefficients and direct held-out
residuals for baseline, native and all three Harmony matrices. All pass; maximum
R² discrepancy is 7.15e-13 and maximum coefficient discrepancy is 3.10e-13.
Each check takes about 12.3 seconds, with at most 683,720,704 bytes peak RSS.
These are concurrent-host observations, not a controlled speed comparison.

The native matrix is the already published [seed-7 integration](FULL_INTEGRATION_RESULTS.md),
executable SHA256
`e360645362ac0707cb497eaa64277e5bf792b28d79bddea707421fdcd043495d`.
It predates sequential-ridge optimization. All three [Harmony matrices](HARMONY_REFERENCE.md)
are the original complete seeds 7/19/41. No integration refit is claimed here.

This is an independent measured-program reference, not a newly executed native
million-cell program publication. The existing native pseudobulk JSON report
is 526,518,683 bytes against its 536,870,912-byte limit, leaving insufficient
space for the added per-cell program arrays. Native full-scale scoring needs a
compact separate program artifact; increasing the global report limit does not
resolve that ownership/storage gap. Existing smaller native program evidence
remains separate. Rare-cell, neighborhood, annotation and unseen-context gates
also remain open.

## Archive and reproduce

The [archive manifest](evidence/2026-09-10-integration-programs/manifest.json)
retains all per-cell program scores, detections and totals; exact definitions,
protocol, design, execution sources/freezes; seven results with every fold and
library moment; five dense-oracle results; logs, test outcomes and original
candidate receipts. Original H5AD, metadata and five latent matrices remain
external with exact byte counts/hashes and the existing study locations in
recorded commands. Historical QC receipt status is preserved unchanged.

```sh
python Tools/Omics/Benchmarks/HIRISA/verify_archive.py \\
  Tools/Omics/Benchmarks/HIRISA/evidence/2026-09-10-integration-programs
python -m unittest discover -s Tools/Omics/Benchmarks/HIRISA \\
  -p test_integration_programs.py
```

`prepare_program_reference.py`, `check_integration_programs.py` and
`check_program_dense_oracle.py` expose their required original inputs through
`--help`. Frozen coordinator scripts in the archive retain every executed
command. `archive_integration_programs.py` preserves completed evidence without
claiming external matrix re-execution.
'''
out.write_text(text)
