import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/Users/n/numivivo-hirisa-20260910');p=root/'integration-response-v2';full=root/'integration-full'
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def write(name,v):
 with (p/name).open('x') as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n')
assert json.loads((p/'native-status.json').read_text())['returnCode']==1 and not (p/'native.json').exists()
protocol=json.loads((p/'protocol.json').read_text());freeze=json.loads((p/'native-execution-freeze.json').read_text())
assert sha(root/'design.json')==protocol['designSHA256']
for name,identity in freeze['files'].items():assert sha(p/name)==identity,name
publication=json.loads((full/'full-output-freeze.json').read_text());assert publication['status']=='published'
for name in ['scores.bin','metadata.json','plan.json','receipt.json']:assert sha(full/'native'/name)==publication['files'][name]['SHA256']
assert sha(full/'native/input/scores.bin')==protocol['baselineScoresSHA256']
command=json.loads((p/'native-start.json').read_text())['command'];assert command[-1]==str(p/'native.json');command[-1]=str(p/'native-retry.json')
write('native-retry-start.json',dict(command=command,coordinatorPID=os.getpid(),startedAtUnix=time.time(),reason='Missing design.json copied from the frozen local original; exact protocol hash verified. Prior attempt preserved. No evaluator, margins, baseline or native output changed.'))
began=time.time();env={**os.environ,'OPENBLAS_NUM_THREADS':'1','VECLIB_MAXIMUM_THREADS':'1','OMP_NUM_THREADS':'1'}
with (p/'native-retry.log').open('x') as f:result=subprocess.run(command,env=env,stdout=f,stderr=subprocess.STDOUT)
write('native-retry-status.json',dict(returnCode=result.returncode,seconds=time.time()-began));assert result.returncode==0
result=json.loads((p/'native-retry.json').read_text());assert result['bindings']['scores']['SHA256']==publication['files']['scores.bin']['SHA256']
summary=json.loads((p/'summary.json').read_text())
write('native-evaluation-link.json',dict(status='response-diagnostics-measured',resultFile='native-retry.json',resultSHA256=sha(p/'native-retry.json'),nativePublicationSHA256=sha(full/'full-output-freeze.json'),allResponseDiagnosticGatesPassed=result['allResponseDiagnosticGatesPassed'],classificationControlSensitiveContrasts=summary['negativeControlClassificationLossDetected'],classificationControlInsufficientContrasts=4,scope='Original frozen response diagnostics; initial missing-design failure retained. Marker/program/rare-cell preservation, independent method comparison and whole biological qualification remain open.'))
print('Full response evaluation complete',result['allResponseDiagnosticGatesPassed'],flush=True)
