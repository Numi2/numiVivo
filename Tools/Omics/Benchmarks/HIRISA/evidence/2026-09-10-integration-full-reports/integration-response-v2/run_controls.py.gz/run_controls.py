import json,os,subprocess,sys,time
from pathlib import Path
r=Path('/Users/home/numivivo-hiris-20260910');p=r/'integration-response-v2'
assert (p/'baseline.json').is_file()
old=json.loads((r/'integration-response/baseline.json').read_text());new=json.loads((p/'baseline.json').read_text())
for key in ['cells','libraryCells','libraryMeans','folds','conditionalDonorScatter','classificationCells','cellsOutsideMatchedClassifiers']:assert old[key]==new[key],key
(p/'baseline-exact.json').write_text(json.dumps(dict(status='passed',allNumericalResultsExact=True,reason='Binding validation only; original baseline preserved'),indent=2)+'\n')
base=[sys.executable,str(p/'check_integration_response.py'),'--source',str(r/'hirisa.h5ad'),'--metadata',str(r/'pca/quality-repair/full/metadata.json'),'--design',str(r/'design.json'),'--protocol',str(p/'protocol.json'),'--scores',str(r/'pca/quality-repair/full/scores.bin'),'--baseline',str(p/'baseline.json')]
for name,extra in [('identity',[]),('library-erasure',['--library-erasure'])]:
 began=time.time()
 with (p/(name+'.log')).open('x') as f: result=subprocess.run(base+extra+['--out',str(p/(name+'.json'))],stdout=f,stderr=subprocess.STDOUT)
 (p/(name+'-status.json')).write_text(json.dumps(dict(exitCode=result.returncode,seconds=time.time()-began),indent=2)+'\n')
 assert result.returncode==0,name
identity=json.loads((p/'identity.json').read_text());erasure=json.loads((p/'library-erasure.json').read_text())
assert identity['allResponseDiagnosticGatesPassed'] and all(c['meanBalancedAccuracyLoss']==0 and c['meanRelativeResponseDrift']==0 for c in identity['comparisons'])
assert all(abs(c['meanRelativeResponseDrift']-1)<1e-12 for c in erasure['comparisons'])
assert all(f['balancedAccuracy']==.5 for f in erasure['folds'])
summary=dict(status='complete-baseline-and-controls',cells=new['cells'],classificationCells=new['classificationCells'],cellsOutsideMatchedClassifiers=new['cellsOutsideMatchedClassifiers'],folds=len(new['folds']),identityAllExact=True,negativeControlResponseLossDetected=16,negativeControlClassificationLossDetected=sum(c['meanBalancedAccuracyLoss']>.05 for c in erasure['comparisons']),contrasts=[dict(population=c['population'],treatment=c['treatment'],baselineBalancedAccuracy=c['baselineBalancedAccuracy'],negativeControlAccuracy=c['candidateBalancedAccuracy'],classificationControlDetectsLoss=c['meanBalancedAccuracyLoss']>.05) for c in erasure['comparisons']],maximumResidentBytes=max(json.loads((p/(name+'.json')).read_text())['maximumResidentBytes'] for name in ['baseline','identity','library-erasure']),nativeEvaluation='pending-full-native-publication',scope=new['scope'])
(p/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
