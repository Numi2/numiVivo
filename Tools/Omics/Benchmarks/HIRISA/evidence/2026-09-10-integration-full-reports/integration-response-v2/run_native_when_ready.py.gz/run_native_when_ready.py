"""Run the frozen response diagnostic once the existing native job publishes."""
import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/Users/n/numivivo-hirisa-20260910');out=root/'integration-response-v2';full=root/'integration-full'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def write(name,value):
 with (out/name).open('x') as f:json.dump(value,f,indent=2,sort_keys=True);f.write('\n')
freeze=json.loads((out/'native-execution-freeze.json').read_text())
for name,identity in freeze['files'].items():assert sha(out/name)==identity,name
start=json.loads((full/'resume-start.json').read_text());coordinator=start['coordinatorPID']
write('native-wait-start.json',dict(coordinatorPID=os.getpid(),existingNativeCoordinatorPID=coordinator,startedAtUnix=time.time(),executionFreezeSHA256=sha(out/'native-execution-freeze.json')))
print('Waiting on the existing native full-cohort publication',flush=True)
try:
 while not (full/'full-output-freeze.json').exists():
  p=full/'full-publish-status.json'
  if p.exists():assert json.loads(p.read_text())['returnCode']==0,'Native publication failed'
  os.kill(coordinator,0);time.sleep(15)
 publication=json.loads((full/'full-output-freeze.json').read_text());assert publication['status']=='published'
 protocol=json.loads((out/'protocol.json').read_text())
 for name in ['scores.bin','metadata.json','plan.json','receipt.json']:
  assert sha(full/'native'/name)==publication['files'][name]['SHA256']
 assert publication['files']['metadata.json']['SHA256']==protocol['metadataSHA256']
 assert sha(full/'native/input/scores.bin')==protocol['baselineScoresSHA256']
 for name,identity in freeze['files'].items():assert sha(out/name)==identity,name
 command=['/Users/n/numivivo-integration-reference-py/bin/python',str(out/'check_integration_response.py'),'--source',str(root/'native-release/original.h5ad'),'--metadata',str(full/'native/metadata.json'),'--design',str(root/'design.json'),'--protocol',str(out/'protocol.json'),'--scores',str(full/'native/scores.bin'),'--baseline',str(out/'baseline.json'),'--out',str(out/'native.json')]
 env={**os.environ,'OPENBLAS_NUM_THREADS':'1','VECLIB_MAXIMUM_THREADS':'1','OMP_NUM_THREADS':'1'};began=time.time()
 with (out/'native.log').open('x') as log:
  process=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT)
  write('native-start.json',dict(command=command,processPID=process.pid,startedAtUnix=began,nativePublicationSHA256=sha(full/'full-output-freeze.json')))
  print('Full native response evaluation started',process.pid,flush=True);code=process.wait()
 write('native-status.json',dict(returnCode=code,seconds=time.time()-began));assert code==0
 result=json.loads((out/'native.json').read_text());assert result['bindings']['scores']['SHA256']==publication['files']['scores.bin']['SHA256']
 summary=json.loads((out/'summary.json').read_text())
 write('native-evaluation-link.json',dict(status='response-diagnostics-measured',resultSHA256=sha(out/'native.json'),nativePublicationSHA256=sha(full/'full-output-freeze.json'),allResponseDiagnosticGatesPassed=result['allResponseDiagnosticGatesPassed'],classificationControlSensitiveContrasts=summary['negativeControlClassificationLossDetected'],classificationControlInsufficientContrasts=4,scope='Frozen full-cohort response diagnostics only; marker/program/rare-cell preservation, full independent-method comparison and complete biology qualification remain open. Native replay and independent numerical status remain in integration-full.'))
 print('Full native response diagnostics measured',flush=True)
except Exception as error:
 write('native-coordinator-failure.json',dict(status='failed',error=repr(error),observedAtUnix=time.time()))
 raise
