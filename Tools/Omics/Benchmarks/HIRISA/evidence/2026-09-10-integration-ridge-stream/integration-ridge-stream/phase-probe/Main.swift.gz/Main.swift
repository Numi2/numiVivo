import Foundation
import CryptoKit
@main struct PhaseProbe {
    static func main() throws {
        let root = URL(fileURLWithPath: CommandLine.arguments[1])
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: false)
        let n = 1_612_594, d = 20, k = 100, levels = 5
        let batch = (0..<n).map { ($0 * 7 + $0 / 11) % levels }
        let x = try VivoIntegrationMatrix(rows: n, columns: d, scratch: root)
        let r = try VivoIntegrationMatrix(rows: n, columns: k, scratch: root)
        let old = try VivoIntegrationMatrix(rows: n, columns: d, scratch: root)
        let current = try VivoIntegrationMatrix(rows: n, columns: d, scratch: root)
        defer { for matrix in [x, r, old, current] { try? matrix.remove() } }
        for i in 0..<n {
            let row = (0..<d).map { sin(Double(i * ($0 + 1)) / 17) }
            try x.setRow(i, row); try old.setRow(i, row); try current.setRow(i, row)
            let weights = (0..<k).map { Double((i * 3 + $0) % 19 + 1) }
            let sum = weights.reduce(0, +)
            try r.setRow(i, weights.map { $0 / sum })
        }
        func now() -> Double { Date().timeIntervalSinceReferenceDate }
        var times: [String: Double] = [:]
        var expected = [Double](); expected.reserveCapacity(k * levels * d)
        var start = now()
        for c in 0..<k {
            var sums = [[Double]](repeating: [Double](repeating: 0, count: d), count: levels)
            for i in 0..<n {
                let weight = try r.value(i, c), row = try x.row(i)
                for j in 0..<d { sums[batch[i]][j] += weight * row[j] }
            }
            expected.append(contentsOf: sums.flatMap { $0 })
        }
        times["legacyStatistics"] = now() - start
        print("legacy statistics done", times["legacyStatistics"]!); fflush(stdout)
        start = now()
        let actual = try VivoSingleCellIntegration.streamedRidgeSums(x: x, memberships: r, batch: batch, levels: levels, activeClusters: Array(0..<k))
        times["streamedStatistics"] = now() - start
        guard actual.map({ $0.bitPattern }) == expected.map({ $0.bitPattern }) else { fatalError("weighted statistics differ") }
        var effects = [[Double]?](repeating: nil, count: k * levels)
        for c in 0..<k { for b in 0..<levels { effects[c * levels + b] = (0..<d).map { Double((c + b + $0) % 13) / 11 } } }
        start = now()
        for c in 0..<k { for b in 0..<levels {
            let effect = effects[c * levels + b]!
            for i in 0..<n where batch[i] == b {
                let weight = try r.value(i, c); var row = try old.row(i)
                for j in 0..<d { row[j] -= weight * effect[j] }
                try old.setRow(i, row)
            }
        } }
        times["legacyCorrection"] = now() - start
        print("legacy correction done", times["legacyCorrection"]!); fflush(stdout)
        start = now()
        try VivoSingleCellIntegration.applyStreamedRidgeEffects(scores: current, memberships: r, batch: batch, levels: levels, effects: effects)
        times["streamedCorrection"] = now() - start
        var hash = SHA256()
        for i in 0..<n {
            let a = try old.row(i).map { $0.bitPattern }, b = try current.row(i).map { $0.bitPattern }
            guard a == b else { fatalError("corrected row differs") }
            var bytes = a.map { $0.littleEndian }
            bytes.withUnsafeMutableBytes { hash.update(data: Data($0)) }
        }
        for matrix in [x, r, old, current] { try matrix.remove() }
        let result: [String: Any] = ["status": "passed", "cells": n, "components": d, "clusters": k, "levels": levels,
            "seconds": times, "allStatisticBitsExact": true, "allCorrectedBitsExact": true,
            "correctedValueSHA256": hash.finalize().map { String(format: "%02x", $0) }.joined(),
            "scratchRemoved": true, "weightedTableValueBytes": k * levels * d * 8,
            "scope": "Full-shape synthetic ridge IO and arithmetic phases; no initial clustering, optimization trajectory, native publication/replay or biological qualification. Sequential timings on a concurrently used host are observations, not end-to-end controlled benchmark claims."]
        try JSONSerialization.data(withJSONObject: result, options: [.prettyPrinted, .sortedKeys]).write(to: root.appendingPathComponent("results.json"), options: .withoutOverwriting)
        print("all full-shape scalar bits exact"); fflush(stdout)
    }
}
