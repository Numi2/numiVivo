import hashlib,json,subprocess,time,shutil
from pathlib import Path
p=Path(__file__).resolve().parent;repo=Path('/Users/home/numivivo-single-cell-20260909')
assert shutil.disk_usage(p).free>=8*1024**3
for name in ['VivoIntegrationMatrix.swift','VivoSingleCellIntegration.swift']:shutil.copy2(repo/'Sources/NumiVivoKit/Omics'/name,p/name)
shutil.copy2(p.parent/'solver-probe/Support.swift',p/'Support.swift')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(name,value):
 with (p/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
sources={s.name:sha(s) for s in p.glob('*.swift')};write('execution-freeze.json',dict(sources=sources,OS=subprocess.check_output(['sw_vers'],text=True),freeBytesBefore=shutil.disk_usage(p).free))
commands=[]
for label,cmd in [('build',['swiftc','-O',str(p/'Support.swift'),str(p/'VivoIntegrationMatrix.swift'),str(p/'VivoSingleCellIntegration.swift'),str(p/'Main.swift'),'-o',str(p/'probe')]),('run',['/usr/bin/time','-l',str(p/'probe'),str(p/'output')])]:
 began=time.time()
 with (p/(label+'.log')).open('x') as f:result=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 record=dict(command=cmd,returnCode=result.returncode,seconds=time.time()-began);commands.append(record);write(label+'-status.json',record);print(record,flush=True);assert result.returncode==0
assert all(sha(p/name)==identity for name,identity in sources.items())
assert not list((p/'output').glob('.integration-matrix-*'))
write('checks.json',dict(status='passed',binarySHA256=sha(p/'probe'),sourceFiles=sources,commands=commands,freeBytesAfter=shutil.disk_usage(p).free,results=json.loads((p/'output/results.json').read_text())))
