import Foundation
import CryptoKit
import Darwin
import Foundation

public enum VivoOmicsError: Error, LocalizedError, Sendable {
    case invalid(String)
    case limit(String)
    public var errorDescription: String? {
        switch self {
        case .invalid(let value): return "omics: \(value)"
        case .limit(let value): return "omics resource limit: \(value)"
        }
    }
}

import Foundation

// Shared artifact identity and validation are independent of program compilation
// and host biology. Valid fingerprint encoding is unchanged. Invalid standalone
// fingerprint construction now reports an artifact error, not a pack-header error.
public enum VivoArtifactValidationError: Error, Sendable, CustomStringConvertible {
    case invalid(String)
    case unresolved(String)
    case incompatible(String)

    public var description: String {
        switch self {
        case .invalid(let message): "Invalid artifact: \(message)"
        case .unresolved(let message): "Unresolved artifact reference: \(message)"
        case .incompatible(let message): "Incompatible artifact: \(message)"
        }
    }
}

public struct VivoFingerprint: Hashable, Codable, Sendable, CustomStringConvertible {
    public static let byteCount = 32
    public let bytes: [UInt8]
    public init(bytes: [UInt8]) throws {
        guard bytes.count == Self.byteCount else {
            throw VivoArtifactValidationError.invalid("SHA-256 fingerprints require exactly 32 bytes")
        }
        self.bytes = bytes
    }
    private enum CodingKeys: String, CodingKey { case bytes }
    public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        var array = try container.nestedUnkeyedContainer(forKey: .bytes)
        if let count = array.count, count != Self.byteCount {
            throw DecodingError.dataCorruptedError(forKey: .bytes, in: container,
                                                   debugDescription: "SHA-256 fingerprints require exactly 32 bytes")
        }
        var value: [UInt8] = []
        value.reserveCapacity(Self.byteCount)
        for _ in 0..<Self.byteCount {
            guard !array.isAtEnd else {
                throw DecodingError.dataCorruptedError(forKey: .bytes, in: container, debugDescription: "Truncated fingerprint")
            }
            value.append(try array.decode(UInt8.self))
        }
        guard array.isAtEnd else {
            throw DecodingError.dataCorruptedError(forKey: .bytes, in: container, debugDescription: "Oversized fingerprint")
        }
        bytes = value
    }
    public func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(bytes, forKey: .bytes)
    }
    public var hex: String { bytes.map { String(format: "%02x", $0) }.joined() }
    public var description: String { hex }
}


enum VivoH5ADCountStore { static let maximumEntries = 2_000_000_000 }
enum VivoPCAStorageLimits { static let maximumRows = 2000000 }
final class VivoCountRecordWriter {
    private let output: FileHandle?
    private var buffer: [UInt64] = []
    private var hasher = SHA256()
    private(set) var entries = 0
    init(_ url: URL?) throws {
        if let url {
            let fd = open(url.path, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0o600)
            guard fd >= 0 else { throw VivoOmicsError.invalid("cannot create count record file") }
            output = FileHandle(fileDescriptor: fd, closeOnDealloc: true)
        } else { output = nil }
        buffer.reserveCapacity(131_072)
    }
    func append(row: Int, feature: Int, bits: UInt64) throws {
        guard row >= 0, row <= Int(UInt32.max), feature >= 0, feature <= Int(UInt32.max),
              entries < VivoH5ADCountStore.maximumEntries else { throw VivoOmicsError.limit("count record coordinates or entries") }
        buffer.append((UInt64(row) | (UInt64(feature) << 32)).littleEndian)
        buffer.append(bits.littleEndian); entries += 1
        if buffer.count == 131_072 { try flush() }
    }
    private func flush() throws {
        guard !buffer.isEmpty else { return }
        try Task.checkCancellation()
        try buffer.withUnsafeBytes {
            let data = Data($0); hasher.update(data: data); try output?.write(contentsOf: data)
        }
        buffer.removeAll(keepingCapacity: true)
    }
    func finish() throws -> VivoFingerprint {
        try flush(); try output?.synchronize(); try output?.close()
        return try VivoFingerprint(bytes: Array(hasher.finalize()))
    }
}


struct VivoOmicsJSONKey: CodingKey {
    let stringValue: String
    let intValue: Int? = nil
    init?(stringValue: String) { self.stringValue = stringValue }
    init?(intValue: Int) { return nil }
}
func vivoOmicsRejectUnknownKeys(_ decoder: Decoder, allowed: Set<String>) throws {
    let fields = try decoder.container(keyedBy: VivoOmicsJSONKey.self)
    let unknown = Set(fields.allKeys.map(\.stringValue)).subtracting(allowed)
    guard unknown.isEmpty else {
        throw DecodingError.dataCorrupted(.init(codingPath: decoder.codingPath,
            debugDescription: "Unknown omics fields: " + unknown.sorted().joined(separator: ", ")))
    }
}


func vivoOmicsID(_ value: String) -> Bool {
    !value.isEmpty && value.utf8.count <= 1_024 &&
    value == value.trimmingCharacters(in: .whitespacesAndNewlines) &&
    !value.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) })
}
public struct VivoOmicsSample: Codable, Sendable, Equatable {
    public let id: String
    public let biologicalReplicateID: String
    public let donorID: String?
    public let condition: String
    public let batchID: String
    public let organism: String
    private enum CodingKeys: String, CodingKey { case id, biologicalReplicateID, donorID, condition, batchID, organism }
    public init(from decoder: Decoder) throws {
        try vivoOmicsRejectUnknownKeys(decoder, allowed: ["id", "biologicalReplicateID", "donorID", "condition", "batchID", "organism"])
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decode(String.self, forKey: .id)
        biologicalReplicateID = try values.decode(String.self, forKey: .biologicalReplicateID)
        donorID = try values.decodeIfPresent(String.self, forKey: .donorID)
        condition = try values.decode(String.self, forKey: .condition)
        batchID = try values.decode(String.self, forKey: .batchID)
        organism = try values.decode(String.self, forKey: .organism)
    }
    public init(id: String, biologicalReplicateID: String, donorID: String? = nil,
                condition: String, batchID: String, organism: String) {
        self.id = id; self.biologicalReplicateID = biologicalReplicateID; self.donorID = donorID
        self.condition = condition; self.batchID = batchID; self.organism = organism
    }
    public func validate() throws {
        guard [id, biologicalReplicateID, condition, batchID, organism].allSatisfy(vivoOmicsID),
              donorID.map(vivoOmicsID) ?? true else { throw VivoOmicsError.invalid("sample identity or metadata") }
    }
}

public struct VivoOmicsCellIdentity: Codable, Sendable, Equatable, Hashable {
    public let sampleID: String
    public let barcode: String
    public init(sampleID: String, barcode: String) { self.sampleID = sampleID; self.barcode = barcode }
    private enum CodingKeys: String, CodingKey { case sampleID, barcode }
    public init(from decoder: Decoder) throws {
        try vivoOmicsRejectUnknownKeys(decoder, allowed: ["sampleID", "barcode"])
        let c = try decoder.container(keyedBy: CodingKeys.self)
        sampleID = try c.decode(String.self, forKey: .sampleID); barcode = try c.decode(String.self, forKey: .barcode)
    }
}

// Type-only adapter for the unused convenience overload; probe calls run(cells:x:samples:options:matrix:) directly.
public struct VivoSingleCellReductionResult { let cells: [VivoOmicsCellIdentity]; let scores: [[Double]] }
