import hashlib,json,subprocess,struct,time,shutil
from pathlib import Path
p=Path(__file__).resolve().parent;prior=Path('/Users/n/numivivo-file-integration-20260909/real');repo=Path('/Users/n/numivivo-h5ad-20260909')
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def write(name,value):
 with (p/name).open('x') as f:json.dump(value,f,indent=2,sort_keys=True);f.write('\n')
def bits(x):return str(struct.unpack('<Q',struct.pack('<d',x))[0])
for name in ['VivoIntegrationMatrix.swift','VivoSingleCellIntegration.swift']:shutil.copy2(repo/'Sources/NumiVivoKit/Omics'/name,p/name)
shutil.copy2(p.parent/'solver-probe/Support.swift',p/'Support.swift')
sources={s.name:sha(s) for s in p.glob('*.swift')};inputs={}
for cohort in ['kang','hagai']:
 for name in ['pca/scores.bin','pca/metadata.json']+[f'plan-{s}.json' for s in [7,19,41]]:inputs[cohort+'/'+name]=sha(prior/cohort/name)
write('execution-freeze.json',dict(sources=sources,inputs=inputs,OS=subprocess.check_output(['sw_vers'],text=True),scope='Complete original Kang/Hagai PCA and exact published plans under unchanged production solver with a16KiB scratch window to force streamed ridge access; scoped numerical qualification, not replacement native receipts.'))
commands=[]
for label,cmd in [('build',['swiftc','-O',str(p/'Support.swift'),str(p/'VivoIntegrationMatrix.swift'),str(p/'VivoSingleCellIntegration.swift'),str(p/'Main.swift'),'-o',str(p/'probe')])]+[(name,['/usr/bin/time','-l',str(p/'probe'),str(prior/name),str(p/name)]) for name in ['kang','hagai']]:
 began=time.time()
 with (p/(label+'.log')).open('x') as log:result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 record=dict(command=cmd,returnCode=result.returncode,seconds=time.time()-began);commands.append(record);write(label+'-status.json',record);print(record,flush=True);assert result.returncode==0
checks=[]
for cohort in ['kang','hagai']:
 for seed in [7,19,41]:
  out=p/cohort/f'seed-{seed}';old=prior/cohort/f'seed-{seed}';actual=json.loads((out/'result.json').read_text());expected=json.loads((old/'report.json').read_text())
  for name in actual['matrixSHA256']:assert actual['matrixSHA256'][name]==sha(old/name)==sha(out/name),(cohort,seed,name)
  for key in ['levels','cellLevels','stoppingReason']:assert actual[key]==expected[key],key
  for left,right in [('objectiveBits','objectives'),('improvementBits','relativeImprovements')]:assert actual[left]==[bits(v) for v in expected[right]],left
  assert actual['assignmentCentersBits']==[[bits(v) for v in row] for row in expected['assignmentCenters']]
  assert actual['maximumRidgeResidualBits']==bits(expected['maximumRidgeResidual'])
  assert actual['ridgePenalties']==expected.get('ridgePenalties',[])
  checks.append(dict(cohort=cohort,seed=seed,cells=actual['cells'],allMatrixAndDiagnosticBitsExact=True,streamedRidgePath=True,priorReportSHA256=sha(old/'report.json'),resultSHA256=sha(out/'result.json'),matrixSHA256=actual['matrixSHA256']))
assert all(sha(p/name)==h for name,h in sources.items()) and all(sha(prior/name)==h for name,h in inputs.items())
write('checks.json',dict(status='passed',commands=commands,cases=checks,binarySHA256=sha(p/'probe'),scope='Every output coordinate, membership and trajectory diagnostic bit matches prior complete native cohorts while forced multiwindow storage exercises the new ridge passes. Numerical evidence only.'))
print('All six complete real-cohort streamed trajectories exact',flush=True)
