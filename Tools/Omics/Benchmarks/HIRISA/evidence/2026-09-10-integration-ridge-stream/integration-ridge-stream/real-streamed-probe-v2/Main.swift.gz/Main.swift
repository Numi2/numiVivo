import Foundation
import CryptoKit
private struct Cell: Decodable { let sampleID: String; let barcode: String; let group: String? }
private struct Metadata: Decodable { let cells: [Cell]; let samples: [VivoOmicsSample] }
private struct Plan: Decodable { let integration: VivoSingleCellIntegrationOptions }
@main struct RealProbe {
    static func main() throws {
        let prior = URL(fileURLWithPath: CommandLine.arguments[1]), output = URL(fileURLWithPath: CommandLine.arguments[2])
        try FileManager.default.createDirectory(at: output, withIntermediateDirectories: false)
        let metadata = try JSONDecoder().decode(Metadata.self, from: Data(contentsOf: prior.appendingPathComponent("pca/metadata.json")))
        let cells = metadata.cells.map { VivoOmicsCellIdentity(sampleID: $0.sampleID, barcode: $0.barcode) }
        let n = cells.count, d = 20
        let bytes = try Data(contentsOf: prior.appendingPathComponent("pca/scores.bin"))
        guard bytes.count == n * d * 16 else { fatalError("PCA shape") }
        for seed in [7, 19, 41] {
            let options = try JSONDecoder().decode(Plan.self, from: Data(contentsOf: prior.appendingPathComponent("plan-\(seed).json"))).integration
            let root = output.appendingPathComponent("seed-\(seed)")
            try FileManager.default.createDirectory(at: root, withIntermediateDirectories: false)
            var owned: [VivoIntegrationMatrix] = []
            func make(_ rows: Int, _ columns: Int) throws -> VivoIntegrationMatrix {
                let m = try VivoIntegrationMatrix(rows: rows, columns: columns, scratch: root, windowBytes: 16_384)
                owned.append(m); return m
            }
            let x = try make(n, d)
            try bytes.withUnsafeBytes { p in
                for i in 0..<n {
                    var row = [Double](repeating: 0, count: d)
                    for j in 0..<d {
                        let offset = (i * d + j) * 16
                        guard UInt32(littleEndian: p.loadUnaligned(fromByteOffset: offset, as: UInt32.self)) == i,
                              UInt32(littleEndian: p.loadUnaligned(fromByteOffset: offset + 4, as: UInt32.self)) == j else { fatalError("coordinates") }
                        row[j] = Double(bitPattern: UInt64(littleEndian: p.loadUnaligned(fromByteOffset: offset + 8, as: UInt64.self)))
                    }
                    try x.setRow(i, row)
                }
            }
            let began = Date().timeIntervalSinceReferenceDate
            let r = try VivoSingleCellIntegration.run(cells: cells, x: x, samples: metadata.samples, options: options, matrix: make)
            let elapsed = Date().timeIntervalSinceReferenceDate - began
            guard r.memberships.benefitsFromBatchedAccess else { fatalError("streaming branch not exercised") }
            var hashes: [String: String] = [:]
            for (name, matrix) in [("scores.bin", r.scores), ("memberships.bin", r.memberships), ("assignment-scores.bin", r.assignmentScores)] {
                hashes[name] = try matrix.writeRecords(to: root.appendingPathComponent(name)).description
            }
            let result: [String: Any] = ["cells": n, "seed": seed, "seconds": elapsed, "levels": r.levels, "cellLevels": r.cellLevels,
                "assignmentCentersBits": r.assignmentCenters.map { $0.map { String($0.bitPattern) } },
                "objectiveBits": r.objectives.map { String($0.bitPattern) },
                "improvementBits": r.relativeImprovements.map { String($0.bitPattern) },
                "maximumRidgeResidualBits": String(r.maximumRidgeResidual.bitPattern), "stoppingReason": r.stoppingReason,
                "matrixSHA256": hashes, "ridgePenalties": r.ridgePenalties ?? [], "windowBytes": 16_384, "streamedRidgePath": true]
            try JSONSerialization.data(withJSONObject: result, options: [.sortedKeys, .prettyPrinted]).write(to: root.appendingPathComponent("result.json"), options: .withoutOverwriting)
            for m in owned { try m.remove() }
            print("seed \(seed) complete \(elapsed)"); fflush(stdout)
        }
    }
}
