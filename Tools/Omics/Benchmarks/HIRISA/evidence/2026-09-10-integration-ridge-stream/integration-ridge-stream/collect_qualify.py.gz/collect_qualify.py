import json,subprocess,time,shlex
from pathlib import Path
root=Path(__file__).resolve().parent;remote='/Users/n/numivivo-hirisa-20260910/integration-ridge-stream'
probe='from pathlib import Path; import json; p=Path("'+remote+'"); print(json.dumps({n:json.loads((p/n).read_text()) for n in ["admission-tests-status.json","admission-release-build-status.json","admission-validation-complete.json"] if (p/n).exists()}))'
print('Waiting for native release validation',flush=True)
while True:
 state=json.loads(subprocess.check_output(['ssh','-4','macmini','python3 -c '+shlex.quote(probe)],text=True))
 for name,value in state.items():assert value.get('returnCode',0)==0,(name,value)
 if 'admission-validation-complete.json' in state:break
 time.sleep(5)
selectors=['--include=/*.json','--include=/*.log','--exclude=*']
subprocess.run(['rsync','-a','-e','ssh -4',*selectors,'macmini:'+remote+'/',str(root)+'/'],check=True)
with (root/'real-pipeline.log').open('x') as log:
 native=subprocess.Popen(['ssh','-4','macmini','python3 '+remote+'/qualify_real.py'],stdout=log,stderr=subprocess.STDOUT)
 fixtures=subprocess.run(['python3',str(root/'continue_fixtures.py')]);native_code=native.wait()
subprocess.run(['rsync','-a','-e','ssh -4',*selectors,'macmini:'+remote+'/',str(root)+'/'],check=True)
assert fixtures.returncode==native_code==0,(fixtures.returncode,native_code)
(root/'qualification-complete.json').write_text(json.dumps(dict(status='passed',fixtureReturnCode=fixtures.returncode,realReturnCode=native_code,scope='Native tests/build, software lifecycle, all complete Kang/Hagai numerical regressions and replay; lifetime full-shape measurement and complete HIRISA integration are separate.'),indent=2)+'\n')
paths=['admission-fixtures','mnn-fixtures','admission-fixture-complete.json','admission-fixtures-status.json','admission-fixtures.log','mnn-fixtures-status.json','mnn-fixtures.log','fixture-execution-freeze.json','qualification-complete.json']
subprocess.run(['rsync','-a','-e','ssh -4',*[str(root/p) for p in paths],'macmini:'+remote+'/'],check=True)
print('Native and full small-cohort regressions passed; fixtures synced for remote archive without duplicating large raw matrices',flush=True)
