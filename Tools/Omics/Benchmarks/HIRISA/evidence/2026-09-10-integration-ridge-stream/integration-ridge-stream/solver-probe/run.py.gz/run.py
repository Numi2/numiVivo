import hashlib,json,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parent
while not (root.parent/'admission-validation-complete.json').exists():
 p=root.parent/'admission-release-build-status.json'
 if p.exists():assert json.loads(p.read_text())['returnCode']==0
 time.sleep(5)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,v):
 with (root/name).open('x') as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n')
sources={p.name:sha(p) for p in root.glob('*.swift')};write('execution-freeze.json',dict(sources=sources,OS=subprocess.check_output(['sw_vers'],text=True),swift=subprocess.check_output(['swift','--version'],text=True)))
commands=[]
for label,source,mode in [('legacy','LegacyIntegration.swift','resident'),('current','VivoSingleCellIntegration.swift','file')]:
 binary=root/(label+'-solver')
 for step,cmd in [('build',['swiftc','-O',str(root/'Support.swift'),str(root/'VivoIntegrationMatrix.swift'),str(root/source),str(root/'Main.swift'),'-o',str(binary)]),('run',['/usr/bin/time','-l',str(binary),str(root/label),mode])]:
  start=time.time()
  with (root/(label+'-'+step+'.log')).open('x') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
  record=dict(label=label,step=step,command=cmd,returnCode=r.returncode,seconds=time.time()-start);commands.append(record);write(label+'-'+step+'-status.json',record);print(json.dumps(record),flush=True);assert r.returncode==0
reference=json.loads((root/'legacy/results.json').read_text());current=json.loads((root/'current/results.json').read_text());assert reference['cells']==current['cells']==163881
checks=[]
for a,b in zip(reference['cases'],current['cases']):
 assert a['matrixFingerprints']==b['matrixFingerprints'] and a['diagnosticSHA256']==b['diagnosticSHA256']
 assert not a['usesBatchedStorage'] and b['usesBatchedStorage'] and b['crossesTileBoundaries']
 checks.append(dict(seed=b['seed'],adaptive=b['adaptive'],matrixFingerprints=b['matrixFingerprints'],diagnosticSHA256=b['diagnosticSHA256'],allMatrixBitsExact=True,allDiagnosticBitsExact=True))
assert all(sha(root/p)==h for p,h in sources.items())
assert not any(p.name.startswith('.integration-matrix-') for p in root.rglob('*'))
write('checks.json',dict(status='passed',cases=checks,cells=163881,blockRows=163881//20,maximumTileRows=8192,commands=commands,binaries={p:sha(root/p) for p in ['legacy-solver','current-solver']},scope='Current file solver versus exact prior resident solver, fixed and expected-mass ridge. Every matrix record and all scalar diagnostics bit exact across multiple tiles in every block. Synthetic numerical test only, not full CLI or full-HIRISA or biological qualification.'))
print('Complete multiple-tile solver trajectories match previous resident solver bit for bit',flush=True)
