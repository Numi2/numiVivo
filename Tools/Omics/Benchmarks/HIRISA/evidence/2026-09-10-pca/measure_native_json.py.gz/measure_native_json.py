import hashlib,json,mmap
from pathlib import Path
r=Path('/Users/home/numivivo-hiris-20260910');p=r/'native-full/report.json';result={}
# Read canonical JSON array byte spans directly, retaining exact native float
# serialization. Quoted strings and escapes cannot terminate an array.
with p.open('rb') as f, mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as b:
 for key in ('quality','metadata'):
  prefix=('"'+key+'":').encode();start=b.find(prefix);assert start>=0
  start+=len(prefix);assert b[start] in (91,123);depth=0;quoted=False;escape=False
  for i in range(start,len(b)):
   c=b[i]
   if quoted:
    if escape:escape=False
    elif c==92:escape=True
    elif c==34:quoted=False
   elif c==34:quoted=True
   elif c in (91,123):depth+=1
   elif c in (93,125):
    depth-=1
    if depth==0:break
  h=hashlib.sha256()
  for offset in range(start,i+1,1048576):h.update(b[offset:min(i+1,offset+1048576)])
  result[key]=dict(bytes=i+1-start,SHA256=h.hexdigest(),start=start,end=i+1)
result['reportSHA256']=hashlib.sha256(p.read_bytes()).hexdigest()
(r/'pca/native-json-measurement.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
