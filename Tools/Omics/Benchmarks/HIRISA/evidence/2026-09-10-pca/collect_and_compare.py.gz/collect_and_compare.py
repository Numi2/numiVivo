import hashlib,json,os,shlex,subprocess,sys,time
from pathlib import Path
base=Path('/Users/home/numivivo-hiris-20260910/pca');repo=Path('/Users/home/numivivo-single-cell-20260909')
remote='/Users/n/numivivo-hirisa-20260910/pca/quality-repair';parent=9723
script=repo/'Tools/Omics/Benchmarks/HIRISA/compare_pca.py';python='/Users/home/numivivo-singlecell-benchmark-py/bin/python'
assert not (base/'comparison.json').exists()
record=dict(parentPID=parent,remote=remote,scriptSHA256=hashlib.sha256(script.read_bytes()).hexdigest(),startedUnix=time.time())
(base/'collection-launch.json').write_text(json.dumps(record,indent=2)+'\n')
def state():
 code='''import json,subprocess\nfrom pathlib import Path\nr=Path(%r)\np=subprocess.run(['ps','-p',%r,'-o','command='],capture_output=True,text=True)\nnames=['full-publish-status.json','full-output-freeze.json','full-verify-status.json']\nprint(json.dumps(dict(parent=p.stdout.strip(),files={name:json.loads((r/name).read_text()) for name in names if (r/name).exists()})))'''%(remote,str(parent))
 r=subprocess.run(['ssh','-4','macmini','python3 -c '+shlex.quote(code)],capture_output=True,text=True,timeout=40)
 if r.returncode:raise RuntimeError(r.stderr)
 return json.loads(r.stdout)
def wait_for(name):
 while True:
  try:s=state()
  except (OSError,RuntimeError,subprocess.TimeoutExpired) as error:
   print('Transient observation failure',str(error),flush=True);time.sleep(30);continue
  if name in s['files']:return s['files'][name]
  for key,value in s['files'].items():
   if key.endswith('-status.json') and value['returnCode']!=0:raise RuntimeError((key,value))
  if 'run_native_quality_qualification.py' not in s['parent']:raise RuntimeError('Qualification parent is no longer live and required artifact is absent: '+name)
  time.sleep(30)
freeze=wait_for('full-output-freeze.json')
print('Native output frozen; transferring complete PCA artifacts',flush=True)
subprocess.run(['rsync','-a','-e','ssh -4','--exclude=original.h5ad','macmini:'+remote+'/full/',str(base/'quality-repair/full')+'/'],check=True)
for name,expected in freeze.items():
 if name=='original.h5ad':continue
 h=hashlib.sha256()
 with (base/'quality-repair/full'/name).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 assert h.hexdigest()==expected['SHA256']
assert hashlib.sha256(script.read_bytes()).hexdigest()==record['scriptSHA256']
env={**os.environ,'OPENBLAS_NUM_THREADS':'2','OMP_NUM_THREADS':'2','VECLIB_MAXIMUM_THREADS':'2'}
command=['/usr/bin/time','-l',python,str(script),'--root',str(base.parent),'--bundle',str(base/'quality-repair/full'),'--out',str(base/'comparison.json')]
with (base/'comparison.log').open('x') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=env)
(base/'comparison-status.json').write_text(json.dumps(dict(returnCode=r.returncode,command=command),indent=2)+'\n')
assert r.returncode==0,'Full comparison failed; original log retained'
print('Complete independent comparison passed',flush=True)
replay=wait_for('full-verify-status.json');assert replay['returnCode']==0,replay
subprocess.run(['rsync','-a','-e','ssh -4','--exclude=original.h5ad','--exclude=numivivo','--exclude=.numivivo-*','macmini:'+remote+'/',str(base/'quality-repair')+'/'],check=True)
(base/'collection-complete.json').write_text(json.dumps(dict(status='passed',nativeReplayPassed=True,completeIndependentComparisonPassed=True,completedUnix=time.time()),indent=2)+'\n')
print('Native replay and local evidence collection passed',flush=True)
