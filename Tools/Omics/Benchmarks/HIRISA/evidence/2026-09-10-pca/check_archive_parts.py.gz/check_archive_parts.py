import copy,gzip,hashlib,json,subprocess,sys
from pathlib import Path
base=Path('/Users/home/numivivo-hiris-20260910/pca');out=base/'archive-verifier-gate';out.mkdir(exist_ok=False)
script=Path('/Users/home/numivivo-single-cell-20260909/Tools/Omics/Benchmarks/HIRISA/verify_archive.py')
data=(base/'feature-moments.npz').read_bytes();sha=lambda b:hashlib.sha256(b).hexdigest();records=[]
width=(len(data)+2)//3
for first in range(0,len(data),width):
 raw=data[first:first+width];encoded=gzip.compress(raw,mtime=0);name='part-'+str(len(records))+'.gz'
 records.append(dict(sourcePath='feature-moments.npz',sourceOffset=first,sourceBytes=len(raw),sourceSHA256=sha(raw),storedPath=name,storedBytes=len(encoded),storedSHA256=sha(encoded),gzipEncoded=True,payload=encoded))
results=[]
for case in ('valid-parts','gap','reordered-content','missing-part','duplicate-offset','legacy-single-file'):
 folder=out/case;folder.mkdir();rows=copy.deepcopy(records)
 if case=='gap':rows[1]['sourceOffset']+=1
 if case=='reordered-content':
  for a,b in zip(rows,[records[1],records[0],records[2]]):
   for key in ('sourceBytes','sourceSHA256','storedBytes','storedSHA256','payload'):a[key]=b[key]
  offset=0
  for r in rows:r['sourceOffset']=offset;offset+=r['sourceBytes']
 if case=='missing-part':rows.pop(1)
 if case=='duplicate-offset':rows[1]['sourceOffset']=rows[0]['sourceOffset']
 if case=='legacy-single-file':
  enc=gzip.compress(data,mtime=0);rows=[dict(sourcePath='feature-moments.npz',sourceBytes=len(data),sourceSHA256=sha(data),storedPath='source.gz',storedBytes=len(enc),storedSHA256=sha(enc),gzipEncoded=True,payload=enc)]
 for row in rows:(folder/row['storedPath']).write_bytes(row.pop('payload'))
 manifest=dict(schemaVersion=2,records=rows,fullSources={'feature-moments.npz':dict(bytes=len(data),SHA256=sha(data))})
 if case=='legacy-single-file':manifest.pop('fullSources');manifest['schemaVersion']=1
 (folder/'manifest.json').write_text(json.dumps(manifest))
 r=subprocess.run([sys.executable,str(script),str(folder)],capture_output=True,text=True)
 (out/(case+'.log')).write_text(r.stdout+r.stderr)
 expected=case in ('valid-parts','legacy-single-file');assert (r.returncode==0)==expected,(case,r.stderr)
 results.append(dict(case=case,returnCode=r.returncode,expectedPass=expected))
(out/'checks.json').write_text(json.dumps(dict(status='passed',sourceSHA256=sha(data),verifierSHA256=sha(script.read_bytes()),cases=results),indent=2)+'\n')
print(json.dumps(results))
