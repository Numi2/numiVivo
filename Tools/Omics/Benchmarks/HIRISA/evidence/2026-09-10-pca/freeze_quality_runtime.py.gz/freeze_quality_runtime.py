import copy, hashlib, json, os, shutil, subprocess, time
from pathlib import Path
root=Path('/Users/n/numivivo-hirisa-20260910/pca/quality-repair'); repo=Path('/Users/n/numivivo-h5ad-20260909')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def write(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n')
def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
runtime=root/'runtime-release';runtime.mkdir(exist_ok=False); binary=runtime/'numivivo'
source_paths=subprocess.check_output(['git','-C',str(repo),'ls-files','Sources','Package.swift','Package.resolved'],text=True).splitlines()
sources={p:sha(repo/p) for p in source_paths if (repo/p).is_file()}
shutil.copy2(repo/'.build/release/numivivo',binary);binary.chmod(0o555)
hdf=Path('/Users/n/numivivo-multiassay-hdf5-20260909/libhdf5.dylib')
env={**os.environ,'NUMIVIVO_HDF5_LIBRARY':str(hdf)}
manifest=dict(binarySHA256=sha(binary),baseCommit=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),
 sourceFiles=sources,configuration='release',buildLogSHA256=sha(root.parent/'release-build-quality-synced.log'),HDF5SHA256=sha(hdf),
 swift=subprocess.check_output(['swift','--version'],text=True),hardware=subprocess.check_output(['system_profiler','SPHardwareDataType'],text=True),
 frozenAtUnix=time.time(),freeBytes=shutil.disk_usage(root).free)
write(runtime/'environment.json',manifest); print('runtimeFrozen',manifest['binarySHA256'],flush=True)
