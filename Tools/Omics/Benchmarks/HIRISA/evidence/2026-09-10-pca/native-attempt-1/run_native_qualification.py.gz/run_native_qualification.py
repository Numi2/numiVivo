import copy, hashlib, json, os, shutil, subprocess, time
from pathlib import Path
root=Path('/Users/n/numivivo-hirisa-20260910/pca'); repo=Path('/Users/n/numivivo-h5ad-20260909')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def write(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n')
def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
runtime=root/'runtime-release';runtime.mkdir(exist_ok=False); binary=runtime/'numivivo'
source_paths=subprocess.check_output(['git','-C',str(repo),'ls-files','Sources','Package.swift','Package.resolved'],text=True).splitlines()
sources={p:sha(repo/p) for p in source_paths if (repo/p).is_file()}
shutil.copy2(repo/'.build/release/numivivo',binary);binary.chmod(0o555)
hdf=Path('/Users/n/numivivo-multiassay-hdf5-20260909/libhdf5.dylib')
env={**os.environ,'NUMIVIVO_HDF5_LIBRARY':str(hdf)}
manifest=dict(binarySHA256=sha(binary),baseCommit=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),
 sourceFiles=sources,configuration='release',buildLogSHA256=sha(root/'release-build.log'),HDF5SHA256=sha(hdf),
 swift=subprocess.check_output(['swift','--version'],text=True),hardware=subprocess.check_output(['system_profiler','SPHardwareDataType'],text=True),
 frozenAtUnix=time.time(),freeBytes=shutil.disk_usage(root).free)
write(runtime/'environment.json',manifest); print('runtimeFrozen',manifest['binarySHA256'],flush=True)
commands=[]
def run(name,args,expected=None):
 start=time.time();cmd=['/usr/bin/time','-l',str(binary),*map(str,args)]
 with (root/(name+'.log')).open('x') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env)
 status=dict(returnCode=r.returncode,seconds=time.time()-start,command=cmd,binarySHA256=manifest['binarySHA256'],expectedRejection=expected)
 write(root/(name+'-status.json'),status);commands.append(status)
 print(name,r.returncode,status['seconds'],flush=True)
 assert r.returncode==0 if expected is None else r.returncode!=0
 if expected:assert expected in (root/(name+'.log')).read_text()
reg=root/'fixture-gate';reg.mkdir(exist_ok=False);inputs=root/'regression-inputs/fixtures';plan=inputs/'plan.json'
for enc in ('csr','csc'):
 run('fixture-'+enc,['singlecell-h5ad-pca',inputs/(enc+'.h5ad'),'--plan',plan,'--output',reg/enc])
 run('fixture-'+enc+'-verify',['singlecell-h5ad-pca-verify',reg/enc])
 run('fixture-'+enc+'-overwrite',['singlecell-h5ad-pca',inputs/(enc+'.h5ad'),'--plan',plan,'--output',reg/enc],'')
for name in ('model.json','scores.bin','loadings.bin','metadata.json','quality.json'):
 assert sha(reg/'csr'/name)==sha(reg/'csc'/name),name
run('fixture-repeat',['singlecell-h5ad-pca',inputs/'csr.h5ad','--plan',plan,'--output',reg/'repeat'])
assert (reg/'repeat/receipt.json').read_bytes()==(reg/'csr/receipt.json').read_bytes()
for name,edit in [('centers',{'pca':{'retainProjectionCenters':False}}),('cache',{'maximumCacheBytes':16}),('work',{'maximumEntryVisits':1})]:
 invalid=json.loads(plan.read_text());invalid['reduction'].update(edit);p=reg/(name+'.json');write(p,invalid)
 run('fixture-reject-'+name,['singlecell-h5ad-pca',inputs/'csr.h5ad','--plan',p,'--output',reg/('reject-'+name)],'')
for name in ('scores','model'):
 dst=reg/('tamper-'+name);shutil.copytree(reg/'csr',dst);receipt=json.loads((dst/'receipt.json').read_text())
 if name=='scores':
  p=dst/'scores.bin';v=bytearray(p.read_bytes());v[0]^=1;p.write_bytes(v)
 else:
  p=dst/'model.json';v=json.loads(p.read_text());v['projectionCenters'][0]+=1;p.write_text(json.dumps(v))
 receipt[name]={'bytes':list(bytes.fromhex(sha(p)))};(dst/'receipt.json').write_text(json.dumps(receipt))
 run('fixture-tamper-'+name,['singlecell-h5ad-pca-verify',dst],'PCA source reconstruction differs')
assert not list(reg.glob('.numivivo-pca-*'))
write(reg/'checks.json',dict(status='passed',commands=len(commands),expectedRejections=sum(x['expectedRejection'] is not None for x in commands),binarySHA256=manifest['binarySHA256']))
expected=json.loads((root/'regression-inputs/expected.json').read_text())
for dataset in ('baron','hagai'):
 source=root/'regression-inputs'/dataset/'prepared.h5ad';assert sha(source)==expected[dataset]['sourceSHA256']
 command=['python3',str(repo/'Tools/Omics/Reduction/check_streamed_cli.py'),'--binary',str(binary),'--prepared',str(source.parent),'--out',str(root/('regression-'+dataset))]
 with (root/('regression-'+dataset+'.log')).open('x') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=env)
 assert r.returncode==0,dataset
 actual=json.loads((root/('regression-'+dataset)/'bundle/report.json').read_text())
 checks={key:digest(actual[key])==value for key,value in expected[dataset]['fields'].items()};assert all(checks.values()),(dataset,checks)
 write(root/('regression-'+dataset+'-exact.json'),dict(status='passed',checks=checks,sourceSHA256=sha(source)))
 print('fullDatasetRegressionPassed',dataset,flush=True)
# No native full-source result has been read before freezing these resource settings.
assert sha(root/'full-plan.json')==json.loads((root/'resource-plan-receipt.json').read_text())['fullPlanSHA256']
write(root/'full-launch.json',dict(planSHA256=sha(root/'full-plan.json'),runtimeManifestSHA256=sha(runtime/'environment.json'),psBefore=subprocess.check_output(['ps','-axo','pid,etime,pcpu,rss,comm'],text=True)))
run('full-publish',['singlecell-h5ad-pca',root.parent/'native-release/original.h5ad','--plan',root/'full-plan.json','--output',root/'full'])
write(root/'full-output-freeze.json',{p.name:dict(bytes=p.stat().st_size,SHA256=sha(p)) for p in (root/'full').iterdir() if p.is_file()})
run('full-verify',['singlecell-h5ad-pca-verify',root/'full'])
print('fullNativePublicationAndReplayPassed',flush=True)
