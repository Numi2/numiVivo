import Foundation

@main struct ProbeMain {
    static func main() throws {
        let root = URL(fileURLWithPath: CommandLine.arguments[1])
        let n = 1_612_594, entries = 34_707_084
        let offsetsReader = try VivoWindowedCountRecords(root.appendingPathComponent("offsets.bin"), entries: n + 1)
        var offsets: [Int] = []; offsets.reserveCapacity(n + 1)
        for i in 0...n {
            let record = try offsetsReader.record(i)
            precondition(record.row == i && record.feature == 0)
            offsets.append(Int(record.bits))
        }
        precondition(offsets.first == 0 && offsets.last == entries)
        let path = root.appendingPathComponent("edges.bin")
        let old = try VivoWindowedCountRecords(path, entries: entries)
        let new = try VivoBufferedCountRecords(path, entries: entries)
        var comparisonStart = Date().timeIntervalSinceReferenceDate
        for i in 0..<entries {
            let a = try old.record(i), b = try new.record(i)
            precondition(a.row == b.row && a.feature == b.feature && a.bits == b.bits)
        }
        let comparisonSeconds = Date().timeIntervalSinceReferenceDate - comparisonStart
        print("All \(entries) original edge records match bit for bit", terminator: "\n")
        var state: UInt64 = 7
        func random() -> UInt64 {
            state &+= 0x9E3779B97F4A7C15; var z = state
            z = (z ^ (z >> 30)) &* 0xBF58476D1CE4E5B9
            z = (z ^ (z >> 27)) &* 0x94D049BB133111EB
            return z ^ (z >> 31)
        }
        var order = Array(0..<n)
        for i in stride(from: n - 1, through: 1, by: -1) { order.swapAt(i, Int(random() % UInt64(i + 1))) }
        let queries = Array(order.prefix(131_072))
        var trials: [[String: Any]] = []; var expected: UInt64?
        for mode in ["mapped", "buffered", "buffered", "mapped"] {
            let mapped = try VivoWindowedCountRecords(path, entries: entries)
            let buffered = try VivoBufferedCountRecords(path, entries: entries)
            var checksum: UInt64 = 0, visits = 0, mappingLoads = 0, lastPage = -1
            comparisonStart = Date().timeIntervalSinceReferenceDate
            for row in queries {
                for i in offsets[row]..<offsets[row + 1] {
                    let record: (row: Int, feature: Int, bits: UInt64)
                    if mode == "mapped" {
                        record = try mapped.record(i)
                        let page = i * 16 / VivoWindowedCountRecords.windowBytes
                        if page != lastPage { mappingLoads += 1; lastPage = page }
                    } else { record = try buffered.record(i) }
                    precondition(record.row == row)
                    checksum = (checksum &* 1099511628211) ^ record.bits ^ UInt64(record.feature)
                    visits += 1
                }
            }
            let seconds = Date().timeIntervalSinceReferenceDate - comparisonStart
            if let expected { precondition(checksum == expected) } else { expected = checksum }
            let result: [String: Any] = ["mode": mode, "queries": queries.count, "records": visits,
                "seconds": seconds, "checksum": String(checksum), "mappedWindowLoads": mappingLoads,
                "bufferLoads": buffered.bufferLoads, "loadedBytes": buffered.loadedBytes]
            trials.append(result)
            print(String(data: try JSONSerialization.data(withJSONObject: result, options: [.sortedKeys]), encoding: .utf8)!)
            fflush(stdout)
        }
        let result: [String: Any] = ["status": "passed", "cells": n, "allEdgeRecordsBitExact": entries,
            "fullComparisonSeconds": comparisonSeconds, "seed": 7, "queryRows": queries.count, "trials": trials,
            "scope": "Same-host read-only storage primitive on the complete original HIRISA graph; fixed shuffled query panel. Existing full native clustering runs concurrently. Not a controlled end-to-end speed comparison or full optimized clustering qualification."]
        try JSONSerialization.data(withJSONObject: result, options: [.prettyPrinted, .sortedKeys]).write(to: URL(fileURLWithPath: CommandLine.arguments[2]), options: .withoutOverwriting)
    }
}
