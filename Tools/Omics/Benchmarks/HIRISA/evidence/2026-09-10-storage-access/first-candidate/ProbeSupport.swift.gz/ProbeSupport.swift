import Foundation
import Darwin
import Foundation

public enum VivoOmicsError: Error, LocalizedError, Sendable {
    case invalid(String)
    case limit(String)
    public var errorDescription: String? {
        switch self {
        case .invalid(let value): return "omics: \(value)"
        case .limit(let value): return "omics resource limit: \(value)"
        }
    }
}

enum VivoH5ADCountStore { static let maximumEntries = 2_000_000_000 }
final class VivoWindowedCountRecords {
    static let windowBytes = 16 * 1_024 * 1_024
    private let fd: Int32
    let count: Int
    private var address: UnsafeMutableRawPointer?
    private var offset = -1
    private var length = 0
    init(_ url: URL, entries: Int) throws {
        guard entries >= 0, entries <= VivoH5ADCountStore.maximumEntries else { throw VivoOmicsError.limit("mapped count entries") }
        fd = open(url.path, O_RDONLY | O_NOFOLLOW | O_NONBLOCK)
        guard fd >= 0 else { throw VivoOmicsError.invalid("cannot open count records") }
        var info = stat()
        guard fstat(fd, &info) == 0, (info.st_mode & mode_t(S_IFMT)) == mode_t(S_IFREG), info.st_size == entries * 16 else {
            _ = close(fd); throw VivoOmicsError.invalid("count record size or type")
        }
        count = entries
    }
    deinit { if let address { _ = munmap(address, length) }; _ = close(fd) }
    func record(_ index: Int) throws -> (row: Int, feature: Int, bits: UInt64) {
        guard index >= 0, index < count else { throw VivoOmicsError.invalid("count record index") }
        let byte = index * 16, next = (byte / Self.windowBytes) * Self.windowBytes
        if next != offset {
            try Task.checkCancellation()
            if let address { _ = munmap(address, length); self.address = nil }
            length = min(Self.windowBytes, count * 16 - next)
            let mapped = mmap(nil, length, PROT_READ, MAP_PRIVATE, fd, off_t(next))
            guard mapped != MAP_FAILED, let mapped else { throw VivoOmicsError.limit("cannot map count window") }
            address = mapped; offset = next
        }
        let p = address!, local = byte - offset
        let packed = UInt64(littleEndian: p.load(fromByteOffset: local, as: UInt64.self))
        return (Int(packed & 0xffff_ffff), Int(packed >> 32), UInt64(littleEndian: p.load(fromByteOffset: local + 8, as: UInt64.self)))
    }
}

