import gzip,hashlib,json,os,shutil,subprocess,time
from pathlib import Path
root=Path('/Users/n/numivivo-hirisa-20260910/clustering-storage');study=root.parent;repo=Path('/Users/n/numivivo-h5ad-20260909');graph=study/'graph'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def read(p):return json.loads(p.read_text())
def write(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n')
assert 'tests in 3 suites passed' in (root/'native-tests.log').read_text()
assert "Build of product 'numivivo' complete!" in (root/'release-build.log').read_text()
assert read(root/'probe-results.json')['status']=='passed'
paths=subprocess.check_output(['git','-C',str(repo),'ls-files','--cached','--others','--exclude-standard','Package.swift','Sources'],text=True).splitlines();sources={p:sha(repo/p) for p in sorted(set(paths)) if (repo/p).is_file()}
for name,h in read(root/'patch-source-freeze.json').items():assert sha(repo/name)==h,name
runtime=root/'runtime-release';runtime.mkdir(exist_ok=False);binary=runtime/'numivivo';shutil.copy2(repo/'.build/release/numivivo',binary);binary.chmod(0o555)
hardware=subprocess.check_output(['system_profiler','SPHardwareDataType'],text=True);hardware='\n'.join(s for s in hardware.splitlines() if not any(k in s for k in ['Serial Number','Hardware UUID','Provisioning UDID']))+'\n'
manifest=dict(binarySHA256=sha(binary),baseCommit=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),sourceFiles=sources,configuration='release',buildLogSHA256=sha(root/'release-build.log'),HDF5SHA256=sha(study.parent/'numivivo-multiassay-hdf5-20260909/libhdf5.dylib'),swift=subprocess.check_output(['swift','--version'],text=True),OS=subprocess.check_output(['sw_vers'],text=True),hardware=hardware,frozenAtUnix=time.time())
write(runtime/'environment.json',manifest)
env={**os.environ,'NUMIVIVO_HDF5_LIBRARY':'/Users/n/numivivo-multiassay-hdf5-20260909/libhdf5.dylib'};commands=[]
def run(label,args):
 cmd=['/usr/bin/time','-l',*map(str,args)];start=time.time()
 with (root/(label+'.log')).open('x') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 record=dict(label=label,command=cmd,returnCode=r.returncode,seconds=time.time()-start);commands.append(record);write(root/(label+'-status.json'),record);print(label,record['returnCode'],record['seconds'],flush=True);assert r.returncode==0,label
run('fixture-fit',[binary,'singlecell-h5ad-pca',graph/'fixture-csr.h5ad','--plan',graph/'fixture-fit-plan.json','--output',root/'fixture-fit'])
run('fixture-query',[binary,'singlecell-h5ad-pca-query',graph/'fixture-query.h5ad','--plan',graph/'fixture-query-plan.json','--reference',root/'fixture-fit','--output',root/'fixture-query'])
run('graph-fixtures',['python3',repo/'Tools/Omics/Reduction/check_graph_store.py','--binary',binary,'--fitted',root/'fixture-fit','--query',root/'fixture-query','--out',root/'graph-fixtures'])
run('clustering-fixtures',['python3',repo/'Tools/Omics/Reduction/check_file_clustering.py','--binary',binary,'--oracle',study/'clustering/legacy-clustering','--graph-fixtures',root/'graph-fixtures','--out',root/'clustering-fixtures'])
for case in ['baron','hagai']:
 run(case+'-fit',[binary,'singlecell-h5ad-pca',study/('pca/regression-inputs/'+case+'/prepared.h5ad'),'--plan',graph/(case+'-fit-plan.json'),'--output',root/(case+'-pca')])
 run(case+'-graph',[binary,'singlecell-pca-neighbors',root/(case+'-pca'),'--plan',graph/(case+'-graph-plan.json'),'--output',root/(case+'-graph')])
 for name in ['neighbors.bin','bandwidths.bin','offsets.bin','edges.bin']:
  assert sha(root/(case+'-graph')/name)==sha(graph/(case+'-graph')/name),(case,name)
 run(case+'-cluster',[binary,'singlecell-graph-cluster',root/(case+'-graph'),'--plan',study/'clustering/plan.json','--output',root/case])
 run(case+'-verify',[binary,'singlecell-graph-cluster-verify',root/case])
 previous=gzip.decompress((study/'clustering'/(case+'-expected-result.json.gz')).read_bytes());actual=(root/case/'result.json').read_bytes();assert actual==previous,case
 execution=read(root/case/'execution.json');assert execution['edgeBufferLoads']>0 and execution['maximumEdgeBufferBytes']==4096
 write(root/(case+'-exact.json'),dict(status='passed',allFrozenResultBytesExact=True,resultSHA256=sha(root/case/'result.json'),graphRecordsBitExact=True,execution=execution))
assert all(sha(repo/p)==h for p,h in sources.items())
write(root/'small-native-complete.json',dict(status='passed',commands=commands,binarySHA256=sha(binary),scope='Complete small-cohort graph/solver numerical equivalence, all-original-HIRISA-edge reader equivalence, native lifecycle, replay and tampering controls. Complete optimized HIRISA clustering and end-to-end performance remain separate.'))
