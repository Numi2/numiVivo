import Foundation

@main struct BatchProbe {
    static func main() throws {
        let root = URL(fileURLWithPath: CommandLine.arguments[1])
        let n = 1_612_594, columns = 100, blockSize = n / 20
        let matrix = try VivoIntegrationMatrix(rows: n, columns: columns, scratch: root)
        defer { try? matrix.remove() }
        let start = Date().timeIntervalSinceReferenceDate
        for i in 0..<n { try matrix.setRow(i, (0..<columns).map { Double(i % 1000) / 10000 + Double($0) }) }
        let initialization = Date().timeIntervalSinceReferenceDate - start
        var state: UInt64 = 7
        func random() -> UInt64 {
            state &+= 0x9E3779B97F4A7C15; var z = state
            z = (z ^ (z >> 30)) &* 0xBF58476D1CE4E5B9
            z = (z ^ (z >> 27)) &* 0x94D049BB133111EB
            return z ^ (z >> 31)
        }
        var order = Array(0..<n)
        for i in stride(from: n - 1, through: 1, by: -1) { order.swapAt(i, Int(random() % UInt64(i + 1))) }
        let indices = Array(order.prefix(blockSize))
        var expected: [UInt64]?, trials: [[String: Any]] = []
        for mode in ["shuffled", "tiled", "tiled", "shuffled"] {
            let began = Date().timeIntervalSinceReferenceDate; var before = 0.0, after = 0.0
            if mode == "shuffled" {
                for i in indices { for value in try matrix.row(i) { before += value } }
                for i in indices { var row = try matrix.row(i); row[0] += 1; try matrix.setRow(i, row) }
                for i in indices { for value in try matrix.row(i) { after += value } }
            } else if mode == "tiled" {
                for start in stride(from: 0, to: indices.count, by: VivoIntegrationMatrix.maximumBatchRows) {
                    let tile = Array(indices[start..<min(indices.count, start + VivoIntegrationMatrix.maximumBatchRows)])
                    for row in try matrix.gatherRows(tile) { for value in row { before += value } }
                }
                for start in stride(from: 0, to: indices.count, by: VivoIntegrationMatrix.maximumBatchRows) {
                    let tile = Array(indices[start..<min(indices.count, start + VivoIntegrationMatrix.maximumBatchRows)])
                    var rows = try matrix.gatherRows(tile)
                    for i in rows.indices { rows[i][0] += 1 }
                    try matrix.scatterRows(tile, rows: rows)
                }
                for start in stride(from: 0, to: indices.count, by: VivoIntegrationMatrix.maximumBatchRows) {
                    let tile = Array(indices[start..<min(indices.count, start + VivoIntegrationMatrix.maximumBatchRows)])
                    for row in try matrix.gatherRows(tile) { for value in row { after += value } }
                }
            }
            let seconds = Date().timeIntervalSinceReferenceDate - began
            let checks = [before.bitPattern, after.bitPattern]
            if let expected { precondition(checks == expected) } else { expected = checks }
            for i in indices.sorted() {
                var row = try matrix.row(i)
                for j in 0..<columns {
                    precondition(row[j] == Double(i % 1000) / 10000 + Double(j) + (j == 0 ? 1 : 0))
                }
                row[0] = Double(i % 1000) / 10000; try matrix.setRow(i, row)
            }
            let record: [String: Any] = ["mode": mode, "seconds": seconds, "beforeBits": String(checks[0]), "afterBits": String(checks[1])]
            trials.append(record);print(String(data: try JSONSerialization.data(withJSONObject: record, options: [.sortedKeys]), encoding: .utf8)!);fflush(stdout)
        }
        let output: [String: Any] = ["status": "passed", "matrixRows": n, "columns": columns, "blockRows": blockSize,
            "scratchBytes": matrix.fileBytes, "maximumMappedBytes": matrix.windowBytes,
            "gatheredValueBytes": blockSize * columns * 8, "tiledValueBytes": VivoIntegrationMatrix.maximumBatchRows * columns * 8, "initializationSeconds": initialization, "trials": trials,
            "allSelectedValueBitsVerified": true,
            "scope": "Synthetic storage-only read/update pattern at full HIRISA row/cluster dimensions. Compiles the exact current production matrix and uses its bounded gather/scatter APIs. Sorted gather/scatter retains selected-row arithmetic order. Not native full integration, solver equivalence, biology or a controlled end-to-end performance qualification."]
        try JSONSerialization.data(withJSONObject: output, options: [.prettyPrinted, .sortedKeys]).write(to: root.appendingPathComponent("results.json"), options: .withoutOverwriting)
        try matrix.remove()
    }
}
