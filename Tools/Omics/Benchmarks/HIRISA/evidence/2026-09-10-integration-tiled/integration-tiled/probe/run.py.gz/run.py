import hashlib,json,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parent;repo=Path('/Users/n/numivivo-h5ad-20260909')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,v):(root/name).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
assert sha(root/'VivoIntegrationMatrix.swift')==sha(repo/'Sources/NumiVivoKit/Omics/VivoIntegrationMatrix.swift')
sources={p.name:sha(p) for p in root.glob('*.swift')};write('source-freeze.json',dict(sources=sources,OS=subprocess.check_output(['sw_vers'],text=True),swift=subprocess.check_output(['swift','--version'],text=True),scope='Exact current production matrix with scoped dependency support and synthetic full-shape storage driver.'))
cmd=['swiftc','-O',str(root/'Support.swift'),str(root/'VivoIntegrationMatrix.swift'),str(root/'BatchProbe.swift'),'-o',str(root/'storage-probe')]
with (root/'build.log').open('x') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
write('build-status.json',dict(command=cmd,returnCode=r.returncode));assert r.returncode==0
cmd=['/usr/bin/time','-l',str(root/'storage-probe'),str(root)];start=time.time()
with (root/'run.log').open('x') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
assert all(sha(root/p)==h for p,h in sources.items())
status=dict(command=cmd,returnCode=r.returncode,seconds=time.time()-start,binarySHA256=sha(root/'storage-probe'),scratchRemoved=not any(root.glob('.integration-matrix-*')));write('run-status.json',status);print(json.dumps(status));assert r.returncode==0 and status['scratchRemoved']
