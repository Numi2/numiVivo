import Foundation
import CryptoKit
import Darwin
import Foundation

public enum VivoOmicsError: Error, LocalizedError, Sendable {
    case invalid(String)
    case limit(String)
    public var errorDescription: String? {
        switch self {
        case .invalid(let value): return "omics: \(value)"
        case .limit(let value): return "omics resource limit: \(value)"
        }
    }
}

import Foundation

// Shared artifact identity and validation are independent of program compilation
// and host biology. Valid fingerprint encoding is unchanged. Invalid standalone
// fingerprint construction now reports an artifact error, not a pack-header error.
public enum VivoArtifactValidationError: Error, Sendable, CustomStringConvertible {
    case invalid(String)
    case unresolved(String)
    case incompatible(String)

    public var description: String {
        switch self {
        case .invalid(let message): "Invalid artifact: \(message)"
        case .unresolved(let message): "Unresolved artifact reference: \(message)"
        case .incompatible(let message): "Incompatible artifact: \(message)"
        }
    }
}

public struct VivoFingerprint: Hashable, Codable, Sendable, CustomStringConvertible {
    public static let byteCount = 32
    public let bytes: [UInt8]
    public init(bytes: [UInt8]) throws {
        guard bytes.count == Self.byteCount else {
            throw VivoArtifactValidationError.invalid("SHA-256 fingerprints require exactly 32 bytes")
        }
        self.bytes = bytes
    }
    private enum CodingKeys: String, CodingKey { case bytes }
    public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        var array = try container.nestedUnkeyedContainer(forKey: .bytes)
        if let count = array.count, count != Self.byteCount {
            throw DecodingError.dataCorruptedError(forKey: .bytes, in: container,
                                                   debugDescription: "SHA-256 fingerprints require exactly 32 bytes")
        }
        var value: [UInt8] = []
        value.reserveCapacity(Self.byteCount)
        for _ in 0..<Self.byteCount {
            guard !array.isAtEnd else {
                throw DecodingError.dataCorruptedError(forKey: .bytes, in: container, debugDescription: "Truncated fingerprint")
            }
            value.append(try array.decode(UInt8.self))
        }
        guard array.isAtEnd else {
            throw DecodingError.dataCorruptedError(forKey: .bytes, in: container, debugDescription: "Oversized fingerprint")
        }
        bytes = value
    }
    public func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(bytes, forKey: .bytes)
    }
    public var hex: String { bytes.map { String(format: "%02x", $0) }.joined() }
    public var description: String { hex }
}


enum VivoH5ADCountStore { static let maximumEntries = 2_000_000_000 }
enum VivoPCAStorageLimits { static let maximumRows = 2000000 }
final class VivoCountRecordWriter {
    private let output: FileHandle?
    private var buffer: [UInt64] = []
    private var hasher = SHA256()
    private(set) var entries = 0
    init(_ url: URL?) throws {
        if let url {
            let fd = open(url.path, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0o600)
            guard fd >= 0 else { throw VivoOmicsError.invalid("cannot create count record file") }
            output = FileHandle(fileDescriptor: fd, closeOnDealloc: true)
        } else { output = nil }
        buffer.reserveCapacity(131_072)
    }
    func append(row: Int, feature: Int, bits: UInt64) throws {
        guard row >= 0, row <= Int(UInt32.max), feature >= 0, feature <= Int(UInt32.max),
              entries < VivoH5ADCountStore.maximumEntries else { throw VivoOmicsError.limit("count record coordinates or entries") }
        buffer.append((UInt64(row) | (UInt64(feature) << 32)).littleEndian)
        buffer.append(bits.littleEndian); entries += 1
        if buffer.count == 131_072 { try flush() }
    }
    private func flush() throws {
        guard !buffer.isEmpty else { return }
        try Task.checkCancellation()
        try buffer.withUnsafeBytes {
            let data = Data($0); hasher.update(data: data); try output?.write(contentsOf: data)
        }
        buffer.removeAll(keepingCapacity: true)
    }
    func finish() throws -> VivoFingerprint {
        try flush(); try output?.synchronize(); try output?.close()
        return try VivoFingerprint(bytes: Array(hasher.finalize()))
    }
}

