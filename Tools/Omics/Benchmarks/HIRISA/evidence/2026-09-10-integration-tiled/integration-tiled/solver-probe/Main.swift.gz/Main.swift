import Foundation
import CryptoKit
@main struct SolverProbe {
    static func main() throws {
        let root = URL(fileURLWithPath: CommandLine.arguments[1]), fileBacked = CommandLine.arguments[2] == "file"
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: false)
        let n = 163_881, d = 2
        let cells = (0..<n).map { VivoOmicsCellIdentity(sampleID: "s\($0 % 3)", barcode: "c\($0)") }
        let samples = (0..<3).map { VivoOmicsSample(id: "s\($0)", biologicalReplicateID: "d\($0)", donorID: "d\($0)", condition: "shared", batchID: "b\($0)", organism: "synthetic") }
        var cases: [[String: Any]] = []
        for (seed, adaptive): (UInt64, Bool) in [(7, false), (19, true)] {
            var options = VivoSingleCellIntegrationOptions(); options.clusters = 3; options.seed = seed
            options.maximumIterations = 2; options.relativeTolerance = 1e-8
            if adaptive { options.ridgeScaling = .expectedClusterBatchMass; options.ridge = 0.2 }
            var matrices: [VivoIntegrationMatrix] = []
            func make(_ rows: Int, _ columns: Int) throws -> VivoIntegrationMatrix {
                let result = try VivoIntegrationMatrix(rows: rows, columns: columns, scratch: fileBacked ? root : nil, windowBytes: 16_384)
                matrices.append(result); return result
            }
            let x = try make(n, d)
            for i in 0..<n { try x.setRow(i, (0..<d).map { j in sin(Double(i * (j + 1)) / 17) + Double(i % 3) / Double(j + 1) }) }
            let start = Date().timeIntervalSinceReferenceDate
            let result = try VivoSingleCellIntegration.run(cells: cells, x: x, samples: samples, options: options, matrix: make)
            let seconds = Date().timeIntervalSinceReferenceDate - start
            var fingerprints: [String: String] = [:]
            for (name, matrix) in [("scores", result.scores), ("memberships", result.memberships), ("assignment-scores", result.assignmentScores)] {
                let path = root.appendingPathComponent("\(seed)-\(name).bin")
                fingerprints[name] = try matrix.writeRecords(to: path).description
            }
            let diagnostics: [String: Any] = ["levels": result.levels, "cellLevels": result.cellLevels,
                "assignmentCenters": result.assignmentCenters.map { $0.map { String($0.bitPattern) } },
                "objectives": result.objectives.map { String($0.bitPattern) },
                "relativeImprovements": result.relativeImprovements.map { String($0.bitPattern) },
                "stoppingReason": result.stoppingReason, "maximumRidgeResidual": String(result.maximumRidgeResidual.bitPattern),
                "ridgePenalties": result.ridgePenalties?.map { $0.map { String($0.bitPattern) } } ?? []]
            let data = try JSONSerialization.data(withJSONObject: diagnostics, options: [.sortedKeys])
            try data.write(to: root.appendingPathComponent("\(seed)-diagnostics.json"), options: .withoutOverwriting)
            let check: [String: Any] = ["seed": seed, "adaptive": adaptive, "matrixFingerprints": fingerprints,
                "diagnosticSHA256": SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined(),
                "seconds": seconds, "crossesTileBoundaries": n / 20 > VivoIntegrationMatrix.maximumBatchRows,
                "usesBatchedStorage": result.memberships.benefitsFromBatchedAccess]
            cases.append(check)
            for matrix in matrices { try matrix.remove() }
            print("seed \(seed) finished in \(seconds) seconds"); fflush(stdout)
        }
        try JSONSerialization.data(withJSONObject: ["cases": cases, "cells": n, "components": d, "clusters": 3, "fileBacked": fileBacked], options: [.prettyPrinted, .sortedKeys]).write(to: root.appendingPathComponent("results.json"), options: .withoutOverwriting)
    }
}
