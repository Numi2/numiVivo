import Foundation
import CryptoKit
import Darwin
@main struct LifetimeProbe {
    static func main() throws {
        let root = URL(fileURLWithPath: CommandLine.arguments[1]), n = 1_612_594
        var results: [[String: Any]] = []
        for mode in ["baseline", "retired"] {
            let work = root.appendingPathComponent(mode)
            try FileManager.default.createDirectory(at: work, withIntermediateDirectories: false)
            defer { try? FileManager.default.removeItem(at: work) }
            var matrices: [VivoIntegrationMatrix] = []
            defer { for matrix in matrices { try? matrix.remove() } }
            var phases: [[String: Any]] = []
            func snapshot(_ phase: String) throws {
                let paths = try FileManager.default.contentsOfDirectory(at: work, includingPropertiesForKeys: nil)
                var logical: Int64 = 0, allocated: Int64 = 0
                for path in paths { var s = stat(); precondition(stat(path.path, &s) == 0); logical += s.st_size; allocated += Int64(s.st_blocks) * 512 }
                phases.append(["phase": phase, "files": paths.count, "logicalBytes": logical, "allocatedBytes": allocated])
            }
            for (slot, columns) in [20,20,20,100,100,20].enumerated() {
                let matrix = try VivoIntegrationMatrix(rows: n, columns: columns, scratch: work); matrices.append(matrix)
                for i in 0..<n { try matrix.setRow(i, (0..<columns).map { Double(i % 1000) / 1000 + Double($0) + Double(slot) }) }
            }
            try snapshot("after-solve-shape")
            if mode == "retired" { for slot in [0,1,4] { try matrices[slot].remove() } }
            try snapshot("before-serialization")
            var fingerprints: [String: String] = [:]
            for (name, slot) in [("scores",2),("memberships",3),("assignment-scores",5)] {
                let path = work.appendingPathComponent(name + ".bin")
                let fingerprint = mode == "retired" ? try matrices[slot].writeRecordsAndRemove(to: path) : try matrices[slot].writeRecords(to: path)
                let handle = try FileHandle(forReadingFrom: path); var hash = SHA256()
                while let data = try handle.read(upToCount: 1_048_576), !data.isEmpty { hash.update(data: data) }
                try handle.close()
                let readHash = hash.finalize().map { String(format: "%02x", $0) }.joined()
                precondition(readHash == fingerprint.description); fingerprints[name] = readHash
                try snapshot("after-" + name)
            }
            for matrix in matrices { try matrix.remove() }
            try snapshot("all-scratch-removed")
            results.append(["mode": mode, "fingerprints": fingerprints, "phases": phases])
            print(mode + " complete"); fflush(stdout)
        }
        precondition((results[0]["fingerprints"] as! [String:String]) == (results[1]["fingerprints"] as! [String:String]))
        let report: [String:Any] = ["status":"passed", "cells":n, "components":20, "clusters":100, "results":results,
            "allOutputBytesIndependentlyRehashed":true, "baselineAndRetiredFingerprintsExact":true,
            "scope":"Synthetic full-shape storage lifetime check with unchanged production matrix APIs. Does not run the integration solver or qualify biology; concurrent sampled peak usage is a lower bound, phase snapshots and layout accounting are retained separately."]
        try JSONSerialization.data(withJSONObject: report, options:[.prettyPrinted,.sortedKeys]).write(to: root.appendingPathComponent("results.json"), options:.withoutOverwriting)
    }
}
