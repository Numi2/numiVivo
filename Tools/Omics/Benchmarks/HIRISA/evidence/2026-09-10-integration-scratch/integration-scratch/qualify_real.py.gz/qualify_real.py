import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
repo=Path('/Users/n/numivivo-h5ad-20260909');root=Path('/Users/n/numivivo-hirisa-20260910/integration-scratch');old=Path('/Users/n/numivivo-file-integration-20260909')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def write(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n')
binary=root/'runtime-release/numivivo';environment=json.loads((binary.parent/'environment.json').read_text());assert sha(binary)==environment['binarySHA256'];assert all(sha(repo/p)==h for p,h in environment['sourceFiles'].items())
out=root/'real';out.mkdir();env={**os.environ,'NUMIVIVO_HDF5_LIBRARY':'/Users/n/numivivo-multiassay-hdf5-20260909/libhdf5.dylib'};commands=[];cases=[]
def run(label,args):
 cmd=['/usr/bin/time','-l',str(binary),*map(str,args)];start=time.time()
 with (out/(label+'.log')).open('x') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 status=dict(label=label,command=cmd,returnCode=r.returncode,seconds=time.time()-start);commands.append(status);write(out/(label+'-status.json'),status);print(label,status['returnCode'],status['seconds'],flush=True);assert r.returncode==0,label
for cohort,n,source in [('kang',24673,old/'prepared/kang.h5ad'),('hagai',13863,Path('/Users/n/numivivo-window-pca-20260909/hagai-input/prepared.h5ad'))]:
 case=out/cohort;case.mkdir();prior=old/'real'/cohort;source_sha=sha(source);old_receipt=json.loads((prior/'pca/receipt.json').read_text());assert bytes(old_receipt['source']['bytes']).hex()==source_sha
 shutil.copy2(old/'prepared'/(cohort+'-fit.json'),case/'fit-plan.json')
 run(cohort+'-fit',['singlecell-h5ad-pca',source,'--plan',case/'fit-plan.json','--output',case/'pca'])
 pca={}
 for name in ['scores.bin','loadings.bin','metadata.json','model.json','quality.json','plan.json']:
  actual=sha(case/'pca'/name);assert actual==sha(prior/'pca'/name),(cohort,name);pca[name]=actual
 assert json.loads((case/'pca/model.json').read_text())['cells']==n
 for seed in [7,19,41]:
  label=cohort+'-'+str(seed);target=case/('seed-'+str(seed));previous=prior/target.name;plan=case/('plan-'+str(seed)+'.json');shutil.copy2(prior/plan.name,plan)
  run(label+'-integrate',['singlecell-pca-integrate',case/'pca','--plan',plan,'--output',target])
  matrices={}
  for name in ['scores.bin','memberships.bin','assignment-scores.bin']:
   actual=sha(target/name);assert actual==sha(previous/name),(cohort,seed,name);matrices[name]=dict(bytes=(target/name).stat().st_size,SHA256=actual)
  report=json.loads((target/'report.json').read_text());reference=json.loads((previous/'report.json').read_text());keys=['method','cells','components','clusters','levels','cellLevels','assignmentCenters','objectives','relativeImprovements','stoppingReason','maximumRidgeResidual','ridgePenalties']
  assert all(report.get(k)==reference.get(k) for k in keys),(cohort,seed,'report');assert report['maximumBufferedValueBytes']==0
  run(label+'-verify',['singlecell-pca-integrate-verify',target])
  check=dict(status='passed',cohort=cohort,cells=n,seed=seed,sourceSHA256=source_sha,PCAFilesExact=pca,matrixFilesExact=matrices,reportNumericalFieldsExact=keys,priorReportSHA256=sha(previous/'report.json'),priorOracleGzipSHA256=sha(prior/('legacy-'+str(seed)+'.json.gz')),receiptSHA256=sha(target/'receipt.json'),singleWindowDirectAccess=True,nativeReplay=True,scope='Fresh runtime-bound native ancestors and complete-cohort numerical equality with prior published, frozen-oracle-qualified matrices. No new biological preservation or full-HIRISA integration claim.')
  write(case/('exact-'+str(seed)+'.json'),check);cases.append(check)
assert all(sha(repo/p)==h for p,h in environment['sourceFiles'].items())
write(root/'real-complete.json',dict(status='passed',binarySHA256=sha(binary),commands=commands,cases=cases))
