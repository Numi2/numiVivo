import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/Users/home/numivivo-hiris-20260910/integration-scratch');repo=Path('/Users/home/numivivo-single-cell-20260909');python='/Users/home/numivivo-singlecell-benchmark-py/bin/python';remote='/Users/n/numivivo-hirisa-20260910/integration-scratch'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def write(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n')
print('Waiting for successful native integration tests and release build',flush=True)
while not (root/'admission-validation-complete.json').exists():
 for name in ['admission-tests-status.json','admission-release-build-status.json']:
  p=root/name
  if p.exists():assert json.loads(p.read_text())['returnCode']==0,name
 time.sleep(5)
assert json.loads((root/'admission-validation-complete.json').read_text())['status']=='passed'
subprocess.run(['rsync','-rct','-e','ssh -4','macmini:'+remote+'/runtime-release',str(root)+'/'],check=True)
binary=root/'runtime-release/numivivo';manifest=json.loads((root/'runtime-release/environment.json').read_text());assert sha(binary)==manifest['binarySHA256']
assert all(sha(repo/p)==h for p,h in manifest['sourceFiles'].items())
scriptroot=repo/'Tools/Omics/Reduction';oracle=Path('/Users/home/numivivo-file-integration-20260909/legacy-integration')
write(root/'fixture-execution-freeze.json',dict(binarySHA256=sha(binary),oracleSHA256=sha(oracle),scripts={p:sha(scriptroot/p) for p in ['check_file_integration.py','check_mnn_integration.py','check_full_integration.py']},OS=subprocess.check_output(['sw_vers'],text=True),scope='Fresh self-contained fixtures generated on the laptop with its actual executable/OS identity. Mac mini receipts are not relabeled.'))
env={**os.environ,'NUMIVIVO_HDF5_LIBRARY':'/Users/home/numivivo-multiassay-hdf5-20260909/libhdf5.dylib'}
commands=[]
for name,cmd in [('admission-fixtures',[python,str(scriptroot/'check_file_integration.py'),'--binary',str(binary),'--oracle',str(oracle),'--out',str(root/'admission-fixtures')]),('mnn-fixtures',[python,str(scriptroot/'check_mnn_integration.py'),'--binary',str(binary),'--out',str(root/'mnn-fixtures')])]:
 start=time.time()
 with (root/(name+'.log')).open('x') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 status=dict(returnCode=r.returncode,seconds=time.time()-start,command=cmd);write(root/(name+'-status.json'),status);commands.append(status);print(name,status,flush=True);assert r.returncode==0,name
write(root/'admission-fixture-complete.json',dict(status='passed',commands=commands,binarySHA256=sha(binary),scope='Fitted/query ridge and MNN lifecycle, frozen legacy solver bytes, independent Scanorama numerical comparison and tampering/rejection controls; not complete-cohort integration or biological qualification.'))
