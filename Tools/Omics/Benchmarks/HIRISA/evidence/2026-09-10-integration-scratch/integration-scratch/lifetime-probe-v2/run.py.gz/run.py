import hashlib,json,shutil,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parent
while not (root.parent/'admission-validation-complete.json').exists():
 p=root.parent/'admission-release-build-status.json'
 if p.exists():assert json.loads(p.read_text())['returnCode']==0
 time.sleep(5)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,v):
 with (root/name).open('x') as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n')
sources={p.name:sha(p) for p in root.glob('*.swift')};free=shutil.disk_usage(root).free;assert free>12*1024**3,free
write('freeze.json',dict(sources=sources,freeBytesBefore=free,OS=subprocess.check_output(['sw_vers'],text=True),swift=subprocess.check_output(['swift','--version'],text=True)))
cmd=['swiftc','-O',str(root/'Support.swift'),str(root/'VivoIntegrationMatrix.swift'),str(root/'Main.swift'),'-o',str(root/'lifetime-probe')]
with (root/'build.log').open('x') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
write('build-status.json',dict(command=cmd,returnCode=r.returncode));assert r.returncode==0
peaks={mode:dict(logicalBytes=0,allocatedBytes=0,samples=0) for mode in ['baseline','retired']}
start=time.time();cmd=['/usr/bin/time','-l',str(root/'lifetime-probe'),str(root)]
with (root/'run.log').open('x') as f:
 process=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT)
 while process.poll() is None:
  for mode,peak in peaks.items():
   if not (root/mode).exists():continue
   logical=allocated=0
   try:paths=list((root/mode).glob('*'))
   except FileNotFoundError:continue
   for p in paths:
    try:s=p.stat()
    except FileNotFoundError:continue
    logical+=s.st_size;allocated+=s.st_blocks*512
   peak['logicalBytes']=max(peak['logicalBytes'],logical);peak['allocatedBytes']=max(peak['allocatedBytes'],allocated);peak['samples']+=1
  time.sleep(.025)
 code=process.wait()
assert all(sha(root/p)==h for p,h in sources.items())
status=dict(returnCode=code,seconds=time.time()-start,command=cmd,binarySHA256=sha(root/'lifetime-probe'),sampledPeaks=peaks,samplingIntervalSeconds=.025,freeBytesAfter=shutil.disk_usage(root).free,scratchAndOutputsRemoved=not any((root/mode).exists() for mode in peaks),scope='Polling observes lower bounds on transient peaks; excludes unrelated filesystem usage. Sources, deterministic phase snapshots and exact output hashes retained.')
write('run-status.json',status);print(json.dumps(status));assert code==0 and status['scratchAndOutputsRemoved']
