import hashlib, json, shutil, subprocess, time
from pathlib import Path

root = Path('/Users/n/numivivo-hirisa-20260910')
repo = Path('/Users/n/numivivo-h5ad-20260909')
def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()

original = json.loads((root / 'runtime/environment.json').read_text())
assert all(sha(repo / p) == expected for p, expected in original['sourceFiles'].items())
runtime = root / 'runtime-release';runtime.mkdir(exist_ok=False)
binary = runtime / 'numivivo'
shutil.copy2(repo / '.build/release/numivivo', binary);binary.chmod(0o555)
record = {**original, 'binarySHA256': sha(binary), 'configuration': 'release',
          'buildLogSHA256': sha(root / 'cli-release-build.log'),
          'sameOmicsSourceAsDebugRuntime': True, 'frozenAtUnix': time.time(),
          'beforeFreeBytes': shutil.disk_usage('/Users/n').free,
          'psAtFreeze': subprocess.check_output(['ps', '-axo', 'pid,etime,pcpu,rss,comm'], text=True)}
(runtime / 'environment.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'binarySHA256': record['binarySHA256'], 'sameOmicsSourceAsDebugRuntime': True}))
