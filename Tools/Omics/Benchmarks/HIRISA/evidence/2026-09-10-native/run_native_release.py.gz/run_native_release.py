import hashlib, json, os, shutil, subprocess, time
from pathlib import Path

root = Path('/Users/n/numivivo-hirisa-20260910')
runtime = root / 'runtime-release';binary = runtime / 'numivivo'
def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()

record = json.loads((runtime / 'environment.json').read_text())
checks = json.loads((root / 'reader-release-checks.json').read_text())
assert checks['status'] == 'passed' and len(checks['checks']) == 30 and checks['fullProduct']
assert sha(binary) == record['binarySHA256']
assert sha(root / 'hirisa.h5ad') == record['sourceSHA256']
env = os.environ.copy()
env['NUMIVIVO_HDF5_LIBRARY'] = '/Users/n/numivivo-multiassay-hdf5-20260909/libhdf5.dylib'
assert sha(Path(env['NUMIVIVO_HDF5_LIBRARY'])) == record['hdf5SHA256']
for name, args in [('publish', ['singlecell-h5ad-pseudobulk', str(root / 'hirisa.h5ad'),
                              '--plan', str(root / 'stream-plan.json'), '--output', str(root / 'native-release')]),
                   ('verify', ['singlecell-h5ad-pseudobulk-verify', str(root / 'native-release')])]:
    command = ['/usr/bin/time', '-l', str(binary), *args]
    started = time.time()
    with (root / ('native-release-' + name + '.log')).open('x') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, env=env)
    status = {'returnCode': result.returncode, 'seconds': time.time() - started, 'command': command,
              'binarySHA256': record['binarySHA256'], 'sourceSHA256': record['sourceSHA256'],
              'readerChecksSHA256': sha(root / 'reader-release-checks.json'),
              'freeBytesAfter': shutil.disk_usage('/Users/n').free}
    (root / ('native-release-' + name + '-status.json')).write_text(json.dumps(status, indent=2) + '\n')
    print(json.dumps(status), flush=True)
    if result.returncode:
        break
