import hashlib, json
from pathlib import Path

root = Path('/Users/n/numivivo-hirisa-20260910')
def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1_048_576), b''):
            h.update(block)
    return h.hexdigest()
def fp(value):
    return bytes(value['bytes']).hex()

debug = json.loads((root / 'native-full/receipt.json').read_text())
release = json.loads((root / 'native-release/receipt.json').read_text())
de = json.loads((root / 'runtime/environment.json').read_text())
re = json.loads((root / 'runtime-release/environment.json').read_text())
assert de['sourceFiles'] == re['sourceFiles']
assert digest(root / 'runtime/numivivo') == de['binarySHA256']
assert digest(root / 'runtime-release/numivivo') == re['binarySHA256']
assert de['sourceSHA256'] == re['sourceSHA256'] == fp(debug['source']) == fp(release['source'])
assert (root / 'native-full/plan.json').read_bytes() == (root / 'native-release/plan.json').read_bytes()
assert digest(root / 'native-full/plan.json') == fp(debug['plan']) == fp(release['plan'])
sha = hashlib.sha256();size = 0
with (root / 'native-full/report.json').open('rb') as a, (root / 'native-release/report.json').open('rb') as b:
    while True:
        left, right = a.read(1_048_576), b.read(1_048_576)
        assert left == right, 'Different report bytes between frozen builds'
        if not left:
            break
        sha.update(left);size += len(left)
assert sha.hexdigest() == fp(debug['report']) == fp(release['report'])
result = {'status': 'passed', 'sameReportBytes': True, 'reportBytes': size,
          'reportSHA256': sha.hexdigest(), 'planSHA256': fp(debug['plan']),
          'sourceSHA256': de['sourceSHA256'], 'sameOmicsSource': True,
          'debugBinarySHA256': de['binarySHA256'], 'releaseBinarySHA256': re['binarySHA256'],
          'debugImplementation': fp(debug['implementation']), 'releaseImplementation': fp(release['implementation']),
          'scope': 'Direct blockwise equality of complete reports and plans from distinct frozen binaries; native replay is recorded separately.'}
(root / 'native-report-identity.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
