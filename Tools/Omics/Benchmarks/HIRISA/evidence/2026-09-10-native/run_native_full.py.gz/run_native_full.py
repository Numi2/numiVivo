import hashlib,json,os,platform,shutil,subprocess,time
from pathlib import Path
root=Path('/Users/n/numivivo-hirisa-20260910');repo=Path('/Users/n/numivivo-h5ad-20260909')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
runtime=root/'runtime';runtime.mkdir(exist_ok=False)
binary=runtime/'numivivo';shutil.copy2(repo/'.build/debug/numivivo',binary);binary.chmod(0o555)
source=root/'hirisa.h5ad';prepared=json.loads((root/'prepared-receipt.json').read_text())
assert sha(source)==prepared['sourceSHA256']
env=os.environ.copy();env['NUMIVIVO_HDF5_LIBRARY']='/Users/n/numivivo-multiassay-hdf5-20260909/libhdf5.dylib'
record={'binarySHA256':sha(binary),'sourceSHA256':sha(source),'sourceBytes':source.stat().st_size,'hdf5SHA256':sha(Path(env['NUMIVIVO_HDF5_LIBRARY'])),'baseCommit':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD']).decode().strip(),'sourceFiles':{str(p.relative_to(repo)):sha(p) for p in sorted((repo/'Sources/NumiVivoKit/Omics').glob('*.swift'))},'macOS':platform.mac_ver(),'machine':platform.machine(),'beforeFreeBytes':shutil.disk_usage('/System/Volumes/Data').free}
(runtime/'environment.json').write_text(json.dumps(record,indent=2)+'\n')
for name,args in [('publish',['singlecell-h5ad-pseudobulk',str(source),'--plan',str(root/'stream-plan.json'),'--output',str(root/'native-full')]),('verify',['singlecell-h5ad-pseudobulk-verify',str(root/'native-full')])]:
 command=['/usr/bin/time','-l',str(binary),*args]
 started=time.time()
 with (root/('native-full-'+name+'.log')).open('x') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=env)
 status={'returnCode':result.returncode,'seconds':time.time()-started,'command':command,'binarySHA256':record['binarySHA256'],'sourceSHA256':record['sourceSHA256'],'freeBytesAfter':shutil.disk_usage('/System/Volumes/Data').free}
 (root/('native-full-'+name+'-status.json')).write_text(json.dumps(status,indent=2)+'\n')
 print(json.dumps(status),flush=True)
 if result.returncode:break
