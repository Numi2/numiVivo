"""Observe the existing native driver; collect/check once publication finishes."""
import hashlib,json,os,shlex,subprocess,sys,time
from pathlib import Path
root=Path('/Users/home/numivivo-hiris-20260910/optimized-clustering');study=root.parent
remote='/Users/n/numivivo-hirisa-20260910/optimized-clustering'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(p.read_text())
def write(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n')
freeze=read(root/'independent-source-freeze.json')
for name,digest in freeze['files'].items():assert sha(root/name)==digest,name
published=read(study/'clustering-reference-publication/publication-verified.json')
assert published['status']=='published' and published['commit']==freeze['publishedCommit']
assert read(root/'checker-qualification-v2/qualification.json')['status']=='passed'
assert read(root/'collector-qualification.json')['status']=='passed'
assert not (root/'collected').exists()
protocol=read(root/'protocol.json');assert sha(root/'comparison-protocol.json')==sha(study/'clustering/protocol.json')
write(root/'independent-coordinator-start.json',dict(pid=os.getpid(),startedUnix=time.time(),freezeSHA256=sha(root/'independent-source-freeze.json'),nativeDriverAction='Observe existing process only; never relaunch native work'))
code='''from pathlib import Path
import json,subprocess
r=Path(REMOTE);start=json.loads((r/'start.json').read_text());pid=start['coordinatorPID']
p=subprocess.run(['ps','-p',str(pid),'-o','command='],stdout=subprocess.PIPE,text=True)
live=p.returncode==0 and str(r/'run_native.py') in p.stdout
print(json.dumps(dict(coordinatorPID=pid,coordinatorLive=live,published=(r/'clustering-output-freeze.json').exists(),complete=(r/'native-complete.json').exists(),failure=json.loads((r/'coordinator-failure.json').read_text()) if (r/'coordinator-failure.json').exists() else None,statuses={p.name:json.loads(p.read_text()) for p in r.glob('*-status.json')})))
'''.replace('REMOTE',repr(remote))
last=None

def state():
 global last
 while True:
  try:
   current=json.loads(subprocess.check_output(['ssh','-4','macmini','python3 -c '+shlex.quote(code)],text=True,timeout=30))
   break
  except (subprocess.SubprocessError,json.JSONDecodeError) as error:
   with (root/'independent-observation-errors.jsonl').open('a') as f:f.write(json.dumps(dict(observedUnix=time.time(),error=repr(error),action='Retry same existing driver; no restart'))+'\n')
   time.sleep(30)
 if current!=last:
  with (root/'independent-observations.jsonl').open('a') as f:f.write(json.dumps(dict(observedUnix=time.time(),state=current))+'\n')
  print('Native state',json.dumps(current),flush=True);last=current
 assert current['failure'] is None,('Native driver failed',current['failure'])
 assert all(v['returnCode']==0 for v in current['statuses'].values()),'Native stage failed'
 assert current['coordinatorLive'] or current['complete'],'Native driver missing without completion; inspect retained state'
 return current

def collect_records():
 destination=root/'native-records';destination.mkdir(exist_ok=True)
 subprocess.run(['rsync','-r','-e','ssh -4','--exclude=*/','macmini:'+remote+'/',str(destination)+'/'],check=True)

try:
 while not state()['published']:time.sleep(30)
 collect_records()
 records=root/'native-records'
 assert read(records/'clustering-publish-status.json')['returnCode']==0
 assert read(records/'graph-equivalence.json')['status']=='passed'
 assert read(records/'pca-exact.json')['allSixPriorPayloadsExact']
 for name,digest in freeze['files'].items():assert sha(root/name)==digest,name
 command=[sys.executable,str(root/'qualified-reference-tools/collect_clustering.py'),'--host','macmini','--remote-bundle',remote+'/clustering','--reference-graph',str(study/'graph/full'),'--protocol',str(root/'comparison-protocol.json'),'--graph-check',str(study/'graph/independent-check/checks.json'),'--reference',str(study/'clustering/independent-reference'),'--out',str(root/'collected')]
 began=time.time()
 with (root/'independent-collection.log').open('x') as f:run=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
 write(root/'independent-collection-status.json',dict(returnCode=run.returncode,seconds=time.time()-began,command=command))
 assert run.returncode==0,'Independent collection/comparison failed; evidence retained'
 # Native replay can continue while the independent full partition is checked.
 while not state()['complete']:time.sleep(30)
 collect_records();native=read(records/'native-complete.json')
 assert native['status']=='passed' and native['binarySHA256']==protocol['runtimeSHA256']
 assert len(native['commands'])==4 and all(v['returnCode']==0 for v in native['commands'])
 frozen=read(records/'clustering-output-freeze.json');bundle=root/'collected/bundle'
 for name,identity in frozen.items():assert (bundle/name).stat().st_size==identity['bytes'] and sha(bundle/name)==identity['SHA256'],name
 checked=read(root/'collected/independent-check/checks.json');assert checked['status']=='passed' and checked['cells']==protocol['cells']
 assert read(root/'collected/complete.json')['status']=='passed'
 write(root/'collection-complete.json',dict(status='passed',cells=protocol['cells'],nativeReplayPassed=True,independentAllCellPartitionCheckPassed=True,nativeRuntimeSHA256=protocol['runtimeSHA256'],nativeCompletionSHA256=sha(records/'native-complete.json'),independentCheckSHA256=sha(root/'collected/independent-check/checks.json'),referenceReuse=checked['referenceReuse'],scope='Current-runtime complete PCA/graph/clustering, exact native replay and full independent partition/objective/connectivity checks. Original graph/igraph receipts unchanged; biological qualification remains separate.'))
 print('Optimized full clustering native and independent qualification complete',flush=True)
except Exception as error:
 write(root/'independent-coordinator-failure.json',dict(status='failed',error=repr(error),observedUnix=time.time()));raise
