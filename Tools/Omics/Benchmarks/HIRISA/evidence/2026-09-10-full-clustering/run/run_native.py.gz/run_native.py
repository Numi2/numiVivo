import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
study=Path('/Users/n/numivivo-hirisa-20260910');root=study/'optimized-clustering';repo=Path('/Users/n/numivivo-h5ad-20260909');runtime=study/'integration-ridge-stream/runtime-release';binary=runtime/'numivivo'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 return h.hexdigest()
def read(p):return json.loads(p.read_text())
def write(name,v):
 with (root/name).open('x') as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n')
protocol=read(root/'protocol.json');environment=read(runtime/'environment.json');published=read(study/'ridge-publication/publication-verified.json')
assert published['status']=='published' and published['commit']==protocol['publishedCommit']
assert sha(binary)==protocol['runtimeSHA256']==environment['binarySHA256']
assert all(sha(repo/name)==identity for name,identity in environment['sourceFiles'].items())
assert read(study/'integration-ridge-stream/qualification-complete.json')['status']=='passed'
assert sha(study/'native-release/original.h5ad')==protocol['sourceSHA256']
for name,identity in protocol['plans'].items():assert sha(root/name)==identity,name
assert read(study/'graph/native-complete.json')['status']=='passed'
assert read(study/'integration-full/native-complete.json')['status']=='passed'
assert read(study/'integration-harmony/complete.json')['status']=='three-complete-reference-fits-and-response-evaluations'
assert shutil.disk_usage(root).free>=protocol['headroomGiB']['initial']*1024**3
hdf=Path('/Users/n/numivivo-multiassay-hdf5-20260909/libhdf5.dylib');assert sha(hdf)==environment['HDF5SHA256']
write('start.json',dict(coordinatorPID=os.getpid(),startedAtUnix=time.time(),freeBytes=shutil.disk_usage(root).free,binarySHA256=sha(binary),sourceFiles=environment['sourceFiles'],protocolSHA256=sha(root/'protocol.json'),psBefore=subprocess.check_output(['ps','-axo','pid,etime,pcpu,rss,comm'],text=True)))
commands=[];env={**os.environ,'NUMIVIVO_HDF5_LIBRARY':str(hdf)}
def run(name,arguments,minimum):
 began=time.time()
 while shutil.disk_usage(root).free<minimum*1024**3:
  with (root/(name+'-headroom.jsonl')).open('a') as f:f.write(json.dumps(dict(observedUnix=time.time(),freeBytes=shutil.disk_usage(root).free,requiredGiB=minimum))+'\n')
  assert time.time()-began<1200,'Headroom did not recover: '+name;time.sleep(15)
 command=['/usr/bin/time','-l',str(binary),*map(str,arguments)];started=time.time()
 with (root/(name+'.log')).open('x') as f:
  process=subprocess.Popen(command,stdout=f,stderr=subprocess.STDOUT,env=env)
  write(name+'-start.json',dict(command=command,timeWrapperPID=process.pid,startedAtUnix=started));print(name,'started',process.pid,flush=True);code=process.wait()
 status=dict(command=command,returnCode=code,seconds=time.time()-started,freeBytesAfter=shutil.disk_usage(root).free);commands.append(status);write(name+'-status.json',status);print(name,'terminal',code,flush=True);assert code==0,name
try:
 run('pca',['singlecell-h5ad-pca',study/'native-release/original.h5ad','--plan',root/'pca-plan.json','--output',root/'pca'],8)
 pca={}
 for name in ['scores.bin','loadings.bin','model.json','metadata.json','quality.json','plan.json']:
  actual=sha(root/'pca'/name);assert actual==sha(study/'integration-full/pca'/name),name;pca[name]=actual
 write('pca-exact.json',dict(status='passed',files=pca,allSixPriorPayloadsExact=True,receiptSHA256=sha(root/'pca/receipt.json')))
 run('graph-publish',['singlecell-pca-neighbors',root/'pca','--plan',root/'graph-plan.json','--output',root/'graph'],6)
 expected=read(study/'graph/full-output-freeze.json');equal={}
 assert {p.name for p in (root/'graph').iterdir() if p.is_file()}==set(expected)
 for name,identity in expected.items():
  if name=='receipt.json':continue
  actual=sha(root/'graph'/name);assert actual==identity['SHA256'] and (root/'graph'/name).stat().st_size==identity['bytes'],name;equal[name]=identity
 assert sha(root/'graph/input/metadata.json')==pca['metadata.json']
 write('graph-equivalence.json',dict(status='passed',files=equal,originalReceiptSHA256=expected['receipt.json']['SHA256'],newReceiptSHA256=sha(root/'graph/receipt.json'),metadataSHA256=pca['metadata.json'],scope='Every graph payload except its newly runtime-bound receipt matches the original qualified graph exactly. Previous graph/igraph checks remain unmodified; explicit equivalence-aware verification remains required.'))
 # Clustering publication itself reconstructs/validates its entire graph/PCA parent.
 run('clustering-publish',['singlecell-graph-cluster',root/'graph','--plan',root/'clustering-plan.json','--output',root/'clustering'],4)
 write('clustering-output-freeze.json',{p.name:dict(bytes=p.stat().st_size,SHA256=sha(p)) for p in (root/'clustering').iterdir() if p.is_file()})
 run('clustering-verify',['singlecell-graph-cluster-verify',root/'clustering'],4)
 write('native-complete.json',dict(status='passed',commands=commands,binarySHA256=sha(binary),scope='Full current-runtime PCA/graph/clustering publication and replay. Complete independent partition/objective/connectivity and igraph comparison remain separate gates.'))
except Exception as error:
 write('coordinator-failure.json',dict(status='failed',error=repr(error),observedAtUnix=time.time()));raise
