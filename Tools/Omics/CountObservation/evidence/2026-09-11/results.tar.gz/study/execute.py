from pathlib import Path
import json,subprocess,time,os,hashlib
root=Path(__file__).resolve().parent;repo=Path('/Users/home/numivivo-expression-memory-20260911')
state={'status':'running','pid':os.getpid(),'startedUnix':time.time(),'commands':[],'sourceHEAD':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()}
def save():(root/'pipeline.json').write_text(json.dumps(state,indent=2)+'\n')
def run(name,args):
 entry={'name':name,'arguments':args,'startedUnix':time.time()};state['commands'].append(entry);save()
 with (root/(name+'.stdout')).open('w') as out,(root/(name+'.stderr')).open('w') as err:
  p=subprocess.Popen(['/usr/bin/time','-l']+args,stdout=out,stderr=err,cwd=repo);entry['pid']=p.pid;save();entry['exit']=p.wait()
 entry['seconds']=time.time()-entry['startedUnix'];save()
 if entry['exit']:raise RuntimeError(name+' failed; retained output')
try:
 run('tests-final',['bash','Tools/Omics/CountObservation/test.sh',str(root/'build')])
 binary=root/'build/count-observation-check';state['binarySHA256']=hashlib.sha256(binary.read_bytes()).hexdigest();save()
 for name,inputname in [('boundaries','boundary-cases'),('controls','cases'),('controls-repeat','cases')]:
  run(name,[str(binary),str(root/'inputs'/(inputname+'.json')),str(root/(name+'.jsonl'))])
 assert (root/'controls.jsonl').read_bytes()==(root/'controls-repeat.jsonl').read_bytes()
 state['completeControlRepeatByteIdentical']=True;state['status']='native-completed-independent-reference-pending'
except Exception as e:state['status']='failed';state['error']=str(e);raise
finally:state['finishedUnix']=time.time();save()
