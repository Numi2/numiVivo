from pathlib import Path
import gzip,json,hashlib,math
import numpy as np
s=Path(__file__).parent;root=Path('/Users/home/numivivo-joint-fold-fits-20260912');sel=json.loads((s/'selection.json').read_text());report={'scope':'Independent augmented least-squares coefficient verification on the first available gene of every training input shard. Full donor exclusion and model hash checks; not an independent reproduction of every inner-CV loss.','folds':{}}
for tag,info in sel['folds'].items():
 m=np.load(s/(tag+'-model.npz'));lookup={int(v):i for i,v in enumerate(m['featureIndices'])};checked=0;err=0
 for p in sorted((root/tag/tag.split('-')[0]).glob('*input.jsonl.gz')):
  assert hashlib.sha256(p.read_bytes()).hexdigest()==info['inputSHA256'][p.name]
  with gzip.open(p,'rt') as f:
   h=json.loads(next(f));gs=h['groups']
   for l in f:
    a=json.loads(l)
    if not a['groups']:continue
    vals={}
    for g,z in zip(gs,a['groups']):
     total=math.fsum(float(c)*float(v) for c,v in zip(g['cellsPerLibrary'],g['libraryCounts']));vals[(g['donorID'],g['conditionID'])]=math.log1p(math.fsum(z['counts'])*1e6/total)
    donors=m['trainingDonorIDs'].tolist();t=next(k[1] for k in vals if k[1]!='control');x=np.array([vals[(d,'control')] for d in donors]);y=np.array([vals[(d,t)]-vals[(d,'control')] for d in donors]);lam=info['selectedPenalty']
    design=np.column_stack([np.ones(len(x)),x]);aug=np.vstack([design,[0,math.sqrt(lam*(len(x)-1))]]);target=np.append(y,0);coef=np.linalg.lstsq(aug,target,rcond=None)[0];i=lookup[a['featureIndex']]
    actual=np.array([m['responseMean'][i]-m['responseSlope'][i]*m['controlMean'][i],m['responseSlope'][i]])
    np.testing.assert_allclose(actual,coef,rtol=1e-9,atol=1e-10);err=max(err,float(np.max(np.abs(actual-coef))));checked+=1;break
 report['folds'][tag]={'genesChecked':checked,'maximumCoefficientDifference':err};print(tag,checked,err,flush=True)
report['status']='pass';(s/'model-verification.json').write_text(json.dumps(report,indent=2)+'\n')
