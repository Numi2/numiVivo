from pathlib import Path
import gzip,json,hashlib,math,itertools
import numpy as np
s=Path(__file__).parent;source=Path('/Users/home/numivivo-joint-fold-prediction-20260912');selection=json.loads((s/'selection.json').read_text());assert selection['status']=='complete';dest=s/'predictions';dest.mkdir(exist_ok=False)
protocol=json.loads(Path('/Users/home/numivivo-joint-fold-fits-20260912/protocol.json').read_text());roles={r['tag']:r for r in protocol['folds']}
receipt={'selectionSHA256':hashlib.sha256((s/'selection.json').read_bytes()).hexdigest(),'folds':{}}
for tag,info in selection['folds'].items():
 path=s/(tag+'-model.npz');assert hashlib.sha256(path.read_bytes()).hexdigest()==info['modelSHA256'];m=np.load(path);lookup={int(v):i for i,v in enumerate(m['featureIndices'])};assert len(lookup)==len(m['featureIndices'])
 assert sorted(m['trainingDonorIDs'].tolist())==sorted(roles[tag]['trainingDonorIDs']);assert roles[tag]['excludedDonorID'] not in m['trainingDonorIDs'];n=0;bindings={}
 with gzip.open(dest/(tag+'.jsonl.gz'),'wt') as out:
  for p in sorted((source/tag).glob('*input.jsonl.gz')):
   other=p.with_name(p.name.replace('-input.','-output.'))
   for q in [p,other]:bindings[q.name]=hashlib.sha256(q.read_bytes()).hexdigest()
   with gzip.open(p,'rt') as f,gzip.open(other,'rt') as g:
    h=json.loads(next(f));assert h['queryDonorID']==roles[tag]['excludedDonorID'];total=sum(a*b for a,b in zip(h['cellsPerLibrary'],h['libraryCounts']));assert total>0
    for aa,bb in itertools.zip_longest(f,g):
     assert aa is not None and bb is not None;a,b=json.loads(aa),json.loads(bb);assert a['featureIndex']==b['featureIndex']
     if a['status']!='boundedContinuousLikelihood':assert 'prediction' not in b;continue
     j=lookup[a['featureIndex']];assert a['featureID']==str(m['featureIDs'][j]);q=math.log1p(sum(a['counts'])*1e6/total);v=max(0,q+float(m['responseMean'][j])+float(m['responseSlope'][j])*(q-float(m['controlMean'][j])));assert math.isfinite(v)
     out.write(json.dumps({'featureIndex':a['featureIndex'],'featureID':a['featureID'],'predictionLog1pCPM':v})+'\n');n+=1
 receipt['folds'][tag]={'predictedFeatures':n,'predictionSHA256':hashlib.sha256((dest/(tag+'.jsonl.gz')).read_bytes()).hexdigest(),'queryInputsAndPriorOutputSHA256':bindings,'excludedDonorID':roles[tag]['excludedDonorID']};print(tag,n,flush=True)
receipt['status']='complete';(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
