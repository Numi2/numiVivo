from predict import transport
import math
# Constant response on distinct control anchors transfers exactly.
c=[1.,3.];t=[3.,7.];w=[.25,0.,0.,.75]
assert math.isclose(transport(9.,c,t,w),math.log(20.),abs_tol=1e-12)
# Zero response preserves the query, including zero.
for q in [0.,1.,1e6]: assert math.isclose(transport(q,[2.],[2.],[1.]),math.log1p(q),abs_tol=1e-12)
# Negative transported rates clip at zero per atom.
assert transport(0.,[9.],[0.],[1.])==0
# Mixture is averaged in CPM rather than log space.
assert math.isclose(transport(1.,[1.],[1.,9.],[.5,.5]),math.log(6.),abs_tol=1e-12)
for args in [(-1,[1],[1],[1]),(0,[1],[1],[.5]),(0,[1],[1],[float('nan')]),(0,[],[1],[])]:
 try:transport(*args)
 except ValueError:pass
 else:raise AssertionError(args)
print('PASS: response identity, zero response, clipping, CPM expectation, invalid inputs')
