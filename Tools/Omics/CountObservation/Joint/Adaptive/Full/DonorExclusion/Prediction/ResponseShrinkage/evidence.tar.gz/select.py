from pathlib import Path
import gzip,json,hashlib,math,time
import numpy as np
S=Path(__file__).parent;ROOT=Path('/Users/home/numivivo-joint-fold-fits-20260912')
PENALTIES=[0,0.01,0.1,1,10,100,None]
def fit(x,d,penalty):
 xm=x.mean(axis=1);dm=d.mean(axis=1);xc=x-xm[:,None]
 den=(xc*xc).sum(axis=1)
 b=np.zeros_like(dm) if penalty is None else np.divide((xc*(d-dm[:,None])).sum(axis=1),den+penalty*(x.shape[1]-1),out=np.zeros_like(dm),where=den+penalty*(x.shape[1]-1)>0)
 return xm,dm,b
result={'scope':'Development training-only selection. Inner validation uses observed pseudobulk CPM, not NB fits. Feature availability was established by outer training count/calibration export; this is not a fully nested dispersion qualification. No outer query-treated outcomes are read.','folds':{}}
for tag in [f'Kang-{i:02}' for i in range(8)]+[f'HIRISA-{i:02}' for i in range(5)]:
 rows=[];ids=[];indices=[];bindings={};donors=None;excluded=0
 for p in sorted((ROOT/tag/tag.split('-')[0]).glob('*input.jsonl.gz')):
  bindings[p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
  with gzip.open(p,'rt') as f:
   h=json.loads(next(f));groups=h['groups'];ds=sorted(set(g['donorID'] for g in groups))
   if donors is None:donors=ds
   assert donors==ds
   lookup={(g['donorID'],g['conditionID']):i for i,g in enumerate(groups)}
   treated=sorted(set(g['conditionID'] for g in groups)-{'control'});assert len(treated)==1
   order=[lookup[(d,c)] for d in donors for c in ['control',treated[0]]]
   totals=[sum(a*b for a,b in zip(g['cellsPerLibrary'],g['libraryCounts'])) for g in groups];assert min(totals)>0
   for line in f:
    z=json.loads(line)
    if not z['groups']:excluded+=1;continue
    assert len(z['groups'])==len(groups)
    rates=[math.log1p(sum(z['groups'][i]['counts'])*1e6/totals[i]) for i in order]
    rows.append(rates);ids.append(z['featureID']);indices.append(z['featureIndex'])
 a=np.asarray(rows,dtype='f8');x=a[:,::2];y=a[:,1::2];d=y-x
 errors=[]
 for lam in PENALTIES:
  terms=[]
  for j in range(len(donors)):
   keep=[i for i in range(len(donors)) if i!=j];xm,dm,b=fit(x[:,keep],d[:,keep],lam)
   pred=np.maximum(0,x[:,j]+dm+b*(x[:,j]-xm));terms.append(float(np.sum((pred-y[:,j])**2)))
  errors.append(sum(terms)/(len(rows)*len(donors)))
 # Ties prefer stronger regularization, including the mean-response limit.
 best=min(range(len(errors)),key=lambda i:(errors[i],-i));xm,dm,b=fit(x,d,PENALTIES[best])
 out=S/(tag+'-model.npz');np.savez_compressed(out,featureIndices=np.asarray(indices),featureIDs=np.asarray(ids),trainingDonorIDs=np.asarray(donors),controlMean=xm,responseMean=dm,responseSlope=b)
 result['folds'][tag]={'trainingDonors':donors,'features':len(rows),'unavailableRows':excluded,'penalties':PENALTIES,'innerDonorMSE':errors,'selectedPenalty':PENALTIES[best],'modelSHA256':hashlib.sha256(out.read_bytes()).hexdigest(),'inputSHA256':bindings}
 (S/'selection.json').write_text(json.dumps(result,indent=2)+'\n');print(tag,len(rows),PENALTIES[best],errors,flush=True)
result['status']='complete';(S/'selection.json').write_text(json.dumps(result,indent=2)+'\n')
