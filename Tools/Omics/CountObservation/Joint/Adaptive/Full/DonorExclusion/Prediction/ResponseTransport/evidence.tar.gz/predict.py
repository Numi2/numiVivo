from pathlib import Path
import gzip, json, hashlib, math, itertools, sys

def transport(q, c, t, weights):
    if not math.isfinite(q) or q < 0 or not c or not t or len(weights)!=len(c)*len(t):
        raise ValueError('invalid query or support shape')
    if any(not math.isfinite(v) or v<0 for v in c+t+weights) or not math.isclose(math.fsum(weights),1,rel_tol=0,abs_tol=1e-10):
        raise ValueError('invalid rates or probabilities')
    # E[CPM] after clipping each transported atom at zero, then log1p.
    # This is a transport candidate, not the original model posterior.
    values=[w*math.expm1(max(0,math.log1p(q)+math.log1p(t[i%len(t)])-math.log1p(c[i//len(t)]))) for i,w in enumerate(weights) if w>0]
    value=math.log1p(math.fsum(values))
    if not math.isfinite(value): raise ValueError('nonfinite transported prediction')
    return value

def run(source, dest):
    dest.mkdir(exist_ok=False)
    receipt={'method':'conditional-log1p-response-transport-v1','scope':'Post-hoc development candidate; no query-treated data read during prediction; not the original Bayesian posterior or calibrated uncertainty.','folds':{}}
    for tag in [f'Kang-{i:02}' for i in range(8)]+[f'HIRISA-{i:02}' for i in range(5)]:
        bindings={};seen=set(); n=0
        with gzip.open(dest/(tag+'.jsonl.gz'),'wt') as output:
            for p in sorted((source/tag).glob('*input.jsonl.gz')):
                other=p.with_name(p.name.replace('-input.','-output.'))
                for a in (p,other):bindings[a.name]=hashlib.sha256(a.read_bytes()).hexdigest()
                with gzip.open(p,'rt') as f, gzip.open(other,'rt') as g:
                    header=json.loads(next(f)); assert len(header['cellsPerLibrary'])==len(header['libraryCounts'])
                    total=sum(a*b for a,b in zip(header['cellsPerLibrary'],header['libraryCounts']));assert total>0
                    for a,b in itertools.zip_longest(f,g):
                        assert a is not None and b is not None
                        x,y=json.loads(a),json.loads(b);assert x['featureIndex']==y['featureIndex'] and x['featureID']==y['featureID']
                        idx=x['featureIndex'];assert idx not in seen;seen.add(idx)
                        if x['status']!='boundedContinuousLikelihood':assert 'prediction' not in y;continue
                        m=x['model']['model'];pred=y['prediction'];assert header['queryDonorID'] not in m['trainingDonorIDs']
                        q=sum(x['counts'])*1e6/total
                        value=transport(q,m['controlRatesCPM'],m['treatedRatesCPM'],pred['probabilities'])
                        output.write(json.dumps({'featureIndex':idx,'featureID':x['featureID'],'predictionLog1pCPM':value},allow_nan=False)+'\n');n+=1
        assert n>0
        receipt['folds'][tag]={'sourceFeatures':len(seen),'predictedFeatures':n,'inputAndPosteriorSHA256':bindings,'predictionSHA256':hashlib.sha256((dest/(tag+'.jsonl.gz')).read_bytes()).hexdigest()}
        (dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n'); print(tag,n,flush=True)
    receipt['status']='complete';(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
if __name__=='__main__':run(Path(sys.argv[1]),Path(sys.argv[2]))
