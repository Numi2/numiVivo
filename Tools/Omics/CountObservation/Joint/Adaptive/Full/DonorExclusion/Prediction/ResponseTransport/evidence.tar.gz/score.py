from pathlib import Path
import json,gzip,math,hashlib
root=Path(__file__).parent; source=Path('/Users/home/numivivo-joint-fold-prediction-20260912'); pred=root/'predictions'
receipt=json.loads((pred/'receipt.json').read_text());assert receipt['status']=='complete'
result={'scope':'Post-hoc development evaluation of one frozen response-transport candidate. Not independent validation; original scores unchanged.','folds':{},'datasets':{}}
for tag,info in receipt['folds'].items():
 p=pred/(tag+'.jsonl.gz');assert hashlib.sha256(p.read_bytes()).hexdigest()==info['predictionSHA256']
 rows=[json.loads(l) for l in gzip.open(p,'rt')]; values={r['featureIndex']:r for r in rows};assert len(values)==len(rows)==info['predictedFeatures']
 score=source/tag/'scores-by-gene.json.gz'; report=json.loads((source/tag/'scores.json').read_text());assert hashlib.sha256(score.read_bytes()).hexdigest()==report['scoresSHA256']
 original=[r for r in json.loads(gzip.decompress(score.read_bytes())) if r['status']=='conditionalPrediction'];assert len(original)==report['scoredGenes'];assert set(values)=={r['featureIndex'] for r in original}
 errors={k:[] for k in ['candidate','originalJoint','trainingMean','noChange']}
 for r in original:
  v=values[r['featureIndex']];assert v['featureID']==r['featureID']
  for k,value in [('candidate',v['predictionLog1pCPM']),('originalJoint',r['predictionLog1pCPM']),('trainingMean',r['trainingMeanResponseLog1pCPM']),('noChange',r['controlLog1pCPM'])]:errors[k].append((value-r['observedLog1pCPM'])**2)
 sse={k:math.fsum(v) for k,v in errors.items()};n=len(rows)
 result['folds'][tag]={'genes':n,'sse':sse,'rmse':{k:math.sqrt(v/n) for k,v in sse.items()},'originalScoresSHA256':report['scoresSHA256'],'candidateSHA256':info['predictionSHA256']}
for dataset in ['Kang','HIRISA']:
 folds=[v for k,v in result['folds'].items() if k.startswith(dataset+'-')];n=sum(v['genes'] for v in folds);rmse={k:math.sqrt(math.fsum(v['sse'][k] for v in folds)/n) for k in folds[0]['sse']}
 result['datasets'][dataset]={'genes':n,'rmse':rmse,'gainOverMeanPercent':100*(1-rmse['candidate']/rmse['trainingMean']),'gainOverNoChangePercent':100*(1-rmse['candidate']/rmse['noChange']),'donorsWorseThanMean':[k for k,v in result['folds'].items() if k.startswith(dataset+'-') and v['rmse']['candidate']>v['rmse']['trainingMean']]}
result['status']='complete-development-evaluation';(root/'scores.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result['datasets'],indent=2))
