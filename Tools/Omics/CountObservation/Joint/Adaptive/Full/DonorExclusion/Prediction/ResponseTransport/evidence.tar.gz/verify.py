from pathlib import Path
import json,gzip,math,hashlib,itertools
r=Path(__file__).parent;s=Path('/Users/home/numivivo-joint-fold-prediction-20260912');receipt=json.loads((r/'predictions/receipt.json').read_text());assert receipt['status']=='complete'
out={'status':'running','folds':{}}
for tag,info in receipt['folds'].items():
 vpath=s/tag/'verification.json';v=json.loads(vpath.read_text());report=json.loads((s/tag/'scores.json').read_text());assert hashlib.sha256(vpath.read_bytes()).hexdigest()==report['verifiedPredictionManifestSHA256'];assert v['status']=='passed-control-only-predictions' and not v['errors']
 expected={}
 for key,b in v['shardBindings'].items():
  for side in ['input','output']:expected[key+'-'+side+'.jsonl.gz']=b[side+'SHA256']
 assert expected==info['inputAndPosteriorSHA256']
 rows={x['featureIndex']:x for x in map(json.loads,gzip.open(r/'predictions'/(tag+'.jsonl.gz'),'rt'))};maximum=0;n=0
 for p in sorted((s/tag).glob('*input.jsonl.gz')):
  with gzip.open(p,'rt') as f,gzip.open(p.with_name(p.name.replace('-input.','-output.')),'rt') as g:
   h=json.loads(next(f));total=sum(a*b for a,b in zip(h['cellsPerLibrary'],h['libraryCounts']))
   for a,b in zip(f,g):
    x,y=json.loads(a),json.loads(b)
    if 'prediction' not in y:continue
    m=x['model']['model'];q=sum(x['counts'])*1e6/total;nt=len(m['treatedRatesCPM'])
    # Independent rate-ratio expression, avoiding exp/log atom transport.
    ref=math.log1p(math.fsum(w*max(0,(1+q)*(1+m['treatedRatesCPM'][i%nt])/(1+m['controlRatesCPM'][i//nt])-1) for i,w in enumerate(y['prediction']['probabilities']) if w>0))
    actual=rows[x['featureIndex']]['predictionLog1pCPM'];err=abs(actual-ref)/max(1,abs(ref));maximum=max(maximum,err);assert err<1e-10;n+=1
 assert n==len(rows)==report['scoredGenes'];out['folds'][tag]={'compared':n,'maximumScaledError':maximum,'frozenSourceBindingsMatched':True};print(tag,n,maximum,flush=True)
out['status']='passed';(r/'verification.json').write_text(json.dumps(out,indent=2)+'\n')
