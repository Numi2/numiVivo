from pathlib import Path
import json,gzip,hashlib,math
import numpy as np
s=Path(__file__).parent;source=Path('/Users/home/numivivo-joint-fold-prediction-20260912');r=json.loads((s/'predictions/receipt.json').read_text());report={'scope':'All predictions independently recomputed as affine log-CPM response with nonnegative clipping; exact query-only file bindings checked.','folds':{}}
for tag,info in r['folds'].items():
 m=np.load(s/(tag+'-model.npz'));model={int(i):(str(f),float(c),float(d),float(b)) for i,f,c,d,b in zip(m['featureIndices'],m['featureIDs'],m['controlMean'],m['responseMean'],m['responseSlope'])}
 p=s/'predictions'/(tag+'.jsonl.gz');assert hashlib.sha256(p.read_bytes()).hexdigest()==info['predictionSHA256'];values={v['featureIndex']:v for v in map(json.loads,gzip.open(p,'rt'))};assert len(values)==info['predictedFeatures'];seen=set();err=0
 for p in sorted((source/tag).glob('*input.jsonl.gz')):
  assert hashlib.sha256(p.read_bytes()).hexdigest()==info['queryInputsAndPriorOutputSHA256'][p.name]
  with gzip.open(p,'rt') as f:
   h=json.loads(next(f));assert h['queryDonorID'] not in m['trainingDonorIDs'];total=math.fsum(float(a)*float(b) for a,b in zip(h['cellsPerLibrary'],h['libraryCounts']))
   for line in f:
    x=json.loads(line)
    if x['status']!='boundedContinuousLikelihood':assert x['featureIndex'] not in values;continue
    i=x['featureIndex'];assert i not in seen;seen.add(i);fid,c,d,b=model[i];assert fid==x['featureID']==values[i]['featureID'];q=math.log(1+math.fsum(x['counts'])/(total/1e6));expected=max(0,(1+b)*q+(d-b*c));actual=values[i]['predictionLog1pCPM'];assert math.isclose(expected,actual,rel_tol=1e-10,abs_tol=1e-10);err=max(err,abs(expected-actual))
 assert seen==set(values);report['folds'][tag]={'predictions':len(seen),'maximumAbsoluteDifference':err};print(tag,len(seen),err,flush=True)
report['status']='pass';(s/'prediction-verification.json').write_text(json.dumps(report,indent=2)+'\n')
