import Foundation
struct Row: Decodable { let indices: [Int]; let counts: [UInt64] }
struct Input: Decodable { let features: [String]; let rows: [Row] }
let model = try JSONDecoder().decode(VivoCellTypistReferenceModel.self, from: Data(contentsOf: URL(fileURLWithPath: CommandLine.arguments[1])))
let input = try JSONDecoder().decode(Input.self, from: Data(contentsOf: URL(fileURLWithPath: CommandLine.arguments[2])))
let predictor = try VivoCellTypistReference(model: model, sourceFeatures: input.features)
var outputs: [[String: Any]] = []
for row in input.rows {
 let r = try predictor.predict(indices: row.indices, counts: row.counts)
 outputs.append(["label": r.label, "decisions": r.decisions, "probabilities": r.probabilities])
}
let data = try JSONSerialization.data(withJSONObject: outputs, options: [.sortedKeys])
try data.write(to: URL(fileURLWithPath: CommandLine.arguments[3]))
