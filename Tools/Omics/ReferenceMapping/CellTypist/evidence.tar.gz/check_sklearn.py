from pathlib import Path
import json,numpy as np,sklearn
from sklearn.linear_model import LogisticRegression
from scipy.special import expit
r=Path(__file__).parent
m=json.loads((r/'model.json').read_text());inp=json.loads((r/'real-input.json').read_text());out=json.loads((r/'real-output.json').read_text())
lookup={g:i for i,g in enumerate(inp['features'])};ix=[lookup[g] for g in m['features']]
x=np.zeros((len(inp['rows']),len(ix)))
for i,row in enumerate(inp['rows']):
 values=dict(zip(row['indices'],row['counts']));total=sum(row['counts'])
 x[i]=[np.log1p(values.get(j,0)/total*10000) if total else 0 for j in ix]
x=np.minimum((x-m['means'])/m['scales'],10)
clf=LogisticRegression();clf.classes_=np.array(m['classes']);clf.coef_=np.array(m['coefficients']);clf.intercept_=np.array(m['intercepts']);clf.n_features_in_=len(ix)
decision=clf.decision_function(x);labels=clf.predict(x)
actual=np.array([a['decisions'] for a in out]);prob=np.array([a['probabilities'] for a in out])
assert np.allclose(actual,decision,rtol=0,atol=1e-10)
assert np.allclose(prob,expit(decision),rtol=0,atol=1e-12)
assert labels.tolist()==[a['label'] for a in out]
result={'status':'passed','cells':len(x),'sklearn':sklearn.__version__,'maximumDecisionError':float(np.max(abs(actual-decision))),'maximumProbabilityError':float(np.max(abs(prob-expit(decision)))),'labelsEqual':True,'scope':'scikit-learn decision_function and predict plus CellTypist independent sigmoid; no retraining or full CellTypist pipeline'}
(r/'sklearn-check.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
