from pathlib import Path
import json, numpy as np, subprocess
from scipy.special import expit
r=Path(__file__).parent
m=json.loads((r/'model.json').read_text());g=len(m['features'])
features=m['features']+['__non_model_gene__']
rng=np.random.default_rng(617)
rows=[{'indices':[],'counts':[]},{'indices':[0,g],'counts':[1,1000000]}]
for _ in range(30):
 idx=np.sort(rng.choice(g+1,size=100,replace=False))
 rows.append({'indices':idx.tolist(),'counts':rng.integers(1,10000,size=100).tolist()})
(r/'checks-input.json').write_text(json.dumps({'features':features,'rows':rows}))
subprocess.run([str(r/'native'),str(r/'model.json'),str(r/'checks-input.json'),str(r/'checks-output.json')],check=True)
out=json.loads((r/'checks-output.json').read_text())
x=np.zeros((len(rows),g+1))
for i,row in enumerate(rows): x[i,row['indices']]=row['counts']
tot=x.sum(axis=1);norm=np.log1p(x[:,:g]*np.divide(10000,tot,out=np.zeros_like(tot),where=tot>0)[:,None])
scaled=np.minimum((norm-np.array(m['means']))/m['scales'],10)
expected=scaled@np.array(m['coefficients']).T+m['intercepts']
actual=np.array([o['decisions'] for o in out]);probs=np.array([o['probabilities'] for o in out])
assert np.allclose(actual,expected,rtol=0,atol=1e-10)
assert np.allclose(probs,expit(expected),rtol=0,atol=1e-12)
assert [o['label'] for o in out]==[m['classes'][j] for j in expected.argmax(axis=1)]
result={'status':'passed-numerical-software-check','rows':len(rows),'maximumDecisionError':float(np.max(np.abs(actual-expected))),'maximumProbabilityError':float(np.max(np.abs(probs-expit(expected)))),'realCellValidation':False}
(r/'checks.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
