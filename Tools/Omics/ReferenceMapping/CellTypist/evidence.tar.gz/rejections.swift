import Foundation
@main struct Checks {
 static func main() throws {
 let data = try Data(contentsOf: URL(fileURLWithPath: CommandLine.arguments[1]))
 let m = try JSONDecoder().decode(VivoCellTypistReferenceModel.self, from: data)
 let p = try VivoCellTypistReference(model:m, sourceFeatures:m.features)
 var passed = 0
 func reject(_ block: () throws -> Void) throws {
  do { try block() } catch is VivoCellTypistReferenceError { passed += 1; return }
  throw NSError(domain:"expected rejection",code:1)
 }
 try reject { _ = try p.predict(indices:[-1],counts:[1]) }
 try reject { _ = try p.predict(indices:[m.features.count],counts:[1]) }
 try reject { _ = try p.predict(indices:[0,0],counts:[1,1]) }
 try reject { _ = try p.predict(indices:[1,0],counts:[1,1]) }
 try reject { _ = try p.predict(indices:[0],counts:[]) }
 try reject { _ = try p.predict(indices:[0],counts:[0]) }
 try reject { _ = try p.predict(indices:[0,1],counts:[UInt64.max,1]) }
 try reject { _ = try VivoCellTypistReference(model:m,sourceFeatures:Array(m.features.dropLast())) }
 try reject { _ = try VivoCellTypistReference(model:m,sourceFeatures:m.features+[m.features[0]]) }
 for key in ["scales","coefficients","intercepts","multiClass","sourceSHA256"] {
  var obj = try JSONSerialization.jsonObject(with:data) as! [String:Any]
  switch key {
  case "scales": obj[key] = Array(repeating:0.0,count:m.features.count)
  case "coefficients": obj[key] = [[Double]]()
  case "intercepts": obj[key] = [Double]()
  case "multiClass": obj[key] = "multinomial"
  default: obj[key] = "unknown"
  }
  let bad = try JSONDecoder().decode(VivoCellTypistReferenceModel.self,from:JSONSerialization.data(withJSONObject:obj))
  try reject { _ = try VivoCellTypistReference(model:bad,sourceFeatures:m.features) }
 }
 print("{\"status\":\"passed\",\"rejections\":\(passed)}")
 }
}
