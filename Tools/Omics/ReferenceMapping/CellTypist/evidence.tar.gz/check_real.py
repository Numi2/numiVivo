from pathlib import Path
import os,sys,json,hashlib,numpy as np,subprocess
from scipy.special import expit
r=Path(__file__).parent
source=Path('/Users/home/numivivo-parse-bcell-counts-20260912')
os.environ['NUMIVIVO_PARSE_STUDY']=str(source);sys.path.insert(0,str(source))
import run_counts
run=next(x for x in run_counts.RUNS if x['sample'].endswith('_PBS'))
_,data,bulk,totals,qc=run_counts.one(run)
records=np.frombuffer(data,dtype='<u8').reshape(-1,2)
row=(records[:,0]&np.uint64(0xffffffff)).astype(int);col=(records[:,0]>>np.uint64(32)).astype(int)
plan=json.loads((source/'donor-plans/Donor8/plan.json').read_text())
features=[f['id'] for f in plan['metadata']['features']]
rows=[]
for i in range(run['lo'],run['hi']):
 k=row==i;rows.append({'indices':col[k].tolist(),'counts':records[k,1].tolist()})
(r/'real-input.json').write_text(json.dumps({'features':features,'rows':rows}))
(r/'real-source.json').write_text(json.dumps({'run':run,'qc':qc,'canonicalStreamSHA256':hashlib.sha256(data).hexdigest(),'selection':'first source run with PBS sample in frozen parent order; all its rows'},indent=2))
subprocess.run([str(r/'native'),str(r/'model.json'),str(r/'real-input.json'),str(r/'real-output.json')],check=True)
m=json.loads((r/'model.json').read_text());lookup={s:i for i,s in enumerate(features)};ix=[lookup[s] for s in m['features']]
expected=[]
for rr in rows:
 x=np.zeros(len(features));x[rr['indices']]=rr['counts'];total=x.sum()
 z=np.log1p(x[ix]*(10000/total if total else 0))
 z=np.minimum((z-m['means'])/m['scales'],10)
 expected.append(np.array(m['coefficients'])@z+m['intercepts'])
expected=np.array(expected);out=json.loads((r/'real-output.json').read_text());actual=np.array([x['decisions'] for x in out])
assert np.allclose(actual,expected,atol=1e-10,rtol=0)
assert np.allclose([x['probabilities'] for x in out],expit(expected),atol=1e-12,rtol=0)
assert [x['label'] for x in out]==[m['classes'][i] for i in expected.argmax(axis=1)]
result={'status':'passed-real-source-window-numerical-comparison','cells':len(rows),'sample':run['sample'],'run':run['run'],'maximumDecisionError':float(np.max(np.abs(actual-expected))),'biologicalAccuracyQualified':False,'fullCohort':False}
(r/'real-check.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
