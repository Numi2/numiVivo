from pathlib import Path
import pickle, io, json, hashlib
import numpy as np
class State:
    pass
class Reader(pickle.Unpickler):
    def find_class(self,module,name):
        if (module,name) in {('sklearn.linear_model._logistic','LogisticRegression'),('sklearn.preprocessing._data','StandardScaler')}:
            return State
        allowed={('numpy','ndarray'):np.ndarray,('numpy','dtype'):np.dtype,('numpy._core.multiarray','_reconstruct'):np._core.multiarray._reconstruct,('numpy._core.multiarray','scalar'):np._core.multiarray.scalar}
        if (module,name) not in allowed: raise ValueError((module,name))
        return allowed[module,name]
r=Path(__file__).parent
b=(r/'aifi_parse_pbmc_celltypist_model_AIFI_L1.pkl').read_bytes()
assert hashlib.sha256(b).hexdigest()=='959938f78eb6e0394a9da0d31a65d57316fcf1be0df9cdde3222cea3842f9a63'
d=Reader(io.BytesIO(b)).load()
m,s=d['Model'],d['Scaler_']
out={'sourceSHA256':hashlib.sha256(b).hexdigest(),'classes':m.classes_.tolist(),'features':m.features.tolist(),'coefficients':m.coef_.tolist(),'intercepts':m.intercept_.tolist(),'means':s.mean_.tolist(),'scales':s.scale_.tolist(),'withMean':bool(s.with_mean),'withStd':bool(s.with_std),'multiClass':m.multi_class,'sklearnVersion':m.__dict__.get('_sklearn_version'),'description':d['description']}
assert len(out['features'])==m.coef_.shape[1] and m.coef_.shape[0]==len(out['classes'])
assert len(set(out['features']))==len(out['features'])
assert all(np.isfinite(x).all() for x in [m.coef_,m.intercept_,s.mean_,s.scale_]) and (s.scale_>0).all()
(r/'model.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['features','coefficients','intercepts','means','scales']},indent=2))
print('features',len(out['features']))
