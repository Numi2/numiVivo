set -e
/Users/n/numivivo-integration-reference-py/bin/python /Users/n/numivivo-rna-variance-profile-20260912/rna-preservation/score.py > /Users/n/numivivo-rna-variance-profile-20260912/rna-preservation/score.log 2>&1
/Users/n/numivivo-integration-reference-py/bin/python /Users/n/numivivo-rna-variance-profile-20260912/atac-preservation/score.py > /Users/n/numivivo-rna-variance-profile-20260912/atac-preservation/score.log 2>&1
touch /Users/n/numivivo-rna-variance-profile-20260912/preservation-finished
