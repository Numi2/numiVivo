from pathlib import Path
import json,hashlib
import numpy as np
from scipy import sparse
s=Path(__file__).parent;inp=s
xs=[np.array(json.loads((inp/(n+'-scores.json')).read_text())) for n in ['rna','atac']]
gs=[json.loads((inp/(n+'-graph.json')).read_text()) for n in ['rna','atac']]
n=len(xs[0]);k=15
indices=[np.array(g['neighborIndices']).reshape(n,k) for g in gs]
ds=[np.array(g['neighborDistances']).reshape(n,k) for g in gs]
from scipy.spatial.distance import cdist
for x,ii,dd in zip(xs,indices,ds):
 d=cdist(x,x)
 for i in range(n):
  order=np.lexsort((np.arange(n),d[i]));order=order[order!=i][:k-1]
  assert np.array_equal(ii[i],np.r_[i,order])
  np.testing.assert_allclose(dd[i],np.r_[0,d[i,order]],rtol=0,atol=1e-10)
widths=[];within=[];cross=[];scores=[]
for m in range(2):
 x=xs[m];ii=indices[m];near=ds[m][:,1]
 membership=sparse.csr_matrix((np.ones(n*k),ii.ravel(),np.arange(n+1)*k),shape=(n,n))
 snn=(membership@membership.T).tocsr()
 width=[]
 for i in range(n):
  sl=slice(snn.indptr[i],snn.indptr[i+1]);shared=snn.data[sl];neighbors=snn.indices[sl]
  take=min(k,len(shared));cutoff=np.partition(shared,take-1)[take-1]
  candidates=neighbors[shared<=cutoff]
  distances=np.maximum(0,np.linalg.norm(x[candidates]-x[i],axis=1)-near[i])
  width.append(np.sort(distances)[-take:].mean())
 width=np.array(width)
 wd=np.maximum(0,np.linalg.norm(x-x[ii[:,1:]].mean(axis=1),axis=1)-near)
 cd=np.maximum(0,np.linalg.norm(x-x[indices[1-m][:,1:]].mean(axis=1),axis=1)-near)
 score=np.clip(np.exp(-wd/width)/(np.exp(-cd/width)+1e-4),0,200)
 widths.append(width);within.append(wd);cross.append(cd);scores.append(score)
scores=np.array(scores);weights=np.exp(scores)/np.exp(scores).sum(axis=0)
reference=dict(bandwidths=widths,withinDistances=within,crossDistances=cross,scores=scores,weights=weights)
native=json.loads((s/'weighted.json').read_text())['modalityWeights'];assert native['cells']==gs[0]['cells']==gs[1]['cells']
metrics={}
for name,values in reference.items():
 err=float(np.max(abs(np.array(native[name])-values)));metrics[name]=err
 np.testing.assert_allclose(native[name],values,rtol=0,atol=1e-10)
np.savez_compressed(s/'reference.npz',**reference)
report=dict(status='PASS-independent-formula-comparison',cells=n,maximumAbsoluteErrors=metrics,rnaWeightQuantiles=np.quantile(weights[0],[0,.25,.5,.75,1]).tolist(),rnaMeanWeight=float(weights[0].mean()),biologicalValidation=False,seuratEndToEndExecuted=False)
(s/'comparison.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
