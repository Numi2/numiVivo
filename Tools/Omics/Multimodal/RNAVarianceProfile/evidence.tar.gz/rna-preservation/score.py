from pathlib import Path
import json,hashlib,importlib.metadata
import numpy as np
import h5py
from scipy import sparse
s=Path('/Users/n/numivivo-rna-variance-profile-20260912/rna-preservation');p=json.loads((s/'protocol.json').read_text());b=Path('/Users/n/numivivo-paired-workflow-20260912/bundle')
for name,h in p['sources'].items():
 with open(name,'rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==h
a=json.loads((b/'result.json').read_text());graphs={name:json.loads((Path('/Users/n/numivivo-rna-variance-profile-20260912')/(name+'-graph.json')).read_text()) for name in ['rna','atac','joint']};graphs['weighted']=json.loads(Path('/Users/n/numivivo-rna-variance-profile-20260912/weighted.json').read_text())['graph']
with h5py.File(b/'original.h5') as f:
 g=f['matrix'];x=sparse.csc_matrix((g['data'][:],g['indices'][:],g['indptr'][:]),shape=tuple(g['shape'][:])).T.tocsr()
 mask=g['features/feature_type'].asstr()[:]=='Gene Expression';ids=g['features/id'].asstr()[:][mask];barcodes=g['barcodes'].asstr()[:]
 x=x[:,mask].astype(np.float64)
assert x.shape==(2711,36601) and x.nnz==5218473 and x.sum()==11786194
assert ids.tolist()==[f['id'] for f in a['rnaMetadata']['features']]
assert barcodes.tolist()==[c['barcode'] for c in a['rna']['cells']]
n,g=x.shape;totals=np.asarray(x.sum(axis=1)).ravel();assert np.all(totals>0)
x.data=np.log1p(x.data/np.repeat(totals,np.diff(x.indptr))*10000)
detected=np.bincount(x.indices,minlength=g)
sums=np.asarray(x.sum(axis=0)).ravel();sums2=np.asarray(x.multiply(x).sum(axis=0)).ravel()
sst=np.maximum(0,sums2-sums*sums/n)
outside=np.setdiff1d(np.arange(g),a['rna']['selectedFeatureIndices']);assert len(outside)==34601
operators={};neighbors={}
for name,graph in graphs.items():
 assert graph['cells']==a['rna']['cells']
 ii=np.array(graph['neighborIndices']).reshape(n,15);assert np.array_equal(ii[:,0],np.arange(n))
 assert all(len(set(row))==15 for row in ii)
 neighbors[name]=ii[:,1:]
 operators['knn/'+name]=sparse.csr_matrix((np.full(n*14,1/14),ii[:,1:].ravel(),np.arange(n+1)*14),shape=(n,n))
 mat=sparse.csr_matrix((graph['weights'],graph['columnIndices'],graph['rowOffsets']),shape=(n,n))
 assert not np.any(mat.diagonal()) and np.all(mat.data>0)
 rows=np.asarray(mat.sum(axis=1)).ravel();assert np.all(rows>0)
 mat.data/=np.repeat(rows,np.diff(mat.indptr));operators['fuzzy/'+name]=mat
errors={name:np.zeros(len(outside)) for name in operators};identity_error=0.
for start in range(0,len(outside),128):
 end=min(start+128,len(outside));columns=outside[start:end];target=x[:,columns].tocsr()
 for name,op in operators.items():
  prediction=(op@target).tocsr();difference=prediction-target
  direct=np.asarray(difference.multiply(difference).sum(axis=0)).ravel()
  algebra=np.asarray(prediction.multiply(prediction).sum(axis=0)).ravel()-2*np.asarray(prediction.multiply(target).sum(axis=0)).ravel()+sums2[columns]
  identity_error=max(identity_error,float(np.max(abs(direct-algebra))))
  np.testing.assert_allclose(direct,algebra,rtol=1e-10,atol=1e-9)
  errors[name][start:end]=direct
 if start%4096==0:print('scored genes',end,flush=True)
scalar_error=0.
for col in p['scalarCheckGeneIndices']:
 local=int(np.searchsorted(outside,col));y=x[:,col].toarray().ravel()
 for name,ii in neighbors.items():
  predicted=np.array([sum(float(y[j]) for j in row)/14 for row in ii])
  value=sum(float(z*z) for z in (predicted-y))
  scalar_error=max(scalar_error,abs(value-errors['knn/'+name][local]))
  np.testing.assert_allclose(value,errors['knn/'+name][local],rtol=1e-10,atol=1e-9)
support=detected[outside];variance=sst[outside];eligible=(support>=20)&(variance>0)
strata={'detected1to19':(support>0)&(support<20),'detected20to99':(support>=20)&(support<100),'detected100plus':support>=100}
summary={}
for name,values in errors.items():
 summary[name]=dict(aggregateSSE=float(values.sum()),macroVarianceNormalizedMSE=float(np.mean(values[eligible]/variance[eligible])),strataSSE={key:float(values[mask].sum()) for key,mask in strata.items()})
gates={}
for mode in ['knn','fuzzy']:
 w=summary[mode+'/weighted'];r=summary[mode+'/rna']
 checks=dict(aggregate=w['aggregateSSE']<=r['aggregateSSE'],macro=w['macroVarianceNormalizedMSE']<=r['macroVarianceNormalizedMSE'])
 for key,mask in strata.items():
  if np.any(mask):checks[key]=w['strataSSE'][key]<=r['strataSSE'][key]
 gates[mode]=dict(passed=all(checks.values()),checks=checks,aggregateChangePercent=100*(w['aggregateSSE']/r['aggregateSSE']-1),macroChangePercent=100*(w['macroVarianceNormalizedMSE']/r['macroVarianceNormalizedMSE']-1))
np.savez_compressed(s/'per-gene.npz',featureIndices=outside,featureIDs=ids[outside].astype(str),detectedCells=support,sst=variance,nullSSE=variance*(n/(n-1))**2,**errors)
report=dict(status='COMPLETE-diagnostic-not-independent-biological-validation',promotionGatePassed=all(z['passed'] for z in gates.values()),cells=n,genes=len(outside),zeroGenes=int(sum(support==0)),macroEligibleGenes=int(sum(eligible)),strataCounts={k:int(sum(v)) for k,v in strata.items()},summary=summary,gates=gates,arithmeticChecks=dict(maxAlgebraDifference=identity_error,maxScalarDifference=scalar_error,scalarGenes=len(p['scalarCheckGeneIndices'])),nullAggregateSSE=float(sum(variance)*(n/(n-1))**2),versions={k:importlib.metadata.version(k) for k in ['numpy','scipy','h5py']},limitations=p['limitations'])
(s/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
