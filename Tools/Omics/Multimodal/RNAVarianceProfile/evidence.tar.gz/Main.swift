import Foundation
@testable import NumiVivoKit
struct Input: Decodable {
 let rna: VivoSingleCellReductionResult
 let atac: VivoAccessibilityLSIResult
}
@main struct Main {
 static func main() throws {
  let s=URL(fileURLWithPath:"/Users/n/numivivo-rna-variance-profile-20260912")
  let input=URL(fileURLWithPath:"/Users/n/numivivo-paired-workflow-20260912/bundle/result.json")
  let before=try VivoH5ADPseudobulk.fingerprint(input)
  let data=try JSONDecoder().decode(Input.self,from:Data(contentsOf:input))
  guard data.rna.cells==data.atac.cells else {throw VivoOmicsError.invalid("paired identities")}
  func normalize(_ scores:[[Double]])throws->[[Double]] {
   try scores.map { row in
    let norm=sqrt(row.reduce(0){$0+$1*$1})
    guard norm.isFinite,norm>0 else {throw VivoOmicsError.invalid("zero modality row")}
    return row.map{$0/norm}
   }
  }
  let rna=try normalize(data.rna.scores),atac=try normalize(data.atac.standardizedEmbeddings)
  let joint=rna.indices.map { i in (rna[i]+atac[i]).map{$0/sqrt(2)} }
  var options=VivoSingleCellNeighborOptions();options.neighbors=15
  for (name,scores) in [("rna",rna),("atac",atac),("joint",joint)] {
   let graph=try VivoSingleCellNeighbors.run(scores:scores,cells:data.rna.cells,options:options)
   try VivoCanonicalJSON.encode(graph).write(to:s.appendingPathComponent(name+"-graph.json"),options:.withoutOverwriting)
   try VivoCanonicalJSON.encode(scores).write(to:s.appendingPathComponent(name+"-scores.json"),options:.withoutOverwriting)
  }
  let result=try VivoWeightedNeighbors.fit(first:rna,second:atac,cells:data.rna.cells)
  try VivoCanonicalJSON.encode(result).write(to:s.appendingPathComponent("weighted.json"),options:.withoutOverwriting)
  guard try VivoH5ADPseudobulk.fingerprint(input)==before else {throw VivoOmicsError.invalid("source changed")}
  print("PASS native variance-retaining profile on \(data.rna.cells.count) cells")
 }
}
