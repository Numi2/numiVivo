import Foundation
@testable import NumiVivoKit
@main struct Main {
 static func main() throws {
  let root=URL(fileURLWithPath:"/Users/home/numivivo-modality-weights-20260912")
  let input=URL(fileURLWithPath:"/Users/home/numivivo-paired-neighbors-20260912")
  func read<T:Decodable>(_ type:T.Type,_ name:String)throws->T {
   try VivoCanonicalJSON.decode(type,from:Data(contentsOf:input.appendingPathComponent(name)))
  }
  let first=try read([[Double]].self,"rna-scores.json"),second=try read([[Double]].self,"atac-scores.json")
  let graph=try read(VivoSingleCellNeighborGraph.self,"rna-graph.json")
  let result=try VivoModalityWeights.fit(first:first,second:second,cells:graph.cells)
  try VivoCanonicalJSON.encode(result).write(to:root.appendingPathComponent("native.json"),options:.withoutOverwriting)
  print("PASS weights for \(graph.cells.count) paired cells")
 }
}
