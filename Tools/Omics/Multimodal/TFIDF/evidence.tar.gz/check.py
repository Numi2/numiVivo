from pathlib import Path
import hashlib
import json
import subprocess
import threading
import time
import h5py
import numpy as np
from scipy import sparse

s = Path(__file__).parent
source = Path('/Users/home/numivivo-multiome-20260909/original.h5')
assert hashlib.sha256(source.read_bytes()).hexdigest() == '5fbff5a4d85e0df345f6502e966ec787a8a4c429fd6b88a8772c43fd915cf3ff'
with h5py.File(source) as h:
    g = h['matrix']
    all_counts = sparse.csc_matrix((g['data'][:], g['indices'][:], g['indptr'][:]), shape=tuple(g['shape'][:]))
    types = g['features/feature_type'].asstr()[:]
    axis = g['features/id'].asstr()[:][types == 'Peaks'].tolist()
    barcodes = g['barcodes'].asstr()[:].tolist()
matrix = all_counts[types == 'Peaks', :].T.tocsr()
matrix.sort_indices()
assert matrix.shape == (2711, 98319) and matrix.nnz == 19292713
row_totals = np.asarray(matrix.sum(axis=1)).ravel().astype(np.uint64)
feature_totals = np.asarray(matrix.sum(axis=0)).ravel().astype(np.uint64)
rows = np.repeat(np.arange(matrix.shape[0], dtype=np.uint32), np.diff(matrix.indptr))
errors = []
started = time.time()
with (s/'native-report.json').open('wb') as log:
    process = subprocess.Popen([str(s/'tfidf'), '2711', '98319', str(matrix.nnz)], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=log)
    def feed():
        try:
            for _ in range(2):
                for start in range(0, matrix.nnz, 65536):
                    stop = min(start+65536, matrix.nnz)
                    block = np.empty((stop-start, 2), dtype='<u8')
                    block[:, 0] = rows[start:stop].astype(np.uint64) | (matrix.indices[start:stop].astype(np.uint64) << 32)
                    block[:, 1] = matrix.data[start:stop]
                    process.stdin.write(block.tobytes())
            process.stdin.close()
        except BaseException as e:
            errors.append(repr(e))
    thread = threading.Thread(target=feed); thread.start()
    checked = 0; maximum = 0.0; digest = hashlib.sha256()
    while checked < matrix.nnz:
        count = min(65536, matrix.nnz-checked)
        data = process.stdout.read(count*16)
        assert len(data) == count*16, (checked, len(data))
        digest.update(data)
        records = np.frombuffer(data, dtype='<u8').reshape(-1,2)
        rr = rows[checked:checked+count]
        cc = matrix.indices[checked:checked+count]
        np.testing.assert_array_equal(records[:,0] & 0xffffffff, rr)
        np.testing.assert_array_equal(records[:,0] >> 32, cc)
        expected = np.log1p((matrix.data[checked:checked+count].astype(float)/row_totals[rr]) * (2711/feature_totals[cc]) * 10000)
        actual = records[:,1].copy().view('<f8')
        maximum = max(maximum, float(np.max(abs(actual-expected))))
        np.testing.assert_allclose(actual, expected, rtol=1e-13, atol=1e-13)
        checked += count
    assert process.stdout.read(1) == b''
    thread.join(); assert process.wait() == 0 and not errors, errors
native = json.loads((s/'native-report.json').read_text())
np.testing.assert_array_equal(native['cellTotals'], row_totals)
np.testing.assert_array_equal(native['featureTotals'], feature_totals)
report = dict(status='PASS-complete-real-ATAC-SciPy-formula-comparison', cells=2711, features=98319, records=checked,
              maximumAbsoluteError=maximum, seconds=time.time()-started, outputSHA256=digest.hexdigest(),
              totalCutSites=int(row_totals.sum()), zeroCells=int((row_totals==0).sum()), zeroFeatures=int((feature_totals==0).sum()),
              signacExecution=False, biologicalValidation=False, denseMatrixAllocated=False)
(s/'axis.json').write_text(json.dumps(dict(features=axis, barcodes=barcodes), separators=(',',':')))
(s/'checks.json').write_text(json.dumps(report,indent=2)+'\n'); print(json.dumps(report))
