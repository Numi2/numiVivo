from pathlib import Path
import hashlib, json, subprocess, threading
import h5py
import numpy as np
from scipy import sparse
s=Path(__file__).parent
source=Path('/Users/home/numivivo-multiome-20260909/original.h5')
assert hashlib.sha256(source.read_bytes()).hexdigest()=='5fbff5a4d85e0df345f6502e966ec787a8a4c429fd6b88a8772c43fd915cf3ff'
with h5py.File(source) as h:
    g=h['matrix']; m=sparse.csc_matrix((g['data'][:],g['indices'][:],g['indptr'][:]),shape=tuple(g['shape'][:]))
    m=m[g['features/feature_type'].asstr()[:]=='Peaks',:].tocsc(); m.sort_indices()
totals=np.asarray(m.sum(axis=0)).ravel(); ft=np.asarray(m.sum(axis=1)).ravel()
cols=np.repeat(np.arange(m.shape[1]),np.diff(m.indptr))
errors=[]
with (s/'signac.log').open('wb') as log:
    p=subprocess.Popen(['/opt/homebrew/bin/Rscript',str(s/'signac.R'),str(s/'signac-preprocessing.R')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=log)
    def feed():
        try:
            p.stdin.write(np.array([*m.shape,m.nnz],dtype='<i4').tobytes())
            for values,dtype in [(m.indices,'<i4'),(m.indptr,'<i4'),(m.data,'<f8')]:
                for start in range(0,len(values),65536):p.stdin.write(values[start:start+65536].astype(dtype).tobytes())
            p.stdin.close()
        except BaseException as e:errors.append(repr(e))
    t=threading.Thread(target=feed);t.start();checked=0;maximum=0.;digest=hashlib.sha256()
    while checked<m.nnz:
        n=min(65536,m.nnz-checked);b=p.stdout.read(n*8)
        assert len(b)==n*8,(checked,len(b))
        v=np.frombuffer(b,dtype='<f8');j=m.indices[checked:checked+n];c=cols[checked:checked+n]
        ref=np.log1p((m.data[checked:checked+n].astype(float)/totals[c])*(m.shape[1]/ft[j])*10000)
        maximum=max(maximum,float(np.max(abs(v-ref))))
        np.testing.assert_allclose(v,ref,rtol=1e-13,atol=1e-13)
        digest.update(b);checked+=n
    assert p.stdout.read(1)==b'';t.join();assert p.wait()==0 and not errors,errors
report=dict(status='PASS-pinned-Signac-method1-function',records=checked,maximumAbsoluteError=maximum,outputValuesSHA256=digest.hexdigest(),
            sourceURL='https://raw.githubusercontent.com/stuart-lab/signac/1.16.0/R/preprocessing.R',sourceSHA256=hashlib.sha256((s/'signac-preprocessing.R').read_bytes()).hexdigest(),
            scope='Executed exact parsed RunTFIDF.default in R with Matrix; not full Signac/Seurat pipeline or biological validation')
(s/'signac-checks.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
