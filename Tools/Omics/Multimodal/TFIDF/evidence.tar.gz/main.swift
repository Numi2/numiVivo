import Foundation
let cells = Int(CommandLine.arguments[1])!, features = Int(CommandLine.arguments[2])!, records = Int(CommandLine.arguments[3])!
var output = Data()
let report = try VivoAccessibilityTFIDF.normalize(cells: cells, features: features, maximumRecords: records, scan: { accept in
    var remaining = records * 16
    while remaining > 0 {
        try Task.checkCancellation()
        let target = min(1_048_576, remaining)
        var bytes = Data()
        while bytes.count < target {
            let part = try FileHandle.standardInput.read(upToCount: target - bytes.count) ?? Data()
            guard !part.isEmpty else { throw VivoAccessibilityTFIDFError.invalidCounts }
            bytes.append(part)
        }
        try bytes.withUnsafeBytes { raw in
            for i in stride(from: 0, to: raw.count, by: 16) {
                let packed = UInt64(littleEndian: raw.loadUnaligned(fromByteOffset: i, as: UInt64.self))
                let count = UInt64(littleEndian: raw.loadUnaligned(fromByteOffset: i + 8, as: UInt64.self))
                try accept(Int(packed & 0xffff_ffff), Int(packed >> 32), count)
            }
        }
        remaining -= target
    }
}, emit: { row, column, value in
    var coordinate = (UInt64(row) | (UInt64(column) << 32)).littleEndian
    var bits = value.bitPattern.littleEndian
    withUnsafeBytes(of: &coordinate) { output.append(contentsOf: $0) }
    withUnsafeBytes(of: &bits) { output.append(contentsOf: $0) }
    if output.count >= 1_048_576 { try FileHandle.standardOutput.write(contentsOf: output); output.removeAll(keepingCapacity: true) }
})
try FileHandle.standardOutput.write(contentsOf: output)
let data = try JSONSerialization.data(withJSONObject: ["cells": report.cells, "features": report.features, "records": report.records,
    "cellTotals": report.cellTotals, "featureTotals": report.featureTotals], options: [.sortedKeys])
try FileHandle.standardError.write(contentsOf: data)
