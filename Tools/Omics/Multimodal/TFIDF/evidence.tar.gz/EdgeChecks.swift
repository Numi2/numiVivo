import Foundation
@main struct Check {
    static func main() async throws {
        var passed = 0
        let cases: [[(Int, Int, UInt64)]] = [
            [(-1,0,1)], [(2,0,1)], [(0,-1,1)], [(0,2,1)], [(0,0,0)],
            [(0,0,1),(0,0,1)], [(0,1,1),(0,0,1)],
            [(0,0,UInt64.max),(0,1,1)], [(0,0,UInt64.max),(1,0,1)]
        ]
        for entries in cases {
            do {
                _ = try VivoAccessibilityTFIDF.normalize(cells: 2, features: 2, maximumRecords: 4,
                    scan: { accept in for x in entries { try accept(x.0,x.1,x.2) } }, emit: { _,_,_ in })
                fatalError("accepted invalid counts")
            } catch { passed += 1 }
        }
        for scale in [0.0, -.infinity, .nan] {
            do {
                _ = try VivoAccessibilityTFIDF.normalize(cells: 2, features: 2, maximumRecords: 0, scaleFactor: scale,
                    scan: { _ in }, emit: { _,_,_ in })
                fatalError("accepted invalid scale")
            } catch { passed += 1 }
        }
        var pass = 0
        do {
            _ = try VivoAccessibilityTFIDF.normalize(cells: 2, features: 2, maximumRecords: 4, scan: { accept in
                pass += 1
                let a: UInt64 = pass == 1 ? 1 : 2, b: UInt64 = pass == 1 ? 2 : 1
                try accept(0,0,a); try accept(0,1,b); try accept(1,0,b); try accept(1,1,a)
            }, emit: { _,_,_ in })
            fatalError("accepted changed counts with identical margins")
        } catch VivoAccessibilityTFIDFError.changedReplay { passed += 1 }
        var values = [Double]()
        let zero = try VivoAccessibilityTFIDF.normalize(cells: 4, features: 3, maximumRecords: 1,
            scan: { accept in try accept(2,1,7) }, emit: { row,column,value in
                precondition(row == 2 && column == 1); values.append(value)
            })
        precondition(zero.cellTotals == [0,0,7,0] && zero.featureTotals == [0,7,0])
        precondition(values.count == 1 && abs(values[0] - log1p(40000.0/7)) < 1e-12)
        let task = Task {
            try VivoAccessibilityTFIDF.normalize(cells: 1, features: 1, maximumRecords: 0,
                scan: { _ in }, emit: { _,_,_ in })
        }
        task.cancel()
        do { _ = try await task.value; fatalError("ignored cancellation") }
        catch is CancellationError { passed += 1 }
        print("{\"rejections\":\(passed),\"zeroAxesPreserved\":true,\"changedMarginalsReplayRejected\":true}")
    }
}
