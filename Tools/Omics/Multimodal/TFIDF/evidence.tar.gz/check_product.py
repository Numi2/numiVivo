from pathlib import Path
import hashlib, json, subprocess, time
import h5py
import numpy as np
from scipy import sparse
s=Path(__file__).parent
cli=Path('/Users/home/numivivo-celltypist-interop-20260912/product-build/numivivo-omics')
source=Path('/Users/home/numivivo-multiome-20260909/original.h5')
plan=Path('/Users/home/numivivo-multiome-check-20260909/bundle/plan.json')
out=s/'product-bundle'
assert not out.exists()
cmd=[str(cli),'multiassay-10x-tfidf',str(source),'--plan',str(plan),'--assay','atac','--output',str(out)]
start=time.time();run=subprocess.run(cmd,capture_output=True)
(s/'product-run.log').write_bytes(run.stdout+run.stderr);run.check_returncode()
receipt=json.loads(run.stdout)
for name,field in [('original.h5','source'),('mapping.json','mapping'),('axes.json','axes'),('statistics.json','statistics'),('values.bin','values')]:
    with (out/name).open('rb') as f: assert list(hashlib.file_digest(f,'sha256').digest())==receipt[field]['bytes']
assert bytes(receipt['source']['bytes']).hex()=='5fbff5a4d85e0df345f6502e966ec787a8a4c429fd6b88a8772c43fd915cf3ff'
with h5py.File(source) as h:
    g=h['matrix'];raw=sparse.csc_matrix((g['data'][:],g['indices'][:],g['indptr'][:]),shape=tuple(g['shape'][:]))
    mask=g['features/feature_type'].asstr()[:]=='Peaks'
    feature_ids=g['features/id'].asstr()[:][mask].tolist();barcodes=g['barcodes'].asstr()[:].tolist()
matrix=raw[mask,:].T.tocsr();matrix.sort_indices()
axes=json.loads((out/'axes.json').read_text());statistics=json.loads((out/'statistics.json').read_text())
assert axes['kind']=='chromatinAccessibility' and axes['countUnit']=='cutSiteCount' and axes['genomeAssembly']=='GRCh38'
assert [x['id'] for x in axes['features']]==feature_ids
assert [x['identity']['barcode'] for x in axes['observations']]==barcodes
assert axes['sourceObservationIndices']==list(range(2711))
np.testing.assert_array_equal(statistics['cellTotals'],np.asarray(matrix.sum(axis=1)).ravel())
np.testing.assert_array_equal(statistics['featureTotals'],np.asarray(matrix.sum(axis=0)).ravel())
assert statistics['records']==19292713 and statistics['scaleFactor']==10000
assert bytes(receipt['values']['bytes']).hex()=='97e18cdc7e82e3b5fa5c3bfaf68d4c96ccc342b7334a1618c5e2d4cac72cfb55'
failures=[]
for assay in ['rna','missing','atac']:
    command=cmd.copy();command[6]=assay
    target=out if assay=='atac' else s/('reject-'+assay)
    command[-1]=str(target)
    failed=subprocess.run(command,capture_output=True)
    assert failed.returncode==65,failed.stdout
    assert assay=='atac' or not target.exists()
    assert not list(s.glob('.numivivo-tfidf-*'))
    failures.append(dict(assay=assay,error=failed.stderr.decode()))
with (out/'values.bin').open('rb') as f:assert list(hashlib.file_digest(f,'sha256').digest())==receipt['values']['bytes']
report=dict(status='PASS-complete-10x-native-TFIDF-product',receipt=receipt,seconds=time.time()-start,
            allCountTotalsAndIdentitiesChecked=True,exactQualifiedSparseOutput=True,failures=failures,
            scope='Full measured single-donor paired source; resident multi-assay importer and sparse normalization. Not LSI, integration, regulatory prediction or biological validation.')
(s/'product-checks.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
