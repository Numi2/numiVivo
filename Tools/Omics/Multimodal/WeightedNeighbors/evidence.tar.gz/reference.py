from pathlib import Path
import json,hashlib,importlib.metadata
import numpy as np
from scipy.spatial.distance import cdist
from scipy import sparse
from umap.umap_ import fuzzy_simplicial_set
s=Path(__file__).parent;p=Path('/Users/home/numivivo-paired-neighbors-20260912')
protocol=json.loads((s/'protocol.json').read_text())
for name,h in protocol['inputs'].items():
 with (p/name).open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==h
xs=[np.array(json.loads((p/(name+'-scores.json')).read_text())) for name in ['rna','atac']]
baselines={name:json.loads((p/(name+'-graph.json')).read_text()) for name in ['rna','atac','joint']}
with open('/Users/home/numivivo-modality-weights-20260912/reference.npz','rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==protocol['weightReferenceSHA256']
w=np.load('/Users/home/numivivo-modality-weights-20260912/reference.npz')
n=len(xs[0]);k=15
nearest=[np.array(baselines[name]['neighborDistances']).reshape(n,k)[:,1] for name in ['rna','atac']]
ii=np.empty((n,k),dtype=np.int64);dd=np.empty((n,k))
for lo in range(0,n,128):
 hi=min(lo+128,n);dissimilarity=np.zeros((hi-lo,n))
 for m in range(2):
  euclidean=cdist(xs[m][lo:hi],xs[m]); euclidean[np.arange(hi-lo),np.arange(lo,hi)]=np.inf
  nearest_exact=euclidean.min(axis=1)
  distance=np.maximum(0,euclidean-nearest_exact[:,None])
  dissimilarity+=-np.expm1(-distance/w['bandwidths'][m,lo:hi,None])*w['weights'][m,lo:hi,None]
 distance=np.sqrt(np.clip(dissimilarity/2,0,1))
 for local,i in enumerate(range(lo,hi)):
  order=np.lexsort((np.arange(n),distance[local]));order=order[order!=i][:k-1]
  ii[i]=np.r_[i,order];dd[i]=np.r_[0,distance[local,order]]
np.savez_compressed(s/'reference-neighbors.npz',indices=ii,distances=dd)
native=json.loads((s/'native.json').read_text());g=native['graph']
assert g['cells']==baselines['rna']['cells']==baselines['atac']['cells']
ni=np.array(g['neighborIndices']).reshape(n,k);nd=np.array(g['neighborDistances']).reshape(n,k)
mismatches=int(np.sum(ni!=ii));maxerr=float(np.max(abs(nd-dd)))
ref,_,_=fuzzy_simplicial_set(xs[0],k,np.random.RandomState(7),'euclidean',knn_indices=ii,knn_dists=dd,local_connectivity=1)
actual=sparse.csr_matrix((g['weights'],g['columnIndices'],g['rowOffsets']),shape=(n,n))
diff=actual-ref;weightError=float(np.max(abs(diff.data))) if diff.nnz else 0
overlap={}
for name,b in baselines.items():
 bi=np.array(b['neighborIndices']).reshape(n,k)[:,1:]
 fractions=np.array([len(set(a)&set(b))/(k-1) for a,b in zip(ni[:,1:],bi)])
 overlap[name]=dict(meanSharedNeighborFraction=float(fractions.mean()),zeroOverlapCells=int(sum(fractions==0)))
report=dict(status='PASS' if mismatches==0 and maxerr<1e-10 and weightError<1e-5 else 'FAIL',neighborIndexMismatches=mismatches,maxDistanceError=maxerr,maxFuzzyWeightError=weightError,edges=len(g['weights']),connectedComponents=g['connectedComponents'],isolatedCells=g['isolatedCells'],overlap=overlap,biologicalValidation=False,versions={k:importlib.metadata.version(k) for k in ['numpy','scipy','umap-learn']})
(s/'comparison.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));assert report['status']=='PASS'
