import Foundation
import NumiVivoKit
@main struct Checks {
 static func main() throws {
  let root=URL(fileURLWithPath:"/Users/home/numivivo-modality-weights-20260912")
  let input=URL(fileURLWithPath:"/Users/home/numivivo-paired-neighbors-20260912")
  func read<T:Decodable>(_ type:T.Type,_ path:URL)throws->T { try JSONDecoder().decode(type,from:Data(contentsOf:path)) }
  let a=try read([[Double]].self,input.appendingPathComponent("rna-scores.json"))
  let b=try read([[Double]].self,input.appendingPathComponent("atac-scores.json"))
  let expected=try read(VivoModalityWeightResult.self,root.appendingPathComponent("native.json"))
  let actual=try VivoModalityWeights.fit(first:a,second:b,cells:expected.cells)
  guard actual.weights == expected.weights, actual.bandwidths == expected.bandwidths,
   actual.scores == expected.scores, actual.withinDistances == expected.withinDistances,
   actual.crossDistances == expected.crossDistances else { fatalError("product differs") }
  let swapped=try VivoModalityWeights.fit(first:b,second:a,cells:expected.cells)
  guard swapped.weights == Array(expected.weights.reversed()) else { fatalError("modality swap differs") }
  var checks=0
  func reject(_ action:()throws->VivoModalityWeightResult) {
   do { _=try action();fatalError("invalid input accepted") } catch { checks+=1;print("rejected: \(error)") }
  }
  reject { try VivoModalityWeights.fit(first:Array(a.dropLast()),second:b,cells:expected.cells) }
  var nonunit=a;nonunit[0][0] += 2
  reject { try VivoModalityWeights.fit(first:nonunit,second:b,cells:expected.cells) }
  var nan=a;nan[0][0] = .nan
  reject { try VivoModalityWeights.fit(first:nan,second:b,cells:expected.cells) }
  var duplicate=expected.cells;duplicate[0]=duplicate[1]
  reject { try VivoModalityWeights.fit(first:a,second:b,cells:duplicate) }
  reject { try VivoModalityWeights.fit(first:a,second:b,cells:expected.cells,neighborsIncludingSelf:1) }
  let constant=[[Double]](repeating:[1,0],count:15)
  reject { try VivoModalityWeights.fit(first:constant,second:constant,cells:Array(expected.cells.prefix(15))) }
  print("PASS product parity, modality swap, \(checks) invalid-input checks")
 }
}
