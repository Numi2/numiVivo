import Foundation
import NumiVivoKit
@main struct Main {
 static func main() throws {
  let s=URL(fileURLWithPath:"/Users/home/numivivo-weighted-neighbors-20260912")
  let p=URL(fileURLWithPath:"/Users/home/numivivo-paired-neighbors-20260912")
  func read<T:Decodable>(_ type:T.Type,_ name:String)throws->T {try JSONDecoder().decode(type,from:Data(contentsOf:p.appendingPathComponent(name)))}
  let a=try read([[Double]].self,"rna-scores.json"),b=try read([[Double]].self,"atac-scores.json")
  let baseline=try read(VivoSingleCellNeighborGraph.self,"rna-graph.json")
  let result=try VivoWeightedNeighbors.fit(first:a,second:b,cells:baseline.cells)
  try VivoCanonicalJSON.encode(result).write(to:s.appendingPathComponent("product-native.json"),options:.withoutOverwriting)
  let swap=try VivoWeightedNeighbors.fit(first:b,second:a,cells:baseline.cells)
  guard swap.graph.neighborIndices == result.graph.neighborIndices,
    swap.graph.neighborDistances == result.graph.neighborDistances,
    swap.graph.weights == result.graph.weights else {fatalError("modality swap changed graph")}
  print("PASS weighted graph and modality swap; \(result.graph.weights.count) CSR entries")
 }
}
