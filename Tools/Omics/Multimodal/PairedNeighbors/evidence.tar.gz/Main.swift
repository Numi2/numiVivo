import Foundation
@testable import NumiVivoKit
@main struct Main {
 static func main() throws {
  let root = URL(fileURLWithPath: "/Users/home/numivivo-paired-neighbors-20260912")
  let rna = try VivoCanonicalJSON.decode(VivoSingleCellReductionResult.self, from: Data(contentsOf: URL(fileURLWithPath: "/Users/home/numivivo-paired-rna-pca-20260912/native.json")))
  let atacRoot = URL(fileURLWithPath: "/Users/home/numivivo-atac-lsi-20260912/product-bundle")
  let receipt = try VivoCanonicalJSON.decode(VivoAccessibilityLSIReceipt.self, from: Data(contentsOf: atacRoot.appendingPathComponent("receipt.json")))
  let axesData = try Data(contentsOf: atacRoot.appendingPathComponent("axes.json"))
  let bytes = try Data(contentsOf: atacRoot.appendingPathComponent("embeddings.bin"))
  guard try VivoCanonicalJSON.fingerprint(axesData) == receipt.axes,
        try VivoCanonicalJSON.fingerprint(bytes) == receipt.embeddings else { throw VivoOmicsError.invalid("ATAC hashes") }
  let axes = try VivoCanonicalJSON.decode(VivoAccessibilityTFIDFIO.Axes.self, from: axesData)
  let cells = axes.observations.map { VivoOmicsCellIdentity(sampleID: $0.identity.sampleID, barcode: $0.identity.barcode) }
  guard cells == rna.cells, cells.count == 2711, bytes.count == cells.count*30*16 else { throw VivoOmicsError.invalid("paired axes") }
  var atac = [[Double]](repeating: [Double](repeating: 0,count: 30),count: cells.count)
  try bytes.withUnsafeBytes { p in
   for i in 0..<(cells.count*30) {
    let row = Int(UInt32(littleEndian: p.loadUnaligned(fromByteOffset: i*16,as: UInt32.self)))
    let col = Int(UInt32(littleEndian: p.loadUnaligned(fromByteOffset: i*16+4,as: UInt32.self)))
    guard row == i/30, col == i%30 else { throw VivoOmicsError.invalid("matrix coordinates") }
    atac[row][col] = Double(bitPattern: UInt64(littleEndian: p.loadUnaligned(fromByteOffset: i*16+8,as: UInt64.self)))
   }
  }
  var rnaScores = rna.scores
  for k in 0..<30 {
   var mean = 0.0, m2 = 0.0
   for i in rnaScores.indices { let delta = rnaScores[i][k]-mean;mean += delta/Double(i+1);m2 += delta*(rnaScores[i][k]-mean) }
   let sd = sqrt(m2/Double(rnaScores.count-1))
   guard sd.isFinite, sd>0 else { throw VivoOmicsError.invalid("constant RNA component") }
   for i in rnaScores.indices { rnaScores[i][k] = (rnaScores[i][k]-mean)/sd }
  }
  func l2(_ x: [[Double]]) throws -> [[Double]] {
   try x.map { row in
    let norm = sqrt(row.reduce(0) { $0+$1*$1 })
    guard norm.isFinite, norm>0 else { throw VivoOmicsError.invalid("zero or invalid modality row") }
    return row.map { $0/norm }
   }
  }
  let r = try l2(rnaScores), a = try l2(atac)
  let joint = r.indices.map { i in (r[i]+a[i]).map { $0/sqrt(2) } }
  var options = VivoSingleCellNeighborOptions();options.neighbors = 15
  for (name,scores) in [("rna",r),("atac",a),("joint",joint)] {
   let graph = try VivoSingleCellNeighbors.run(scores: scores,cells: cells,options: options)
   try VivoCanonicalJSON.encode(graph).write(to: root.appendingPathComponent(name+"-graph.json"),options: .withoutOverwriting)
   try VivoCanonicalJSON.encode(scores).write(to: root.appendingPathComponent(name+"-scores.json"),options: .withoutOverwriting)
   print("\(name): \(graph.weights.count) edges, \(graph.connectedComponents) components, \(graph.isolatedCells) isolated")
  }
 }
}
