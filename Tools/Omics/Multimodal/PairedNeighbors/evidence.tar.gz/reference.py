from pathlib import Path
import json,hashlib,importlib.metadata
import numpy as np
from scipy.spatial.distance import cdist
from scipy import sparse
from umap.umap_ import fuzzy_simplicial_set
s=Path(__file__).parent;p=json.loads((s/'protocol.json').read_text())
for path,h in p['inputs'].items():
 with open(path,'rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==h
rna=json.loads(Path('/Users/home/numivivo-paired-rna-pca-20260912/native.json').read_text())
r=np.array(rna['scores']);r=(r-r.mean(axis=0))/r.std(axis=0,ddof=1)
records=np.fromfile('/Users/home/numivivo-atac-lsi-20260912/product-bundle/embeddings.bin',dtype=[('row','<u4'),('col','<u4'),('v','<f8')])
a=records['v'].reshape(2711,30)
r/=np.linalg.norm(r,axis=1)[:,None];a=a/np.linalg.norm(a,axis=1)[:,None]
joint=np.concatenate([r,a],axis=1)/np.sqrt(2)
graphs={};metrics={};k=15;n=len(r)
for name,x in [('rna',r),('atac',a),('joint',joint)]:
 g=json.loads((s/(name+'-graph.json')).read_text());graphs[name]=g
 assert g['cells']==rna['cells']
 native_x=np.array(json.loads((s/(name+'-scores.json')).read_text()))
 np.testing.assert_allclose(native_x,x,rtol=1e-12,atol=1e-12)
 ii=np.empty((n,k),dtype=np.int64);dd=np.empty((n,k))
 for lo in range(0,n,128):
  hi=min(n,lo+128);block=cdist(x[lo:hi],x)
  for local,i in enumerate(range(lo,hi)):
   order=np.lexsort((np.arange(n),block[local]));order=order[order!=i][:k-1]
   ii[i]=np.r_[i,order];dd[i]=np.r_[0,block[local,order]]
 native_i=np.array(g['neighborIndices']).reshape(n,k);native_d=np.array(g['neighborDistances']).reshape(n,k)
 np.testing.assert_array_equal(native_i,ii);np.testing.assert_allclose(native_d,dd,rtol=1e-12,atol=1e-12)
 ref,_,_=fuzzy_simplicial_set(x,k,np.random.RandomState(7),'euclidean',knn_indices=ii,knn_dists=dd,local_connectivity=1)
 native=sparse.csr_matrix((g['weights'],g['columnIndices'],g['rowOffsets']),shape=(n,n))
 diff=(native-ref).tocsr();err=float(np.max(abs(diff.data))) if diff.nnz else 0.
 assert err<1e-5,err
 metrics[name]=dict(maxScoreError=float(np.max(abs(native_x-x))),maxDistanceError=float(np.max(abs(native_d-dd))),maxFuzzyWeightError=err,edges=len(g['weights']),connectedComponents=g['connectedComponents'],isolatedCells=g['isolatedCells'])
overlap={}
for left,right in [('rna','atac'),('rna','joint'),('atac','joint')]:
 li=np.array(graphs[left]['neighborIndices']).reshape(n,k)[:,1:];ri=np.array(graphs[right]['neighborIndices']).reshape(n,k)[:,1:]
 fraction=np.array([len(set(l)&set(r))/(k-1) for l,r in zip(li,ri)])
 overlap[left+'-'+right]=dict(meanSharedNeighborFraction=float(fraction.mean()),medianSharedNeighborFraction=float(np.median(fraction)),zeroOverlapCells=int(np.sum(fraction==0)))
report=dict(status='PASS-numerical-baselines',metrics=metrics,overlap=overlap,versions={k:importlib.metadata.version(k) for k in ['numpy','scipy','umap-learn']},biologicalValidation=False,learnedModalityWeights=False)
(s/'comparison.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
