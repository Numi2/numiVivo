import Foundation
@testable import NumiVivoKit
@main struct Main {
 static func main() throws {
  let root = URL(fileURLWithPath: "/Users/home/numivivo-paired-rna-pca-20260912")
  let source = URL(fileURLWithPath: "/Users/home/numivivo-multiome-20260909/original.h5")
  let before = try VivoH5ADPseudobulk.fingerprint(source)
  let plan = try VivoCanonicalJSON.decode(VivoTenXMultiAssayPlan.self, from: Data(contentsOf: URL(fileURLWithPath: "/Users/home/numivivo-multiome-check-20260909/bundle/plan.json")))
  let multi = try VivoMultiAssayTenX.readSnapshot(source, plan: plan)
  let assay = multi.assays.first { $0.id == "rna" }!
  guard assay.kind == .rna, assay.countUnit == .umiCount else { throw VivoOmicsError.invalid("RNA UMI assay required") }
  let cells = assay.observationIndices.map { multi.observations[$0].identity }
  let sourceData = VivoSingleCellDataset(id: multi.id, evidence: multi.evidence, sourceDescription: multi.sourceDescription,
    countUnit: .umiCount, samples: multi.samples, features: assay.features.map { .init(id: $0.id, name: $0.name) },
    cells: cells.map { .init(barcode: $0.barcode, sampleID: $0.sampleID) }, matrix: assay.matrix)
  var limits = VivoOmicsLimits(); limits.maximumNonzeros = 6_000_000
  let processed = try VivoSingleCellProcessing.run(sourceData, limits: limits)
  guard processed.dataset.cells.count == 2711, processed.sourceCellIndices == Array(0..<2711) else { throw VivoOmicsError.invalid("unexpected cell filtering") }
  var options = VivoSingleCellReductionOptions()
  options.components = 30; options.maximumBasis = 256; options.highlyVariableFeatures = 2000
  options.relativeResidualTolerance = 1e-6; options.seed = 7; options.retainProjectionCenters = true
  let result = try VivoSingleCellReduction.run(processed, options: options)
  guard try VivoH5ADPseudobulk.fingerprint(source) == before else { throw VivoOmicsError.invalid("source changed") }
  try VivoCanonicalJSON.encode(result).write(to: root.appendingPathComponent("native.json"), options: .withoutOverwriting)
  try VivoCanonicalJSON.encode(sourceData.metadata).write(to: root.appendingPathComponent("metadata.json"), options: .withoutOverwriting)
  print("PASS native RNA PCA: \(cells.count) cells, \(assay.features.count) genes, \(assay.matrix.counts.count) counts, \(result.selectedFeatureIndices.count) HVGs, \(result.basisSize) basis")
 }
}
