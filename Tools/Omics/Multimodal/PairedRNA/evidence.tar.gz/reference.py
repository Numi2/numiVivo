from pathlib import Path
import json,hashlib,importlib.metadata
import numpy as np
import h5py,scanpy as sc,anndata as ad
from scipy import sparse
from scipy.sparse.linalg import LinearOperator,svds
s=Path(__file__).parent
source=Path('/Users/home/numivivo-multiome-20260909/original.h5')
with source.open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==json.loads((s/'protocol.json').read_text())['sourceSHA256']
with h5py.File(source) as h:
 g=h['matrix'];shape=tuple(g['shape'][:]);x=sparse.csc_matrix((g['data'][:],g['indices'][:],g['indptr'][:]),shape=shape).T.tocsr()
 types=g['features/feature_type'].asstr()[:];ids=g['features/id'].asstr()[:];names=g['features/name'].asstr()[:];barcodes=g['barcodes'].asstr()[:]
mask=types=='Gene Expression';x=x[:,mask].astype(np.float64);ids=ids[mask];names=names[mask]
assert x.shape==(2711,36601) and x.nnz==5218473 and x.sum()==11786194
raw_total=int(x.sum());a=ad.AnnData(x);a.obs_names=barcodes;a.var_names=ids
sc.pp.normalize_total(a,target_sum=10000);sc.pp.log1p(a)
sc.pp.highly_variable_genes(a,flavor='seurat',n_top_genes=2000,n_bins=20)
selected=np.flatnonzero(a.var.highly_variable.to_numpy());z=a.X[:,selected].tocsr()
center=np.asarray(z.mean(axis=0)).ravel();n,m=z.shape
def mv(v):return np.asarray(z@v)-center@v
def rmv(v):return np.asarray(z.T@v)-center*np.sum(v)
def mm(v):return np.asarray(z@v)-np.ones((n,1))@(center@v)[None,:]
def rmm(v):return np.asarray(z.T@v)-center[:,None]*v.sum(axis=0)[None,:]
op=LinearOperator((n,m),matvec=mv,rmatvec=rmv,matmat=mm,rmatmat=rmm,dtype=np.float64)
u,d,vt=svds(op,k=30,tol=1e-10,solver='arpack',which='LM',v0=np.random.default_rng(719).normal(size=min(n,m)))
order=np.argsort(d)[::-1];u=u[:,order];d=d[order];v=vt[order].T
np.savez_compressed(s/'reference.npz',u=u,singularValues=d,loadings=v,selected=selected,centers=center,barcodes=barcodes.astype(str),featureIDs=ids.astype(str),hvgMeans=a.var.means.to_numpy(),hvgDispersions=a.var.dispersions_norm.to_numpy())
report=dict(cells=n,features=x.shape[1],selected=len(selected),records=x.nnz,counts=raw_total,versions={k:importlib.metadata.version(k) for k in ['numpy','scipy','scanpy','anndata','h5py']},leftResidual=float(np.max(np.linalg.norm(mm(v)-u*d,axis=0)/d)),rightResidual=float(np.max(np.linalg.norm(rmm(u)-v*d,axis=0)/d)))
(s/'reference-checks.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
