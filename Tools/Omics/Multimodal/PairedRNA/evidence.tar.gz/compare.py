from pathlib import Path
import json
import numpy as np
s=Path(__file__).parent
a=json.loads((s/'native.json').read_text());meta=json.loads((s/'metadata.json').read_text());b=np.load(s/'reference.npz')
assert [c['barcode'] for c in a['cells']]==b['barcodes'].tolist()
assert [f['id'] for f in meta['features']]==b['featureIDs'].tolist()
axes=json.loads(Path('/Users/home/numivivo-atac-lsi-20260912/product-bundle/axes.json').read_text())
assert a['cells']==[o['identity'] for o in axes['observations']]
np.testing.assert_array_equal(a['selectedFeatureIndices'],b['selected'])
v=np.array(a['loadings']);scores=np.array(a['scores']);sign=np.sign(np.sum(v*b['loadings'],axis=0));v*=sign;scores*=sign
nativeS=np.sqrt(np.array(a['explainedVariance'])*(len(scores)-1))
metrics=dict(maxRelativeSingularValueError=float(np.max(abs(nativeS/b['singularValues']-1))),maxLoadingError=float(np.max(abs(v-b['loadings']))),maxScoreError=float(np.max(abs(scores-b['u']*b['singularValues']))),maxCenterError=float(np.max(abs(np.array(a['projectionCenters'])-b['centers']))),maximumNativeResidual=max(a['relativeResiduals']))
passed=metrics['maxRelativeSingularValueError']<1e-8 and metrics['maxLoadingError']<1e-6 and metrics['maxScoreError']<1e-4 and metrics['maxCenterError']<1e-10 and metrics['maximumNativeResidual']<=1e-6
report=dict(status='PASS' if passed else 'FAIL',cells=2711,features=36601,selected=2000,components=30,exactPairedRNAATACIdentities=True,exactScanpyHVGSelection=True,metrics=metrics,biologicalValidation=False)
(s/'comparison.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));assert passed
